﻿using System;
using System.IO;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.ca.models.Rescue;
using cdk.evr.converge.cbe.ca.models.Transaction;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Inventory;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.ca.Formatters
{
    /// <summary>
    /// Formatter that allows content of type text/plain and application/octet stream
    /// or no content type to be parsed to raw data. Allows for a single input parameter
    /// in the form of:
    /// 
    /// public string RawString([FromBody] string data)
    /// public byte[] RawData([FromBody] byte[] data)
    /// </summary>
    public class RawRequestBodyFormatter : InputFormatter
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public RawRequestBodyFormatter()
        {
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/json"));
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/plain"));
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/octet-stream"));
        }


        /// <summary>
        /// Allow only json media types to proceed.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override Boolean CanRead(InputFormatterContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            var contentType = context.HttpContext.Request.ContentType;

            if (string.IsNullOrEmpty(contentType) || contentType == "application/json" ||
                contentType == "text/json" || contentType == "application/*+json")
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Handle json types using the NewtonSoft library to deserialize.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public override async Task<InputFormatterResult> ReadRequestBodyAsync(InputFormatterContext context)
        {
            var request = context.HttpContext.Request;
            var path = context.HttpContext.Request.Path.Value;
            var contentType = context.HttpContext.Request.ContentType;

            if (contentType == "application/json" || contentType == "application/*+json" || contentType == "text/json")
            {
                // We want to deserialize using NewtonSoft, not Microsoft.
                using (var reader = new StreamReader(request.Body))
                {
                    var content = await reader.ReadToEndAsync();
                    switch (path)
                    {
                        case "/api/Inventory/UpdateInventory":
                            return await InputFormatterResult.SuccessAsync(JsonConvert.DeserializeObject<ApiItemModel<InventoryRangeUpdateModel>>(content));
                        case "/api/Inventory/ReceiveInventory":
                            return await InputFormatterResult.SuccessAsync(JsonConvert.DeserializeObject<ApiItemModel<InventoryRangeModel>>(content));
                        case "/api/Inventory/TransferInventory":
                            return await InputFormatterResult.SuccessAsync(JsonConvert.DeserializeObject<ApiItemModel<InventoryRangeTransferModel>>(content));
                        case "/api/Rescue/TransactionRescue":
                            return await InputFormatterResult.SuccessAsync(JsonConvert.DeserializeObject<ApiItemModel<RecoveryModel>>(content));
                        default:
                            return await InputFormatterResult.SuccessAsync(JsonConvert.DeserializeObject<ApiItemModel<CaTransactionModel>>(content));
                    }
                }
            }

            return await InputFormatterResult.FailureAsync();
        }
    }
}

