﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace cdk.evr.converge.cbe.ca
{
    public interface ITokenManager
    {
        bool ValidateToken(string authToken);
    }
}