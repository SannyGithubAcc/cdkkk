﻿using cdk.evr.converge.cbe.ca.models.Transaction;
using cdk.evr.converge.cbe.common.models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// Interface for the TransactionServiceController.
    /// </summary>
    public interface ITransactionServiceController
    {
        /// <summary>
        /// Submit is used to submit CaTransactionModel objects for processing.  All state
        /// transactions are processed through this service, which will return a new
        /// CaTransactionModel object containing the initial request with response properties
        /// populated.  In all cases, this service should return a CaTransactionModel with any
        /// encountered errors identified in the errors object.
        /// </summary>
        /// <param name="request">Json string representation of a CaTransactionModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing CaTransactionModel object with the specified request properties and either the response properties or error objects specified.</returns>
        Task<IActionResult> Submit([FromBody] ApiItemModel<CaTransactionModel> request);
    }
}