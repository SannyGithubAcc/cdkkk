﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.ca.biz.TransactionMockings;
using cdk.evr.converge.cbe.ca.biz.TransactionProcessors;
using cdk.evr.converge.cbe.ca.models.Inquiries.OvernightDriverLicenseInquiryModels;
using cdk.evr.converge.cbe.ca.models.Inquiries.OvernightVehicleInquiryModels; //Temporarily needed for mocked overnight responses
using cdk.evr.converge.cbe.ca.models.Transaction;
using cdk.evr.converge.cbe.common;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Constants;
using cdk.evr.converge.cbe.common.models.Eft;
using cdk.evr.converge.cbe.common.models.Enumerations;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.models.Logging;
using cdk.evr.converge.cbe.common.models.Transactions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// The TransactionServiceController provides the API functions for processing a
    /// transaction.  Based on the properties supplied in the request, the appropriate
    /// transaction processor will be identified and run in order to service the request.
    /// </summary>
    [TokenAuthorizationFilter]
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionServiceController : ControllerBase, ITransactionServiceController
    {
        private ITransactionProcessorFactory _transactionProcessorFactory { get; set; }
        private ITransactionMockingFactory _transactionMockingFactory { get; set; }
        private ITransactionLogging _transactionLogger { get; set; }
        private IStoreValidator _storeValidator { get; set; }
        private ITransactionManager _transactionManager { get; set; }
        private IDmvLogManager _dmvLogManager { get; set; }
        private ICruxLoggingManager _cruxLoggingManager = null;
        private ISystemPerformanceManager _systemPerformanceManager { get; set; }
        private readonly ISystemStatusManager _statusManager;
        private readonly IStoreManager _storeManager;
        private DateTime? _startTime;
        private DateTime? _endTime;
        private string _detail;

        private readonly ISplunkManager _splunkManager;
        private readonly IApplicationSettingsManager _settingsManager;
        private string _tmpLogPath = null;
        private string _logFilePath
        {
            get
            {
                if (string.IsNullOrEmpty(_tmpLogPath))
                    LoadSettings();

                return _tmpLogPath;
            }
        }

        public ApiListModel<CaTransactionModel> transactionResponse { get; private set; }

        /// <summary>
        /// Constructor with dependencies injected.
        /// </summary>
        /// <param name="transactionFactory">TransactionProcessorFactory object, used to identify the transaction processor that will service this request.</param>
        /// <param name="transactionMockingFactory">TransactionMockingFactory object, used to identify the transaction mocking object that can service this request if mocking is enabled.</param>
        /// <param name="transactionLogger">TransactionLogging object, responsible for logging transactions to the postgres transaction_log table.</param>
        /// <param name="companyValidator">StoreValidator object, used the processing company is authorized to run this transaction.</param>
        /// <param name="transactionManager">TransactionManager object, responseible for manipulating transaction and transaction_detail records.</param>
        /// <param name="dmvLogManager">DmvLogManager object, responsible for creating dmv_log records.</param>
        /// <param name="settingsManager">ApplicationSettingsManager object, responseible for app common settings .</param>
        /// <param name="splunkManager">ISplunk Manager is responsible for creating and writing to a Serilog that feeds log entries in Splunk.</param>
        /// <param name="cruxLoggingManager">Crux Logging Manager to log errors to Crux system</param>
        /// <param name="statusManager">ISystemStatus Manager is responsible for creating and writing to a system status.</param>
        /// <param name="systemPerformanceManager">ISystemPerformanceManager is responsible for logging performance of the transaction.</param>
        /// <param name="storeManager">IStoreManager is responsible for load store model of the transaction.</param>
        public TransactionServiceController(ITransactionProcessorFactory transactionFactory,
            ITransactionMockingFactory transactionMockingFactory,
            ITransactionLogging transactionLogger,
            IStoreValidator companyValidator,
            ITransactionManager transactionManager,
            IDmvLogManager dmvLogManager,
            IApplicationSettingsManager settingsManager,
            ISplunkManager splunkManager,
            ICruxLoggingManager cruxLoggingManager,
            ISystemStatusManager statusManager,
            ISystemPerformanceManager systemPerformanceManager,
            IStoreManager storeManager)
        {
            _transactionMockingFactory = transactionMockingFactory;
            _transactionProcessorFactory = transactionFactory;
            _transactionLogger = transactionLogger;
            _storeValidator = companyValidator;
            _transactionManager = transactionManager;
            _dmvLogManager = dmvLogManager;
            _splunkManager = splunkManager;
            _settingsManager = settingsManager;
            _cruxLoggingManager = cruxLoggingManager;
            _statusManager = statusManager;
            _storeManager = storeManager;
            _systemPerformanceManager = systemPerformanceManager;
        }

        /// <summary>
        /// Submit is used to submit CaTransactionModel objects for processing.  All state
        /// transactions are processed through this service, which will return a new
        /// CaTransactionModel object containing the initial request with response properties
        /// populated.  In all cases, this service should return a CaTransactionModel with any
        /// encountered errors identified in the errors object.
        /// </summary>
        /// <param name="request">CaTransactionModel object containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing CaTransactionModel object with the specified request properties and either the response properties or error objects specified.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(ApiItemModel<CaTransactionModel>), 200)]
        public async Task<IActionResult> Submit([FromBody] ApiItemModel<CaTransactionModel> request)
        {
            var totalPerformance = new SystemPerformanceModel()
            {
                RequestId = request.Item.RequestId,
                State = request.Identification.State,
                System = "TransactionSubmit",
                Subsystem = "Total",
                Cmf = request.Identification.Cmf,
                Control = request.Item.Control,
                TransactionOperation = request.Item.TransactionOperation,
                TransactionType = request.Item.TransactionType
            };
            var response = new ApiItemModel<CaTransactionModel>(request);

            // We must never return a 500 error, wrap all of the logic with a try/catch
            // block to ensure all exceptions get handled one way or another.
            try
            {
                var performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "PreProcessing", request.Item.RequestId);

                var message = string.Empty;
                _startTime = DateTime.UtcNow;

                BuildDetailString(request.Item);

                var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                var isProduction = environment == Environments.Production;
                var isMocking = request.Item.TransactionMocking.UseHostMocking || request.Item.TransactionMocking.UseMocking;
                bool isTestAccount = false;
                try
                {
                    var storeModel = await _storeManager.ReadByCMFAsync(request.Identification.Cmf);
                    if (storeModel.HasErrors)
                    {
                        response.Errors.AddRange(storeModel.Errors);
                    }
                    else
                    {
                        isTestAccount = (storeModel.Item.IsTest.HasValue) ? storeModel.Item.IsTest.Value : false;
                    }
                }
                catch(Exception ex)
                {
                    response.Errors.Add(new ErrorModel($"Unable to read store data from the database {request.Identification.Cmf}", ex));
                }

                if (response.HasErrors)
                {
                    return Ok(response);
                }

                if (isProduction && !isMocking && isTestAccount)
                {
                    response.Errors.Add(new ErrorModel(false, false, true, ErrorSeverityEnum.Fatal, "Test accounts are not allowed to run transactions in the production environment.", request.Identification.Cmf));
                    return Ok(response);
                }

                //   Instantiate/init logging objects (trace, state, dmvlog).
                var cruxLoggingRequest = new CruxRequestModel();
                cruxLoggingRequest.TransactionInfo.AddRequestObject(request);
                cruxLoggingRequest.TransactionInfo.Jurisdiction = request.Identification.State;
                cruxLoggingRequest.TransactionInfo.Environment = (isProduction) ? "prod" : "test";
                cruxLoggingRequest.TransactionInfo.DebugMode = false;
                cruxLoggingRequest.TransactionInfo.Class = "J01";
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.CMF = request.Identification.Cmf;
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.HardwareID = request.Identification.ComputerId;
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ProductID = "CCAE";
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ProductVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.UserID = request.Identification.UserId;
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.Address = request.Identification.ClientIp;
                if (string.IsNullOrWhiteSpace(cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.Address))
                {
                    response.Errors.Add(new ErrorModel(false, false, true, ErrorSeverityEnum.Warning, "You must populate the ClientIp field in the identity object.  This is a required field, future versions of this API will reject transactions without a client IP address."));
                    cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.Address = "139.139.139.139";
                }
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.Port = 1111;
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.AddressType = "IPv4";
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.Protocol = "TCP";
                cruxLoggingRequest.TransactionInfo.AuthenticatedCredentials.ClientNetworkInfo.ServiceType = "browser";

                var traceLogModel = new TransactionLogModel(request.Item, request.Identification);
                traceLogModel.AddRequest(response);
                var traceLogItemModel = new ApiItemModel<TransactionLogModel>
                {
                    Item = traceLogModel
                };


                _splunkManager.InitializeLogger(request.Identification, _logFilePath);
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                if (response.Item.TransactionMocking.UseMocking && response.Item.TransactionOperation != TransactionOperation.Overnight)
                {
                    performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "MockResponse", request.Item.RequestId);

                    if (response.Item.TransactionMocking.ReturnStatus == TransactionStatus.Rescue)
                    {
                        response.Item = GetRescuedTransactionModel();
                    } else
                    {
                        response = await MockResponse(response);
                    }

                    performance.EndDateTime = DateTime.Now;
                    response.Performance.Add(performance);
                    response = await LogTotalPerformanceAsync(response, totalPerformance);
                    return Ok(response);
                }

                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "CheckForceDown", request.Item.RequestId);
                if (await IsSystemStatusForcedDown(request.Item.FirstPartnerId))
                {
                    response.Errors.Add(new ErrorModel(true, false, false, ErrorSeverityEnum.Fatal, "The system is curently not accepting any requests due to a forced down condition."));
                    response.Item.TransactionStatus = TransactionStatus.Down;

                    performance.EndDateTime = DateTime.Now;
                    response.Performance.Add(performance);
                    response = LogTotalPerformanceAsync(response, totalPerformance).Result;
                    return Ok(response);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // See if this transaction was processed previously, if so then
                // return that transaction.
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "CheckIfAutoRecovery", request.Item.RequestId);
                var tmpTransaction = await _transactionManager.CheckIfAutoRecoveryAsync(response);
                if (tmpTransaction != null)
                {
                    /*
                    * Temporary block to return mocked overnight inquiry responses
                    * until the console application to process overnight transactions
                    * has been completed
                    */
                    if (tmpTransaction.Item.TransactionOperation == TransactionOperation.Overnight && tmpTransaction.Item.TransactionMocking.UseMocking)
                    {
                        if (tmpTransaction.Item.TransactionType == TransactionType.VehicleInquiry)
                        {

                            var mockResponse = CreateMockedOvernightVehicleResponse();
                            tmpTransaction.Item.StateOvernightVehicleInquiryResponse = mockResponse;
                            tmpTransaction.Item.TransactionStatus = TransactionStatus.Success;
                        }
                        else if (tmpTransaction.Item.TransactionType == TransactionType.CustomerInquiry)
                        {
                            var mockedDlResponse = CreateMockedOvernightCustomerResponse();
                            tmpTransaction.Item.StateOvernightDriversLicenseInquiryResponse = mockedDlResponse;
                            tmpTransaction.Item.TransactionStatus = TransactionStatus.Success;
                        }

                    }
                    else
                    {
                        /*
                        * End of temporary block mocking overnight response.
                        */

                        tmpTransaction.Errors.Add(new ErrorModel
                        {
                            PropertyInError = new List<string> { "RequestId" },
                            Severity = ErrorSeverityEnum.General,
                            Message = "This transaction was previously processed, this is that transaction.  This happens when a transaction exists matching the same CMF and RequestId."
                        });
                    }

                    // Send the crux logging information to the CVR host.
                    // We need to make sure we are not billing this when we create the dmvlog object.
                    _endTime = DateTime.UtcNow;
                    cruxLoggingRequest.TransactionInfo.AddResponseObject(tmpTransaction);
                    try
                    {
                        cruxLoggingRequest.TransactionInfo.dmvlog = await _cruxLoggingManager.BuildCruxDmvLogModel(tmpTransaction);
                        cruxLoggingRequest.TransactionInfo.dmvlog.StartTime = _startTime;
                        cruxLoggingRequest.TransactionInfo.dmvlog.EndTime = _endTime;
                        cruxLoggingRequest.TransactionInfo.dmvlog.DmvDate = _startTime.Value.ToString("yyyy-MM-dd");
                        cruxLoggingRequest.TransactionInfo.dmvlog.Detail = _detail;
                    }
                    catch (Exception ex)
                    {
                        message = "Unable to create dmvlog object from transaction.";
                        _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                    }
                    await SendCruxLog(cruxLoggingRequest);

                    tmpTransaction = await LogTotalPerformanceAsync(tmpTransaction, totalPerformance);
                    return Ok(tmpTransaction);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // See if this transaction was processed previously with same information but different transacation info, if so then
                // return that transaction.
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "CheckIfDuplicateTransaction", request.Item.RequestId);
                Func<CaTransactionModel, CaTransactionModel, bool> func = (CaTransactionModel t1, CaTransactionModel t2) => { return t1.FeeAcceptedIndc == t2.FeeAcceptedIndc; };
                var duplicateTransaction = await _transactionManager.CheckForDuplicateInformation(request, func);
                if(duplicateTransaction.Item != null)
                {
                    if(duplicateTransaction.HasErrors)
                    {
                        response.Errors.AddRange(duplicateTransaction.Errors);
                    }
                    else
                    {
                        response.Errors.Add(new ErrorModel
                        {
                            PropertyInError = new List<string> { "Item" },
                            Severity = ErrorSeverityEnum.General,
                            Message = "This transaction was previously processed by a different transaction, this is that transaction.  This happens when a transaction exists matching the same operation, transaction type, cmf and control."
                        });
                    }

                    // Send the crux logging information to the CVR host.
                    // We need to make sure we are not billing this when we create the dmvlog object.
                    _endTime = DateTime.UtcNow;
                    cruxLoggingRequest.TransactionInfo.AddResponseObject(response);
                    try
                    {
                        cruxLoggingRequest.TransactionInfo.dmvlog = await _cruxLoggingManager.BuildCruxDmvLogModel(response);
                        cruxLoggingRequest.TransactionInfo.dmvlog.StartTime = _startTime;
                        cruxLoggingRequest.TransactionInfo.dmvlog.EndTime = _endTime;
                        cruxLoggingRequest.TransactionInfo.dmvlog.DmvDate = _startTime.Value.ToString("yyyy-MM-dd");
                        cruxLoggingRequest.TransactionInfo.dmvlog.Detail = _detail;
                    }
                    catch (Exception ex)
                    {
                        message = "Unable to create dmvlog object from transaction.";
                        _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                    }
                    await SendCruxLog(cruxLoggingRequest);

                    response = await LogTotalPerformanceAsync(response, totalPerformance);
                    return Ok(response);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // Todo - Instantiate/init perforance objects.

                try
                {
                    performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "WrittingTransactionLog(Request)", request.Item.RequestId);
                    traceLogItemModel = await _transactionLogger.WriteLogAsync(traceLogItemModel);
                    performance.EndDateTime = DateTime.Now;
                    response.Performance.Add(performance);
                }
                catch (Exception ex)
                {
                    message = "Exception while writting request to transaction log.";
                    var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                    response.Errors.Add(error);
                }

                // Validate the company/user information - deprecated?
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "ValidateStore", request.Item.RequestId);
                try
                {
                    response = await _storeValidator.ValidateStoreAsync(response, false, false);
                }
                catch (Exception ex)
                {
                    message = "Exception while validating request store information.";
                    var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                    response.Errors.Add(error);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                if (response.HasErrors)
                {
                    return await ReturnError(response, cruxLoggingRequest, totalPerformance);
                }

                // Todo - Validate the transaction properties.

                // Todo - Validate the transaction objects (not needed in CA).

                // For void transaction, need to save previous transacion so that unvoid can use it.
                if (response.Item.TransactionOperation == TransactionOperation.Void)
                {
                    var lastTrans = await _transactionManager.GetLatestTransactionAsync(response);
                    if (lastTrans.Item != null && !string.IsNullOrEmpty(lastTrans.Item.TransactionOperation))
                    {
                        response.Item.PreviousTransactionOperation = lastTrans.Item.TransactionOperation;
                        response.Performance.Add(lastTrans.Performance.First());
                    }
                }
                response.Item.TransactionStatus = TransactionStatus.Processing;
                response = await _transactionManager.SaveTransactionAsync(response);

                //Check transaction table and details and see if the transaction is clear or complete state. Return detail record back
                //Check is the operation is the same. Read detail record on operation, transaction type, cmf and control number find detail record. if status is clear or complete return transaction.
                // Create the transaction record.
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "ProcessTransaction", request.Item.RequestId);
                try
                {
                    response = await ProcessTransactionAsync(response);
                }
                catch (Exception ex)
                {
                    message = "Exception while processing transaction.";
                    var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                    response.Errors.Add(error);
                    response.Item.TransactionStatus = TransactionStatus.Failure;
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // Todo - Update performance obejcts and log results.

                //Update the System Status
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "UpdateStatus", request.Item.RequestId);
                if (response.Item.TransactionStatus == TransactionStatus.Down)
                {
                    UpdateSystemStatusAsync("Down", request.Item.FirstPartnerId, request.Item.TransactionType);
                }
                else if (response.Item.TransactionStatus == TransactionStatus.Failure && response.Errors.Any(error => error.Message.Contains("Q023")))
                {
                    UpdateSystemStatusAsync("Down", request.Item.FirstPartnerId, request.Item.TransactionType);
                }
                else
                {
                    UpdateSystemStatusAsync("Up", request.Item.FirstPartnerId, request.Item.TransactionType);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // Save or delete transaction depending on the disposition of the transaction.
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "SaveTransaction", request.Item.RequestId);
                if (!response.HasErrors)
                {
                    response = await _transactionManager.SaveTransactionAsync(response);
                }
                else
                {
                    /*
                     * Deleting Transaction details based on the request_id. If any transaction didn't have details after latest transaction detail delete, then its deleting complete transaction information.
                     * Because we are not maintaining transction with error status, web team holding the information. Anyhow we are storing those request related information in transaction_log and state_log for further references.
                     */
                    response = await _transactionManager.DeleteTransactionAsync(response);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // Create dmvlog entry.
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "DMVLogManager.LogTransactionAsync", request.Item.RequestId);
                try
                {
                    await _dmvLogManager.LogTransactionAsync(response);
                }
                catch (Exception ex)
                {
                    message = "Unable to create dmvlog object from transaction.";
                    _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // Send the crux logging information to the CVR host.
                _endTime = DateTime.UtcNow;
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "CruxLogBuilding", request.Item.RequestId);
                cruxLoggingRequest.TransactionInfo.AddResponseObject(response);
                try
                {
                    cruxLoggingRequest.TransactionInfo.dmvlog = await _cruxLoggingManager.BuildCruxDmvLogModel(response);
                    cruxLoggingRequest.TransactionInfo.dmvlog.StartTime = _startTime;
                    cruxLoggingRequest.TransactionInfo.dmvlog.EndTime = _endTime;
                    cruxLoggingRequest.TransactionInfo.dmvlog.DmvDate = _startTime.Value.ToString("yyyy-MM-dd");
                    cruxLoggingRequest.TransactionInfo.dmvlog.Detail = _detail;
                }
                catch (Exception ex)
                {
                    message = "Unable to create crux dmvlog object from transaction.";
                    _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "SendCruxLog", request.Item.RequestId);
                try
                {
                    await SendCruxLog(cruxLoggingRequest);
                }
                catch (Exception ex)
                {
                    message = "Unable to to send crux logging information to legacy system.";
                    _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                }
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);

                // Log the response object and end date/time.
                performance = new SystemPerformanceModel(request.Identification.State, "TransactionSubmit", "WrittingTransactionLog(Response)", request.Item.RequestId);
                traceLogItemModel.Item.AddResponse(response);
                traceLogItemModel = await _transactionLogger.WriteLogAsync(traceLogItemModel);
                performance.EndDateTime = DateTime.Now;
                response.Performance.Add(performance);
            }
            catch (Exception ex)
            {
                var message = "Unhandled exception while processing transaction";
                var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, message, ex);
                response.Errors.Add(error);
                response.Item.TransactionStatus = TransactionStatus.Failure;
            }

            response = await LogTotalPerformanceAsync(response, totalPerformance);
            return Ok(response);
        }


        /// <summary>
        /// Used to send the Crux logging object to the legacy system and handle any errors that are encountered.
        /// </summary>
        /// <param name="cruxLoggingRequest">CruxRequestModel object containing the logging information.</param>
        /// <returns>Void</returns>
        private async Task SendCruxLog(CruxRequestModel cruxLoggingRequest)
        {
            try
            {
                var cruxLoggingResponse = await _cruxLoggingManager.SendLog(cruxLoggingRequest);
                if (cruxLoggingResponse == null || cruxLoggingResponse.LoggingResult?.Status == "failure")
                {
                    _splunkManager.InitializeAndLogException(null, _logFilePath, "Unable to send CRUX logging information to the legacy server.", null, cruxLoggingRequest, cruxLoggingResponse);
                }
            }
            catch (Exception ex)
            {
                _splunkManager.InitializeAndLogException(null, _logFilePath, "Exception while sending CRUX log to legacy system.", ex, cruxLoggingRequest);
            }
        }

        /// <summary>
        /// Used to return from an error condition and handle appropriate logging.
        /// </summary>
        /// <param name="request">ApiItemModel of type PaTransactionModel object containing the response to be returned to the user.</param>
        /// <param name="cruxLoggingRequest">CruxRequestModel object containing logging information for the legacy system.</param>
        /// <param name="totalPerformance">SystemPerformanceModel object to log total preformance of transaction.</param>
        /// <returns>IActionResult indicating the http response code (we always return 200; i.e., Ok) and object.</returns>
        private async Task<IActionResult> ReturnError(ApiItemModel<CaTransactionModel> request, CruxRequestModel cruxLoggingRequest, SystemPerformanceModel totalPerformance)
        {
            var response = new ApiItemModel<CaTransactionModel>(request);

            try
            {
                _endTime = DateTime.UtcNow;
                response.Item.TransactionStatus = TransactionStatus.Failure;
                await _dmvLogManager.LogTransactionAsync(request);

                try
                {
                    cruxLoggingRequest.TransactionInfo.dmvlog = await _cruxLoggingManager.BuildCruxDmvLogModel(request);
                    cruxLoggingRequest.TransactionInfo.dmvlog.StartTime = _startTime;
                    cruxLoggingRequest.TransactionInfo.dmvlog.EndTime = _endTime;
                    cruxLoggingRequest.TransactionInfo.dmvlog.DmvDate = _startTime.Value.ToString("yyyy-MM-dd");
                    cruxLoggingRequest.TransactionInfo.dmvlog.Detail = _detail;
                }
                catch (Exception ex)
                {
                    var message = "Unable to create dmvlog object from transaction.";
                    _splunkManager.InitializeAndLogException(null, _logFilePath, message, ex);
                }

                // Send the crux logging information to the CVR host.
                cruxLoggingRequest.TransactionInfo.AddResponseObject(request);
                await SendCruxLog(cruxLoggingRequest);
            }
            catch (Exception ex)
            {
                _splunkManager.InitializeAndLogException(null, _logFilePath, "Unhandled exception while generating/sending CRUX information to legacy system.", ex, request, cruxLoggingRequest);
            }
            response = await LogTotalPerformanceAsync(response, totalPerformance);

            return Ok(response);
        }

        /// <summary>
        /// Used to identify a mocking processor that can service the requests and
        /// then runs that service's Mock method.  This will generate an appropriate
        /// response that can be returned to the caller.
        /// </summary>
        /// <param name="request">CaTransactionModel object containing the request information.</param>
        /// <returns>CaTransactionModel object containing the mocked data or an error if one was encountered.</returns>
        private async Task<ApiItemModel<CaTransactionModel>> MockResponse(ApiItemModel<CaTransactionModel> request)
        {
            var response = new ApiItemModel<CaTransactionModel>(request);

            var mocker = await _transactionMockingFactory.GetProcessor(request.Item.TransactionType, request.Item.TransactionOperation);

            if (mocker == null)
            {
                var error = new ErrorModel
                {
                    IsRequestError = true
                };
                error.PropertyInError = new List<string>() { "TransactionType", "TransactionOperation" };
                error.Message = "Unable to identify mocking object based on the supplied TransactionType and TransactionOperation properties.";
                response.Errors.Add(error);
                response.Item.TransactionStatus = TransactionStatus.Failure;

                return response;
            }

            try
            {
                response = await mocker.Mock(response);
            }
            catch (Exception mockException)
            {
                var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, "Unable to mock the response for TransactionOperation.", mockException);
                error.PropertyInError = new List<string>();
                error.PropertyInError.Add("TransactionType");
                error.PropertyInError.Add("TransactionOperation");
                response.Errors.Add(error);
                response.Errors.Add(error);
                response.Item.TransactionStatus = TransactionStatus.Failure;
            }

            return response;
        }

        /// <summary>
        /// Used to identify what transaction processor to use and then calls the
        /// process method to process the transaction.
        /// </summary>
        /// <param name="request">CaTransactionModel object containg request information.</param>
        /// <returns>CaTransactionModel object containing the response information from the state or an appropriate error object indicating the nature of the failure.</returns>
        private async Task<ApiItemModel<CaTransactionModel>> ProcessTransactionAsync(ApiItemModel<CaTransactionModel> request)
        {
            var response = new ApiItemModel<CaTransactionModel>(request);

            // Route transaction to appropriate transaction processor code.
            var transactionProcessor = _transactionProcessorFactory.GetProcessor(request.Item.TransactionType, request.Item.TransactionOperation);
            if (transactionProcessor == null)
            {
                var error = new ErrorModel
                {
                    IsRequestError = true
                };
                error.PropertyInError = new List<string>() { "TransactionType", "TransactionOperation" };
                error.Message = "Unable to identify transaction processor object based on the supplied TransactionType and TransactionOperation properties.";
                response.Errors.Add(error);
                response.Item.TransactionStatus = TransactionStatus.Failure;

                return response;
            }

            // Process the transaction.
            response = await transactionProcessor.Process(response);

            // Todo - Update inventory table.

            return response;
        }

        /// <summary>
        /// Used to see if the specified service is down or forced down.
        /// </summary>
        /// <param name="firstPartnerId">Uniquely identify a First Level Business Partner of a transaction</param>
        /// <returns>Task of type bool indicating if the service is down (true) or not (false).</returns>
        private async Task<bool> IsSystemStatusForcedDown(string firstPartnerId)
        {
            var systemStatusRecord = await _statusManager.ReadByStateSystemSubSystemAsync("CA", null, null);
            if (systemStatusRecord != null && !systemStatusRecord.HasErrors && systemStatusRecord.Item.Status.ToLower() == "forced down")
            {
                return true;
            }
            systemStatusRecord = await _statusManager.ReadByStateSystemSubSystemAsync("CA", "Transactions", null);
            if (systemStatusRecord != null && !systemStatusRecord.HasErrors && systemStatusRecord.Item.Status.ToLower() == "forced down")
            {
                return true;
            }
            if (!string.IsNullOrEmpty(firstPartnerId))
            {
                systemStatusRecord = await _statusManager.ReadByStateSystemSubSystemAsync("CA", "Transactions", firstPartnerId);
                if (systemStatusRecord != null && !systemStatusRecord.HasErrors && systemStatusRecord.Item.Status.ToLower() == "forced down")
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// This will identify system and subsystem based on the transaction type.
        /// </summary>
        /// <param name="transactionType">Name of the transaction.</param>
        /// <returns>Returns system and sub-system.</returns>
        private Tuple<string, string> GetSystemSybSystemFromTransactionType(string transactionType)
        {
            string system, subSystem = null;
            switch (transactionType)
            {
                case TransactionType.VehicleInquiry:
                    system = "Inquiry";
                    subSystem = "VR";
                    break;
                case TransactionType.CustomerInquiry:
                    system = "Inquiry";
                    subSystem = "DL";
                    break;
                case TransactionType.OLInquiry:
                    system = "Inquiry";
                    subSystem = "OL";
                    break;
                default:
                    system = "Transaction";
                    break;
            }

            return Tuple.Create(system, subSystem);
        }

        /// <summary>
        /// This will update the system status.
        /// </summary>
        /// <param name="status">Status of the system.</param>
        /// <param name="officeId">Office id.</param>
        /// <param name="transactionType">Name of the transaction.</param>
        private async void UpdateSystemStatusAsync(string status, string officeId, string transactionType)
        {
            var record = new ApiItemModel<SystemStatusModel>();
            try
            {
                var systemStatusRecord = GetSystemSybSystemFromTransactionType(transactionType);
                record.Identification.State = "CA";
                record.Identification.UserId = "System";
                record.Item.State = "CA";
                record.Item.System = systemStatusRecord.Item1;
                record.Item.Subsystem = systemStatusRecord.Item1 == "Transaction" ? officeId : systemStatusRecord.Item2;
                record.Item.Status = status;
                record.Item.StatusTimestamp = DateTime.Now;
                record = await _statusManager.SaveAsync(record);
            }
            catch(Exception ex)
            {
                _splunkManager.InitializeAndLogException(record.Identification, _logFilePath, "Unable to update system status.", ex);
            }            
        }


        /// <summary>
        /// Used to load the full path name of the exception file for logging purposes.
        /// </summary>
        private void LoadSettings()
        {
            var response = _settingsManager.ReadAsync("CA", "Logging", "Exceptions").Result;
            if (response != null)
            {
                var setting = JsonConvert.DeserializeObject<PathSetting>(response.Item.Settings.AsJsonString());
                _tmpLogPath = setting.Path;
            }
        }

        private OvernightVehicleInquiryModel CreateMockedOvernightVehicleResponse()
        {
            var result = new OvernightVehicleInquiryModel()
            {
                BasicInformation = new BasicModel()
                {
                    ReportedLicenseNumber = "3TST421",
                    InternalRecordLength = 1124,
                    TypeRecordCode = "0",
                    BasicRecordLength = 265,
                    TypeBody = "0",
                    TypeLicense = "11",
                    VlfClass = "FW",
                    LastPaperIssuedCode = "9",
                    LastTransaction = "18",
                    ExpirationDate = new DateTime(2022, 7, 20),
                    TypeVehicle = "12",
                    RegisteredOwnerCounty = "01",
                    RegisteredOwnerZipCode = "00000",
                    FirstSoldDate = null,
                    TotalFee = "0000",
                    ModelYear = 17,
                    LastTransactionDate = null,
                    RegistrationIssueDate = new DateTime(2019, 6, 30),
                    Reserved = "00",
                    LastOwnershipIssueDate = new DateTime(2020, 9, 10),
                    TypeInformationIndicators = "00000000",
                    VinLength = 16,
                    ReportedVin = "1TSTK2VT0HEA11223",
                    BodyTypeModelLength = 1,
                    BodyTypeModel = "UT",
                    ReportedMakeLength = 3,
                    ReportedMake = "FORD",
                    RegisteredOwnerNameLength = 26,
                    RegisteredOwnerName = "DOE JOHN A",
                    RegisteredOwnerNameLine2Length = 26,
                    RegisteredOwnerNameLine2 = "1111 KNOTT",
                    RegisteredOwnerCityLength = 12,
                    RegisteredOwnerCity = "SAN DIEGO",
                    LastThreeOfVin = "320",
                    NumberSubrecordE = 0,
                    NumberSubrecordG = 0,
                    NumberSubRecordJ = 0,
                    NumberSubrecordM = 2,
                    RegisteredOwnerAddressSourceIndicator = "D ",
                    Date = new DateTime(2020, 01, 01),
                    FileCode = "V",
                    LicenseNumber = "3TST421",
                    Vin = "1TSTK2VT0HEA11223",
                    Year = null,
                    Make = null,
                    UserInformation = "12345773                                          S0022",
                    Filler = " ",
                    FutureInteger = 0

                },
                BRecord = new SubrecordB()
                {
                    SubrecordCode = "B",
                    SubrecordLength = 98,
                    FoVoMask = 64,
                    VehicleMotivePower = "G",
                    RegisteredOwnerLine3NameOrAddress = "",
                    RegisteredOwnerLine4NameOrAddress = "",
                    Equipment = "",
                    CgwOrGvwIndicator = "@ "
                },
                CRecord = new SubrecordC()
                {
                    SubrecordCode = "C",
                    SubrecordLength = 124,
                    FoVoMask = 16,
                    AllocatedCounty = -224,
                },
                DRecord = new SubrecordD()
                {
                    SubrecordCode = "D",
                    SubrecordLength = 199,
                    FoVoMask = 0,
                    LegalOwnerName = "TONKIN FORD            ",
                    LegalOwnerLine2NameOrAddress = "1234 SANDY BLVD           ",
                    LegalOwnerCity = "SAN LEANDRO  ",
                },
                ERecordList = new List<SubrecordE>(),
                JRecordList = new List<SubrecordJ>(),
                MRecordList = new List<SubrecordM>()
                                    {
                                        new SubrecordM()
                                        {
                                            SubrecordCode = "M",
                                            SubrecordLength = 56,
                                            FoVoMask = 0,
                                            TypeTransactionCode = "POT",
                                            TechnicianId = "09",
                                            OfficeId = "141",
                                            WorkDate = new DateTime(2018, 1, 20),
                                            SequenceNumber = "4117",
                                            Amount = "0014400",
                                        },
                                        new SubrecordM()
                                        {
                                            SubrecordCode = "M",
                                            SubrecordLength = 56,
                                            FoVoMask = 0,
                                            TypeTransactionCode = "POT",
                                            TechnicianId = "05",
                                            OfficeId = "140",
                                            WorkDate = new DateTime(2016, 12, 23),
                                            SequenceNumber = "2775",
                                            Amount = "0064300",
                                        }
                                    },
                PlateWithOwnerErrorList = new List<PwoErrorModel>(),
                MultiVinErrorList = new List<MultiVinErrorModel>(),
                OtherErrorList = new List<OtherErrorModel>()
            };

            return result;
        }

        private OvernightDriversLicenseInquiryModel CreateMockedOvernightCustomerResponse()
        {
            var result = new OvernightDriversLicenseInquiryModel
            {
                BasicResponse = new StateBasicResponse
                {
                    Address = new OvernightAddressModel
                    {
                        AddressDate = "01/08/19",
                        City = "EL CAJON",
                        State = "CALIF",
                        StreetAddress = "1330 BUCKEYE CDR",
                        Zip = "92021"
                    },
                    Aka = "ALVAREZ, KELLY SUE BOYD",
                    BirthDate = "010862",
                    BlockNumber = "001",
                    ClearanceDate = "10/26",
                    ClearanceNumber = "874",
                    DriversLicense = "N8473486",
                    ExpirationDate = "010824",
                    EyeColor = "GREEN",
                    FileBatesNumber = "",
                    HairColor = "BLOND",
                    Height = "508",
                    IssueDate = "010819",
                    LicenseClass = "COMM",
                    LicenseExtension = "",
                    LicenseHeld = "",
                    MiscellaneousInformation = "73113081",
                    Name = "BOYD, KELLY SUE",
                    OtherAddress = new OvernightAddressModel
                    {
                        AddressDate = "02/19/16",
                        City = "LAKESIDE",
                        State = "CALIF",
                        StreetAddress = "15470 EL MONTE RD",
                        Zip = ""
                    },
                    OtherApplicationIssueDate = "",
                    OtherApplicationType = "",
                    PageNumber = "71554",
                    RecordDate = "102621",
                    ResidentialAddress = new OvernightAddressModel(),
                    Restriction1 = "",
                    Restriction2 = "",
                    Restriction3 = "",
                    Restriction4 = "",
                    Restriction5 = "",
                    RestrictionCantHandleCode = "",
                    Sex = "F",
                    TimeTableMessage = "1816",
                    Weight = "160"
                },
                ErrorResponse = new StateErrorResponse(),
                LegalResponse = new StateLegalResponse
                {
                    Abstracts = new List<string>(),
                    AccidentDate = "121920",
                    AccidentLocation = "*SAN DIEGO CO",
                    FrFileNumber = "",
                    ReportNumber = "96800014949",
                    Type = "ACC",
                    VehicleLicenseNumber = "7K14794"
                },
                MiscellaneousResponse = new StateMiscellaneousResponse
                {
                    MiscellaneousInformation = new List<string>
                                    {
                                        "MEDICAL EXPIRES 09-16-22",
                                        "DOUBLES/TRIPLES ENDORSEMENT",
                                        "TANK VEHICLE ENDORSEMENT",
                                        "SUBJECT ISSUED ID CARD 06/10/02 EXPIRES 01/08/08",
                                        "SUBJECT REPORTED DECEASED"
                                    },
                    RequesterInformation = new List<string>
                                    {
                                        "CVR",
                                        "CHRISTINE ROONEY",
                                        "1100 TOWN AND COUNTRY RD STE 850",
                                        "ORANGE         CA  92868"
                                    }
                }
            };

            return result;
        }

        /// <summary>
        /// Get Rescued mocking transaction model
        /// </summary>
        /// <returns></returns>
        private CaTransactionModel GetRescuedTransactionModel()
        {
            var request = new CaTransactionModel();
            request.Control = Guid.NewGuid().ToString();
            request.RequestId = Guid.NewGuid().ToString();
            request.TransactionType = TransactionType.NewIssue;
            request.TransactionOperation = TransactionOperation.Complete;
            request.TransactionVersion = "V01";
            request.ProductVersion = "CCAI0100";
            request.ImportVendor.Vendor = "Manual";
            request.ImportVendor.Method = "Manual";
            request.FirstPartnerId = "V07";
            request.SecondPartnerId = "BG";
            request.Vehicle.Odometer = "3";
            request.Vehicle.OdometerBrand = "A";
            request.Vehicle.OdometerUnit = "M";
            request.Registration.Plate = "2VUA601";
            request.Vehicle.LicenseTypeCode = "11";
            request.FeeAcceptedIndc = false;
            request.Sale.PurchaseDate = DateTime.Now.ToString("yyyyMMdd");
            request.Vehicle.Vin = "4T1BF1FK6CU154890";
            request.DealerDismantlerNumber = "1";
            request.Registration.Sticker = "X0000602";
            request.Vehicle.FuelType = "Gas";
            request.Vehicle.Make = "FORD";
            request.Vehicle.ModelYear = "2009";
            request.Sale.PurchasePrice = 40000;
            request.Vehicle.YearFirstSold = "2020";
            request.Vehicle.BodyStyle = "4D";
            request.Title.ReportOfSaleNumber = "12908799";
            request.Registration.InventoryCodes.Add("01R");
            request.Registration.InventoryCodes.Add("290");
            var owner = new CaOwnerModel();
            var address = new AddressBaseModel();
            address.City = "PLEASANTON";
            address.County = "1";
            address.State = "CA";
            address.StreetAddress1 = "23 ANYST";
            address.Zip = "94588";
            address.AddressType = "Residence";
            owner.DriverLicense = "N1234567";
            owner.FullName = "JOHN MILLER";
            owner.OwnerType = "Individual";
            owner.OwnerProfile = "Primary";
            owner.Addresses.Add(address);
            request.Owners.Add(owner);

            request.CompleteDateTime = DateTime.UtcNow;
            request.TransactionStatus = TransactionStatus.Rescue;
            request.CaFees.AddFee("001", "59");
            request.CaFees.AddFee("154", "2");
            request.CaFees.AddFee("002", "27");
            request.CaFees.AddFee("316", "54");
            request.CaFees.AddFee("004", "150");
            request.CaFees.AddFee("464", "1");
            request.CaFees.AddFee("008", "1");
            request.CaFees.AddFee("031", "1");
            request.CaFees.AddFee("039", "6");
            request.CaFees.AddFee("060", "6");
            request.CaFees.AddFee("061", "8");
            request.CaFees.AddFee("085", "6");
            request.CaFees.AddFee("086", "1");
            request.CaFees.AddFee("100", "3");
            request.CaFees.AdjustedAmount = "325";
            request.CaFees.PreviousPaidAmount = "0";
            request.ServiceFee = "20";
            request.OnlineProcessingFee = "5";
            request.CaFees.TotalDue = "325";
            request.Eft = "350";

            return request;
        }

        /// <summary>
        /// Used to generate the dmvlog detail property.  This has a very specific format for inquiries.
        /// </summary>
        /// <param name="request"></param>
        private void BuildDetailString(CaTransactionModel request)
        {
            _detail = string.Empty;
            if (request.TransactionType == TransactionType.VehicleInquiry && request.TransactionOperation == TransactionOperation.Online)
            {
                var vehicleRequest = request.VehicleOnlineInquiryRequest;
                var hasAddress = vehicleRequest.SuppressAddress ? "N" : "Y";
                _detail = $"{vehicleRequest.Purpose.EnsureSize(2)}{vehicleRequest.RequesterCode.EnsureSize(5)}4{vehicleRequest.FileCode.EnsureSize(1)}{vehicleRequest.Vin.EnsureSize(20)}{hasAddress}";
            }

            if (request.TransactionType == TransactionType.CustomerInquiry && request.TransactionOperation == TransactionOperation.Online)
            {
                var customerRequest = request.CustomerOnlineInquiryRequest;
                var dob = customerRequest.DateOfBirth.HasValue ? customerRequest.DateOfBirth.Value.ToString("MMddyy") : string.Empty.EnsureSize(6);
                var hasAddress = customerRequest.SuppressAddress ? "N" : "Y";
                _detail = $"{customerRequest.Purpose.EnsureSize(2)}{customerRequest.RequesterCode.EnsureSize(5)}VS{customerRequest.DriversLicense.EnsureSize(8)}{customerRequest.LastName.EnsureSize(3)}{dob}   {hasAddress}";
            }

            if (request.TransactionType == TransactionType.OLInquiry && request.TransactionOperation == TransactionOperation.Online)
            {
                var licenseRequest = request.OLOnlineInquiryRequest;
                var hasAddress = licenseRequest.SuppressedAddress ? "N" : "Y";
                _detail = $"{licenseRequest.Purpose.EnsureSize(2)}{licenseRequest.RequesterCode.EnsureSize(5)}B {licenseRequest.LicenseNumber.EnsureSize(8)}{string.Empty.PadLeft(12)}{hasAddress}";
            }

            if (request.TransactionType == TransactionType.VehicleInquiry && request.TransactionOperation == TransactionOperation.Overnight)
            {
                var vehicleRequest = request.StateOvernightVehicleInquiryRequest;
                var asOfDate = vehicleRequest.Date.HasValue ? vehicleRequest.Date.Value.ToString("MMddyy") : string.Empty.PadLeft(6);
                var year = vehicleRequest.Year.HasValue ? vehicleRequest.Year.Value.ToString().EnsureSize(2) : string.Empty.EnsureSize(2);
                var hasAddress = vehicleRequest.SuppressAddress ? "N" : "Y";
                if (vehicleRequest.Vin.Trim().Length > 0)
                {
                    if (asOfDate.Trim().Length > 0)
                    {
                        _detail = $"{vehicleRequest.UserAccessCode.EnsureSize(5)}{vehicleRequest.ManualProcessingCode.EnsureSize(1)}{vehicleRequest.FileCode.EnsureSize(1)}{vehicleRequest.Vin.EnsureSize(17)}{asOfDate}";
                    }
                    else
                    {
                        _detail = $"{vehicleRequest.UserAccessCode.EnsureSize(5)}{vehicleRequest.ManualProcessingCode.EnsureSize(1)}{vehicleRequest.FileCode.EnsureSize(1)}{vehicleRequest.Vin.EnsureSize(18)}{year}{vehicleRequest.Make.EnsureSize(3)}";
                    }
                }
                else
                {
                    if (asOfDate.Trim().Length > 0)
                    {
                        _detail = $"{vehicleRequest.UserAccessCode.EnsureSize(5)}{vehicleRequest.ManualProcessingCode.EnsureSize(1)}{vehicleRequest.FileCode.EnsureSize(1)}{vehicleRequest.LicenseNumber.EnsureSize(7)}{vehicleRequest.Vin.EnsureSize(10)}{asOfDate}";
                    }
                    else
                    {
                        _detail = $"{vehicleRequest.UserAccessCode.EnsureSize(5)}{vehicleRequest.ManualProcessingCode.EnsureSize(1)}{vehicleRequest.FileCode.EnsureSize(1)}{vehicleRequest.LicenseNumber.EnsureSize(7)}{year}{vehicleRequest.Make.EnsureSize(3)}";
                    }
                }
            }

            if (request.TransactionType == TransactionType.CustomerInquiry && request.TransactionOperation == TransactionOperation.Overnight)
            {
                var customerRequest = request.StateOvernightDriverLicenseInquiryRequest;
                if (customerRequest.DriverLicenseNumber.Trim().Length > 0)
                {
                    _detail = $"{customerRequest.EndUserAccessCode.EnsureSize(5)}{customerRequest.DriverLicenseNumber.EnsureSize(8)}{customerRequest.LastName.EnsureSize(3)}{string.Empty.EnsureSize(14)}";
                }
                else
                {
                    var dob = customerRequest.BirthDate.HasValue ? customerRequest.BirthDate.Value.ToString("MMddyy") : string.Empty.EnsureSize(6);
                    _detail = $"{customerRequest.EndUserAccessCode.EnsureSize(5)}{customerRequest.LastName.EnsureSize(19)}{dob}";
                }
            }
        }

        /// <summary>
        /// Logs the total performance of the transaction and saves it to the system performance table.
        /// </summary>
        /// <param name="request">ApiItemModel of type CaTransactionModel object containing response information.</param>
        /// <param name="totalPerformance">SystemPerformanceModel that contains info related to the total performance.</param>
        /// <returns>ApiItemModel of type CaTransactionModel of the response  with total performance added.</returns>
        private async Task<ApiItemModel<CaTransactionModel>> LogTotalPerformanceAsync(ApiItemModel<CaTransactionModel> request, SystemPerformanceModel totalPerformance)
        {
            var response = new ApiItemModel<CaTransactionModel>(request);
            totalPerformance.EndDateTime = DateTime.Now;
            response.Performance.Add(totalPerformance);
            var performanceLog = new ApiItemModel<SystemPerformanceModel>()
            {
                Identification = new IdentificationModel(request.Identification),
                Item = new SystemPerformanceModel(totalPerformance)
            };
            try
            {
                performanceLog = await _systemPerformanceManager.SaveAsync(performanceLog);
            }
            catch(Exception ex)
            {
                _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, "Unable to log total system performance.", ex);
            }

            return response;
        }
    }
}