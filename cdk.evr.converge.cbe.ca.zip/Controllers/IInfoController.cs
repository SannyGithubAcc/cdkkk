﻿using System.Collections.Generic;
using cdk.evr.converge.cbe.ca.Models;
using Microsoft.AspNetCore.Mvc;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    public interface IInfoController
    {
        ActionResult<List<SystemInformationModel>> GetSystemStatus();
    }
}