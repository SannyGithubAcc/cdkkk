﻿using System;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.ca.models.Rescue;
using cdk.evr.converge.cbe.common.models;
using Microsoft.AspNetCore.Mvc;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// Interface for the RescueController.
    /// </summary>
    public interface IRescueController
    {
        /// <summary>
        /// TransactionRescue used to rescue specified control related transactions that have been stuck for some age (typically 60 seconds)
        /// </summary>
        /// <param name="request">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing ApiItemModel of RecoveryModel object with the specified request properties and either the response properties or error objects specified.</returns>
        Task<IActionResult> TransactionRescue([FromBody] ApiItemModel<RecoveryModel> request);
    }
}
