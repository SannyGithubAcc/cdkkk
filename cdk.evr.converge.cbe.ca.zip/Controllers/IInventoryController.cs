﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Inventory;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// Interface for the InventoryController class.
    /// </summary>
    public interface IInventoryController
    {
        /// <summary>
        /// UpdateInventory is used to submit inventory status to DMV for given status and range of inventory.
        /// For single item, range start and end will indicate the single item with count being 1.
        /// </summary>
        /// <param name="request">Json string representation of a ApiItemModel of InventoryRangeUpdateModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing ApiItemModel of InventoryRangeUpdateModel object with the specified request properties and either the response properties or error objects specified.</returns>
        Task<IActionResult> UpdateInventory([FromBody] ApiItemModel<InventoryRangeUpdateModel> request);

        /// <summary>
        /// ReceiveInventory is used to submit inventory receipts to DMV for given range of inventory.
        /// </summary>
        /// <param name="request">Json string representation of a ApiItemModel of InventoryRangeModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing ApiItemModel of InventoryRangeModel bject with the specified request properties and either the response properties or error objects specified.</returns>
        Task<IActionResult> ReceiveInventory([FromBody] ApiItemModel<InventoryRangeModel> request);

        /// <summary>
        /// TransferInventory is used to submit inventory out and in to DMV for given range of inventory.
        /// This will actually call internal funcitons of InventoryUpdate calls twice one for "out" from current location and the other for "in" to the target location
        /// For single item, range start and end will indicate the single item with count being 1.
        /// </summary>
        /// <param name="request">Json string representation of a ApiItemModel or InventoryRangeTransferModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing ApiItemModel of InventoryRangeTransferModel object with the specified request properties and either the response properties or error objects specified.</returns>
        Task<IActionResult> TransferInventory([FromBody] ApiItemModel<InventoryRangeTransferModel> request);

    }
}