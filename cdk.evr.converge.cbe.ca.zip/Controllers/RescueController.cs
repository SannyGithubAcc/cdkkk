﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.ca.models;
using cdk.evr.converge.cbe.ca.models.Inquiries.InquiryModels;
using cdk.evr.converge.cbe.ca.models.Rescue;
using cdk.evr.converge.cbe.ca.models.Transaction;
using cdk.evr.converge.cbe.common;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Constants;
using cdk.evr.converge.cbe.common.models.Enumerations;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.models.Inventory;
using cdk.evr.converge.cbe.common.models.Transactions;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// The RescueController provides the API functions for processing a Transaction Rescue.
    /// </summary>
    [TokenAuthorizationFilter]
    [Route("api/[controller]")]
    [ApiController]
    public class RescueController : ControllerBase, IRescueController
    {
        private const int StaleDuration = 60;
        private readonly ISplunkManager _splunkManager;
        private readonly IApplicationSettingsManager _settingsManager;
        private readonly ITransactionManager _transactionManager;
        private readonly ITransactionInProcessManager _transactionInProcessManager;
        private readonly IInventoryManager _inventoryManager;
        private readonly ITransactionServiceController _transactionServiceController;
        private readonly AppConfigModel _appConfigModel;
        private string _tmpLogPath = null;
        private string _logFilePath
        {
            get
            {
                if (string.IsNullOrEmpty(_tmpLogPath))
                    LoadSettings();

                return _tmpLogPath;
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settingsManager"></param>
        /// <param name="splunkManager"></param>
        /// <param name="transactionManager">TransactionManager object, responseible for manipulating transaction and transaction_detail records.</param>
        /// <param name="transactionInProcessManager">TransactionInProcessManager object, responseible for retrieving transaction_detail records which are struck in rescue process.</param>
        /// <param name="appConfigModel"></param>
        /// <param name="inventoryManager"></param>
        /// <param name="transactionServiceController"></param>
        public RescueController(
            IApplicationSettingsManager settingsManager,
            ISplunkManager splunkManager,
            ITransactionManager transactionManager,
            ITransactionInProcessManager transactionInProcessManager,
            IInventoryManager inventoryManager,
            ITransactionServiceController transactionServiceController,
            AppConfigModel appConfigModel)
        {
            _splunkManager = splunkManager;
            _settingsManager = settingsManager;
            _transactionManager = transactionManager;
            _transactionInProcessManager = transactionInProcessManager;
            _inventoryManager = inventoryManager;
            _transactionServiceController = transactionServiceController;
            _appConfigModel = appConfigModel;
        }

        /// <summary>
        /// TransactionRescue used to rescue specified control related transactions that have been stuck for some age (typically 60 seconds)
        /// </summary>
        /// <param name="request">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing ApiItemModel of RecoveryModel object with the specified request properties and either the response properties or error objects specified.</returns>
        [HttpPost("TransactionRescue")]
        [ProducesResponseType(typeof(ApiItemModel<RecoveryModel>), 200)]
        public async Task<IActionResult> TransactionRescue([FromBody] ApiItemModel<RecoveryModel> request)
        {
            var rescueRequest = ValidateRescueRequest(request);
            var response = new ApiItemModel<RecoveryModel>(rescueRequest);

            if (response.HasErrors)
            {
                return Ok(response);
            }

            if (request.Item.UseMocking)
            {
                response = await MockResponse(response);
                return  Ok(response);
            }

            response = await PrepareAndProcessRescue(response);
            return Ok(response);
        }


        /// <summary>
        /// Is Used to get the tranctionDetails and process rescue transaction
        /// </summary>
        /// <param name="rescueRequest">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <returns>RecoveryModel with transaction information</returns>
        private async Task<ApiItemModel<RecoveryModel>> PrepareAndProcessRescue(ApiItemModel<RecoveryModel> rescueRequest)
        {
            var response = new ApiItemModel<RecoveryModel>(rescueRequest);

            if (rescueRequest.Item.IsStale)
            {
                response = await PerformStaleAction(rescueRequest);
            }
            else
            {
                response = await PerformNonStaleAction(rescueRequest);
            }

            return response;
        }

        /// <summary>
        /// retrieve transaction from the transcationDetailID and perform Rescue analysis
        /// </summary>
        /// <param name="rescueRequest">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <param name="transactionInProcess">Rescue transaction related reference data</param>
        /// <param name="transactionDetailID">Rescue transaction detailID from the transactionInProcess</param>
        /// <returns>RecoveryModel with transaction information</returns>
        private async Task<ApiItemModel<RecoveryModel>> RescueTransaction(ApiItemModel<RecoveryModel> rescueRequest, ApiItemModel<TransactionInProcessModel> transactionInProcess, long transactionDetailID)
        {
            var transaction = await _transactionManager.GetTransactionByDetailIdAsync<CaTransactionModel>(transactionDetailID);
            ApiItemModel<RecoveryModel> response = await AnalizeRescueTransactions(rescueRequest, transaction, transactionInProcess);
            return response;
        }

        /// <summary>
        /// Used to perform non stale rescue process
        /// </summary>
        /// <param name="rescueRequest">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <returns>RecoveryModel with transaction information</returns>
        private async Task<ApiItemModel<RecoveryModel>> PerformNonStaleAction(ApiItemModel<RecoveryModel> rescueRequest)
        {
            var response = new ApiItemModel<RecoveryModel>(rescueRequest);

            ApiItemModel<TransactionInProcessModel> transactionInProcess = new ApiItemModel<TransactionInProcessModel>();

            if (!string.IsNullOrEmpty(rescueRequest.Item.Plate))
            {
                transactionInProcess = await _transactionInProcessManager.ReadByStateCmfPlateAsync(rescueRequest.Identification.State, rescueRequest.Identification.Cmf, rescueRequest.Item.Plate);
            }
            else if (!string.IsNullOrEmpty(rescueRequest.Item.Vin))
            {
                transactionInProcess = await _transactionInProcessManager.ReadByStateCmfVinAsync(rescueRequest.Identification.State, rescueRequest.Identification.Cmf, rescueRequest.Item.Vin);
            }
            else
            {
                var message = $"We didn't have any rescue transction is associcated Control : {rescueRequest.Item.Control} by Vin : {rescueRequest.Item.Vin} OR Plate : {rescueRequest.Item.Plate}";
                response.Errors.Add(new ErrorModel(false, true, false, ErrorSeverityEnum.Fatal, message));
                response.Item.RecoveryStatus = TransactionStatus.Failure;

            }

            long transactionDetailID = transactionInProcess.Item.TransactionDetailId;

            if (transactionDetailID > 0)
            {
                //var transction = await _transactionManager.GetTransactionByDetailIdAsync<CaTransactionModel>(transactionDetailID);
                //response = await AnalizeRescueTransactions(rescueRequest, transction, transtionInProcess);

                response = await RescueTransaction(rescueRequest, transactionInProcess, transactionDetailID);
            }

            return response;
        }

        /// <summary>
        /// Used to perform stale rescue process, stale rescue means retrieve all struck transaction from transctionInProcess table and perform rescue operation transctions proceeded with in 60 seconds
        /// </summary>
        /// <param name="rescueRequest">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <returns>RecoveryModel with transaction information</returns>
        private async Task<ApiItemModel<RecoveryModel>> PerformStaleAction(ApiItemModel<RecoveryModel> rescueRequest)
        {
            var response = new ApiItemModel<RecoveryModel>(rescueRequest);
            ApiListModel<TransactionInProcessModel> transtionInProcessList = new ApiListModel<TransactionInProcessModel>();

            transtionInProcessList = new ApiListModel<TransactionInProcessModel>(); // await _transactionInProcessManager.ReadByState(rescueRequest.Identification.State);

            foreach (var item in transtionInProcessList?.Items)
            {
                long transactionDetailID = item.TransactionDetailId;
                ApiItemModel<TransactionInProcessModel> transactionInProcesItem = new ApiItemModel<TransactionInProcessModel>();
                transactionInProcesItem.Item = item;

                if (transactionDetailID > 0)
                {
                    //var transction = await _transactionManager.GetTransactionByDetailIdAsync<CaTransactionModel>(transactionDetailID);
                    //ApiItemModel<RecoveryModel> responseItem = await AnalizeRescueTransactions(rescueRequest, transction, transtionInProcesItem);
                    ApiItemModel<RecoveryModel> responseItem = await RescueTransaction(rescueRequest, transactionInProcesItem, transactionDetailID);
                    if(responseItem.Item.RecoveryResponse != null && responseItem.Item.RecoveryResponse.Count > 0)
                    {
                        response.Item.RecoveryResponse.Add(responseItem.Item.RecoveryResponse?[0]);
                    }
                }
            }

            return response;
        }

        /// <summary>
        /// AnalizeRescueTransactions will perform basic analysis
        /// </summary>
        /// <param name="request">Json string representation of a ApiItemModel of RecoveryModel containing the properties associated with the specified request.</param>
        /// <param name="reservedTransaction">Transaction which has the reserved status</param>
        /// <param name="transtionInProcess">TransactionInProcess which has the reserved transction reference information</param>
        /// <returns>RecoveryModel with transaction information</returns>
        private async Task<ApiItemModel<RecoveryModel>> AnalizeRescueTransactions(ApiItemModel<RecoveryModel> request, ApiItemModel<CaTransactionModel> reservedTransaction, ApiItemModel<TransactionInProcessModel>  transtionInProcess)
        {
            var recoveryResponse = new ApiItemModel<RecoveryModel>(request);
            if(!recoveryResponse.Item.IsStale || reservedTransaction.Item.RunDateTime.HasValue && (DateTime.UtcNow - reservedTransaction.Item.RunDateTime).Value.TotalSeconds < StaleDuration)
            {
                ApiItemModel<CaTransactionModel> RecoveredResponses = await PerpareRescue(reservedTransaction, request.Item.RecoveryAction);
                recoveryResponse = await ExecuteRescue(RecoveredResponses, reservedTransaction, recoveryResponse);
            }
            if (recoveryResponse.Item.RecoveryStatus == TransactionStatus.Success)
            {
                try
                {
                    await _transactionInProcessManager.DeleteTransactionInProcessAsync(transtionInProcess);
                }
                catch(Exception ex)
                {
                    var message = "Unhandled exception while processing deleting transactionInProcess";
                    var error = _splunkManager.InitializeAndLogException(recoveryResponse.Identification, _logFilePath, message, ex);
                    recoveryResponse.Errors.Add(error);
                }
            }
            return recoveryResponse;
        }

        /// <summary>
        /// ExecuteRescue will update the transaction information based on the recovered responses or lookup reponse data
        /// </summary>
        /// <param name="RecoveredResponses">Existing Transaction Reponse or Lookup reponse data</param>
        /// <param name="ReservedTransaction">Earlier executed Transaction</param>
        /// <param name="response">RecoveryModel object that created from the request</param>
        /// <returns>RecoveryModel with the updated data of the recovery reponse</returns>
        private async Task<ApiItemModel<RecoveryModel>> ExecuteRescue(ApiItemModel<CaTransactionModel> RecoveredResponses, ApiItemModel<CaTransactionModel> ReservedTransaction, ApiItemModel<RecoveryModel> response)
        {
            var recoveryStatus = TransactionStatus.Failure;
            var recoveryResponse = new ApiItemModel<RecoveryModel>(response);

            if (!RecoveredResponses.HasErrors && !string.IsNullOrWhiteSpace(RecoveredResponses.Item.Eft))
            {
                ReservedTransaction.Item.Vehicle = RecoveredResponses.Item.Vehicle;
                ReservedTransaction.Item.Eft = RecoveredResponses.Item.Eft;
                ReservedTransaction.Item.CertificationDate = RecoveredResponses.Item.CertificationDate;
                ReservedTransaction.Item.Registration = RecoveredResponses.Item.Registration;
                recoveryStatus = TransactionStatus.Success;
            }
            else
            {
                ReservedTransaction.Errors = RecoveredResponses.Errors;
                recoveryStatus = TransactionStatus.Failure;
            }

            if (!IsRecoverableError(ReservedTransaction.Errors))
            {
                recoveryResponse = await RescueInventory(ReservedTransaction, recoveryResponse);
            }

            try
            {
                recoveryResponse.Item.RecoveryResponse = new List<CaTransactionModel>();
                recoveryResponse.Item.RecoveryResponse.Add(ReservedTransaction.Item);
                var transactionStatus = recoveryStatus;
                if (response.Item.RecoveryAction == "Release" && transactionStatus == TransactionStatus.Failure)
                {
                    recoveryStatus = TransactionStatus.Success;
                }
                recoveryResponse = await SetRecoveryTransactionStatus(ReservedTransaction.Item, transactionStatus, recoveryResponse);
            }
            catch (Exception ex)
            {
                var message = "Unhandled exception while processing recovery transaction inquriy";
                var error = _splunkManager.InitializeAndLogException(recoveryResponse.Identification, _logFilePath, message, ex);
                recoveryResponse.Errors.Add(error);
                recoveryStatus = TransactionStatus.Failure;
            }

            recoveryResponse.Item.RecoveryStatus = recoveryStatus;
            return recoveryResponse;
        }

        /// <summary>
        /// RescueInventory used to recover Inventory items based on the transaction rescue
        /// </summary>
        /// <param name="reservedTransactionItem">Earlier executed Transaction Item</param>
        /// <param name="response">RecoveryModel object that created from the request</param>
        /// <returns>RecoveryModel with the updated data of the inventory reponse</returns>
        private async Task<ApiItemModel<RecoveryModel>> RescueInventory(ApiItemModel<CaTransactionModel> reservedTransactionItem, ApiItemModel<RecoveryModel> response)
        {
            List<string> inventoryItems = new List<string>();
            var recoveryResponse = new ApiItemModel<RecoveryModel>(response);
            if (!string.IsNullOrEmpty(reservedTransactionItem.Item.Registration.Plate))
            {
                inventoryItems.Add(reservedTransactionItem.Item.Registration.Plate);
            }
            if (!string.IsNullOrEmpty(reservedTransactionItem.Item.Registration.Sticker))
            {
                inventoryItems.Add(reservedTransactionItem.Item.Registration.Sticker);
            }

            if (inventoryItems.Count > 0)
            {
                var invRequest = new ApiListModel<InventoryQueryModel>();
                invRequest.Identification = new IdentificationModel(response.Identification);
                invRequest.Filters = new List<FilterModel>
                {
                    new FilterModel
                    {
                        FieldName = "Control",
                        Value = reservedTransactionItem.Item.Control
                    },
                    new FilterModel
                    {
                        FieldName = "Serial",
                        Values = inventoryItems
                    }
                };

                recoveryResponse = await UpdateInventoryStatus(reservedTransactionItem, recoveryResponse, invRequest);
            }
            return recoveryResponse;
        }

        /// <summary>
        /// UpdateInventoryStatus will update the status based on the recovery status of the transaction
        /// </summary>
        /// <param name="reservedTransactionItem">Earlier executed Transaction Item</param>
        /// <param name="response">RecoveryModel object that created from the request</param>
        /// <param name="invRequest">InventoryQueryModel object that contains transaction plate/sticker</param>
        /// <returns>RecoveryModel with the updated data of the inventory status reponse</returns>
        private async Task<ApiItemModel<RecoveryModel>> UpdateInventoryStatus(ApiItemModel<CaTransactionModel> reservedTransactionItem, ApiItemModel<RecoveryModel> response, ApiListModel<InventoryQueryModel> invRequest)
        {
            var inventoryResponse = await _inventoryManager.GetInventoryListAsync("CA", invRequest);
            var recoveryResponse = new ApiItemModel<RecoveryModel>(response);
            if (inventoryResponse.HasErrors)
            {
                response.Errors.Add(new ErrorModel(false, true, false, ErrorSeverityEnum.Fatal, $"Unable to recover the transaction inventory items for control: {reservedTransactionItem.Item.Control}"));
                response.Errors.AddRange(inventoryResponse.Errors);
            }
            else
            {
                var inventoryUpdateResponse = new ApiItemModel<RecoveryModel>(response);
                foreach (var item in inventoryResponse?.Items)
                {
                    inventoryUpdateResponse = await PrepareAndUpdateInventoryStatus(item, reservedTransactionItem, recoveryResponse);
                    recoveryResponse.Errors.AddRange(inventoryUpdateResponse.Errors);
                }
            }
            return recoveryResponse;
        }

        /// <summary>
        /// PrepareAndUpdateInventoryStatus used to update the resepective inventory item status based on the recovery status of the transaction
        /// </summary>
        /// <param name="item">InventoryModel Object that contains inventiry information</param>
        /// <param name="reservedTransactionItem">Earlier executed Transaction Item</param>
        /// <param name="response">RecoveryModel object that created from the request</param>
        /// <returns>RecoveryModel with the updated data of the inventory status reponse</returns>
        private async Task<ApiItemModel<RecoveryModel>> PrepareAndUpdateInventoryStatus(InventoryModel item, ApiItemModel<CaTransactionModel> reservedTransactionItem, ApiItemModel<RecoveryModel> response)
        {
            var recoveryResponse = new ApiItemModel<RecoveryModel>(response);
            if (item.Status != InventoryStatusEnum.IssuedFinal.Value())
            {
                ApiItemModel<InventoryUpdateStatusModel> apiInventoryModel = new ApiItemModel<InventoryUpdateStatusModel>();
                apiInventoryModel.Identification = new IdentificationModel(reservedTransactionItem.Identification);
                apiInventoryModel.Item = new InventoryUpdateStatusModel
                {
                    Status = item.Status,
                    Cmf = item.Cmf,
                    Serial = item.Serial,
                    OfficeId = item.OfficeId,
                    PoolType = item.PoolType,
                    RequestId = Guid.NewGuid().ToString(),
                    SiteId = item.SiteId,
                    State = item.State,
                    Type = item.Type
                };

                var apiInventoryModelRequest = SetInventoryStatusAndNotes(apiInventoryModel, reservedTransactionItem, item.PreviousStatus, recoveryResponse.Item.RecoveryAction);
                var updateResponse = await _inventoryManager.UpdateInventoryAsync(apiInventoryModelRequest);
                if (updateResponse.HasErrors)
                {
                    recoveryResponse.Errors.Add(new ErrorModel(false, true, false, ErrorSeverityEnum.Fatal, $"Unable to update inventory status of serial: {apiInventoryModel.Item.Serial} during transaiton being completed."));
                    recoveryResponse.Errors.AddRange(updateResponse.Errors);
                }
            }
            return recoveryResponse;
        }

        /// <summary>
        /// SetInventoryStatusAndNotes used to set the inventory status and notes based on the recovery status and action of the transaction
        /// </summary>
        /// <param name="apiInventoryModel">InventoryUpdateStatusModel object that contains the inventory model infromation</param>
        /// <param name="reservedTransactionItem">Earlier executed Transaction Item</param>
        /// <param name="PreviousStatus">Previous status of the inventory</param>
        /// <param name="RecoveryAction">Transaction rescue action to be performed</param>
        /// <returns>RecoveryModel with the updated data of the inventory status and notes reponse</returns>
        private ApiItemModel<InventoryUpdateStatusModel> SetInventoryStatusAndNotes(ApiItemModel<InventoryUpdateStatusModel> apiInventoryModel, ApiItemModel<CaTransactionModel> reservedTransactionItem, string PreviousStatus, string RecoveryAction)
        {
            var apiInventoryReturnModel = new ApiItemModel<InventoryUpdateStatusModel>(apiInventoryModel);
            apiInventoryReturnModel.Item.NewStatus = PreviousStatus;
            apiInventoryReturnModel.Item.Notes = "Transaction Recovery process";
            if(RecoveryAction == "Accept" && reservedTransactionItem.Item.TransactionOperation == TransactionOperation.Complete)
            {
                apiInventoryReturnModel.Item.NewStatus = InventoryStatusEnum.IssuedFinal.Value();
                apiInventoryReturnModel.Item.Notes = "Transaction Completed";
            }
            else if(RecoveryAction == "Release")
            {
                apiInventoryReturnModel.Item.NewStatus = InventoryStatusEnum.Available.Value();
                apiInventoryReturnModel.Item.Notes = "Transaction Recovery with release action";
            }

            return apiInventoryReturnModel;
        }

        /// <summary>
        /// PerpareRescue will perform the lookup and set transaction status to be success or failure
        /// </summary>
        /// <param name="ReservedTransaction">Transaction which has the reserved status</param>
        /// <param name="rescueAction">Recovery action which we need to perform Release or Accept</param>
        /// <returns>RecoveryModel with transaction information</returns>
        private async Task<ApiItemModel<CaTransactionModel>> PerpareRescue(ApiItemModel<CaTransactionModel> ReservedTransaction, string rescueAction)
        {
            var response = new ApiItemModel<CaTransactionModel>();
            ApiListModel<CaTransactionModel> RecoveredResponses = new ApiListModel<CaTransactionModel>();

            response = PrepareError(rescueAction);
            var replayIsMatchingResponse = IsReplayMatchTransaction(ReservedTransaction);
            if (rescueAction != "Release" && replayIsMatchingResponse == true)
            {
                RecoveredResponses.Items.Add(ReservedTransaction.Item);
                response = ReservedTransaction;
            }
            else if (rescueAction != "Release" && RecoveredResponses.Items.Count == 0 && !IsOriginalTransaction(ReservedTransaction.Item.TransactionType))
            {
                ApiItemModel<CaTransactionModel> lookupResponse = await CheckAndRunLookup(ReservedTransaction, rescueAction);
                response = lookupResponse;
            }
            
            return response;
        }

        /// <summary>
        /// CheckAndRunLookup will use to validate the existing records and run the lookup as needed
        /// </summary>
        /// <param name="reservedTransaction">Transaction which has the reserved status</param>
        /// <param name="rescueAction">Recovery action which we need to perform Release or Accept</param>
        /// <returns>CaTransactionModel item model with reponse object</returns>
        private async Task<ApiItemModel<CaTransactionModel>> CheckAndRunLookup(ApiItemModel<CaTransactionModel> reservedTransaction, string rescueAction)
        {
            bool hasTIP = false;
            var vinInquiryRequest = new ApiItemModel<CaTransactionModel>();
            var plateInquiryRequest = new ApiItemModel<CaTransactionModel>();

            vinInquiryRequest.Item = new CaTransactionModel
            {
                TransactionType = TransactionType.VehicleInquiry,
                TransactionOperation = TransactionOperation.Online,
                Vehicle = new CaVehicleModel
                {
                    Vin = reservedTransaction.Item.Vehicle.Vin
                }
            };

            plateInquiryRequest.Item = new CaTransactionModel
            {
                TransactionType = TransactionType.VehicleInquiry,
                TransactionOperation = TransactionOperation.Online,
                Registration = new CaRegistrationModel
                {
                   Plate  = reservedTransaction.Item.Registration.Plate
                }
            };
            ApiItemModel<CaTransactionModel> inquiryTransactionResponse = new ApiItemModel<CaTransactionModel>();
            

            var vinInquiryResponse = await _transactionManager.GetLatestTransactionAsync(vinInquiryRequest);
            var plateInquiryResponse = await _transactionManager.GetLatestTransactionAsync(plateInquiryRequest);


            if (vinInquiryResponse.Item.RunDateTime?.ToString("yyyyMMdd") == DateTime.Now.ToString("yyyyMMdd"))
            {
                hasTIP = true;
                inquiryTransactionResponse = vinInquiryResponse;
            }
            else if(plateInquiryResponse.Item.RunDateTime?.ToString("yyyyMMdd") == DateTime.Now.ToString("yyyyMMdd"))
            {
                hasTIP = true;
                inquiryTransactionResponse = plateInquiryResponse;
            }

            if (!hasTIP)
            {
                var inquiryRequest = new ApiItemModel<CaTransactionModel>();
                inquiryRequest.Item = reservedTransaction.Item;
                inquiryRequest.Item.TransactionType = TransactionType.VehicleInquiry;
                inquiryRequest.Item.TransactionOperation = TransactionOperation.Online;
                try
                {

                    inquiryRequest.Item.VehicleOnlineInquiryRequest = GetOnlineInquiryRequest(inquiryRequest);
                    inquiryRequest.Item.VehicleOnlineInquiryRequest.Vin = inquiryRequest.Item.Vehicle.Vin;
                    inquiryTransactionResponse = (ApiItemModel<CaTransactionModel>) await _transactionServiceController.Submit(inquiryRequest);

                    if(inquiryTransactionResponse.HasErrors)
                    {
                        inquiryRequest.Item.VehicleOnlineInquiryRequest.Vin = null;
                        inquiryRequest.Item.VehicleOnlineInquiryRequest.Plate = inquiryRequest.Item.Registration.Plate;
                        inquiryTransactionResponse = (ApiItemModel<CaTransactionModel>)await _transactionServiceController.Submit(inquiryRequest);
                    }
                    hasTIP = true;
                }
                catch (Exception ex)
                {
                    var message = "Unhandled exception while processing recovery transaction inquriy";
                    var error = _splunkManager.InitializeAndLogException(inquiryRequest.Identification, _logFilePath, message, ex);
                    inquiryTransactionResponse.Errors.Add(error);
                }

                inquiryTransactionResponse = PrepareError(rescueAction);
            }

            return inquiryTransactionResponse;
        }

        /// <summary>
        /// PrepareError will create the BPA system down error
        /// </summary>
        /// <returns>CaTransactionModel item model with reponse object</returns>
        private ApiItemModel<CaTransactionModel> PrepareError(string rescueAction)
        {
            ApiItemModel<CaTransactionModel> errorTransaction = new ApiItemModel<CaTransactionModel>();
            if (rescueAction != "Accept")
            {
                errorTransaction.Errors.Add(new ErrorModel(true, false, true, ErrorSeverityEnum.Fatal,
                        "Q023 BPA system temporarily unavailable.", new string[] { }));
            }
            return errorTransaction;
        }

        /// <summary>
        /// Use to analize matching transaction existing or not
        /// </summary>
        /// <param name="reservedTransactionItem">Transaction which has the reserved status</param>
        /// <returns>Returns the Matching transaction for recover</returns>
        private bool IsReplayMatchTransaction(ApiItemModel<CaTransactionModel> reservedTransactionItem)
        {
            bool isRecoverableError = IsRecoverableError(reservedTransactionItem.Errors);
            return !(reservedTransactionItem.HasErrors && isRecoverableError
                && (reservedTransactionItem.Errors.Any(error => (error.Message.Contains("Q023") || error.IsStateError == true)) || reservedTransactionItem.Item.Report.PrintData.Count() == 0));
        }

        /// <summary>
        /// Use to define either original transaction or not
        /// </summary>
        /// <param name="transactionType">Reserved Tranasction Type</param>
        /// <returns>Return the eigther original transaction or not</returns>
        private bool IsOriginalTransaction(string transactionType)
        {
            string[] NewIssueTransactions =
            {
                TransactionType.NewIssue,
                TransactionType.NewIssueOutOfStock
            };
            string[] OrignalTransactions = NewIssueTransactions.Union(TransactionType.TransferTransactions).Union(TransactionType.TransferReissueWithoutRenewal)
                .Union(TransactionType.RenewalTransactions).Union(TransactionType.RegistrationOnlyTransactions).Union(TransactionType.ReissueTransactions).ToArray();

            return OrignalTransactions.Contains(transactionType);
        }

        /// <summary>
        /// Used to check the transaction error is recoverable or not
        /// </summary>
        /// <param name="errors">Error Model List Object</param>
        /// <returns>Return the is error recoverable or not</returns>
        private bool IsRecoverableError(List<ErrorModel> errors)
        {
            bool recoverableError = false;

            foreach(var error in errors)
            {
                if (error.IsStateError && (error.Message.Contains("BPA system down") || error.Message.Contains("x3270 error")
                    || error.Message.Contains("BPA vpn down") || error.Message.Contains("unkown communication error") || error.Message.Contains("soap execution error")))
                {
                    recoverableError = true;
                }
            }

            return recoverableError;
        }

        /// <summary>
        /// Used to create the CVR Requester code based Vehicle Inquiry
        /// </summary>
        /// <param name="inquiryRequest">CaTransactionModel item model to prepare the inquiryRequest</param>
        /// <returns>Returning VehicleOnlineInquiryRequestModel with Online inquiry request information</returns>
        private VehicleOnlineInquiryRequestModel GetOnlineInquiryRequest(ApiItemModel<CaTransactionModel> inquiryRequest)
        {
            return new VehicleOnlineInquiryRequestModel
            {
                RequesterCode = _appConfigModel.CVRCAInquriyReqesterCode,
                User = inquiryRequest.Identification.UserId,
                Purpose = "99"
            };
        }

        /// <summary>
        /// Updated the status of the transaction based in the inquriy response
        /// </summary>
        /// <param name="reservedTransaction">Transaction which has the reserved status</param>
        /// <param name="recoveryStatus">Transaction status based on the recovery inquiry</param>
        /// <param name="response">RecoveryModel object that created from the request</param>
        /// <returns>Returning ApiItem of Recovery model transaction status</returns>
        private async Task<ApiItemModel<RecoveryModel>> SetRecoveryTransactionStatus(CaTransactionModel reservedTransaction, string recoveryStatus, ApiItemModel<RecoveryModel> response)
        {
            var request = new ApiItemModel<CaTransactionModel>();
            var recoveryResponse = new ApiItemModel<RecoveryModel>(response);
            request.Identification = recoveryResponse.Identification;
            request.Item = reservedTransaction;
            request.Item.TransactionStatus = recoveryStatus;
            try
            {
                await _transactionManager.SaveTransactionAsync(request);
            }
            catch (Exception ex)
            {
                var message = "Unhandled exception while processing save transaction with reservedTransaction";
                var error = _splunkManager.InitializeAndLogException(recoveryResponse.Identification, _logFilePath, message, ex);
                recoveryResponse.Errors.Add(error);
            }

            return recoveryResponse;
        }

        /// <summary>
        /// Validates a RecoveryModel to ensure all required fields exist
        /// for writting a RecoveryModel record.
        /// </summary>
        /// <param name="request">RecoveryModel object containing the data associated with a RecoveryModel.</param>
        /// <returns>return RecoveryModel response </returns>
        private ApiItemModel<RecoveryModel> ValidateRescueRequest(ApiItemModel<RecoveryModel> request)
        {
            var response = new ApiItemModel<RecoveryModel>(request);

            if (request.Identification == null || (request.Item.IsForce && (string.IsNullOrWhiteSpace(request.Item.Control))) || ((string.IsNullOrWhiteSpace(request.Item.Control) || string.IsNullOrWhiteSpace(request.Item.RecoveryAction)) && !request.Item.IsStale && !request.Item.IsForce))
            {
                var parameters = new List<string>();
                if (string.IsNullOrEmpty(request.Item.Control))
                {
                    parameters.Add("Control");
                }

                if (string.IsNullOrEmpty(request.Item.RecoveryAction) && !request.Item.IsForce)
                {
                    parameters.Add("RecoveryAction");
                }

                if (request.Identification == null || string.IsNullOrEmpty(request.Identification.UserId))
                {
                    parameters.Add("Identification.UserId");
                }

                response.Errors.Add(new ErrorModel(false, false, true, ErrorSeverityEnum.Fatal, "Missing required parameter or request as stale/force.", parameters.ToArray()));
            }

            return response;
        }

        /// <summary>
        /// Used to load the full path name of the exception file for logging purposes.
        /// </summary>
        private void LoadSettings()
        {
            var response = _settingsManager.ReadAsync("CA", "Logging", "Exceptions").Result;
            if (response != null)
            {
                var setting = JsonConvert.DeserializeObject<PathSetting>(response.Item.Settings.AsJsonString());
                _tmpLogPath = setting.Path;
            }
        }

        /// <summary>
        /// Mock the rescue reponse for Accept/Release
        /// </summary>
        /// <param name="rescueRequest"></param>
        /// <returns></returns>
        private async Task<ApiItemModel<RecoveryModel>> MockResponse(ApiItemModel<RecoveryModel> rescueRequest)
        {
            var response = new ApiItemModel<RecoveryModel>(rescueRequest);

            if (rescueRequest.Item.RecoveryAction == "Accept")
            {
                response = await ReturnMockAcceptResponse(response);
            }
            else if(rescueRequest.Item.RecoveryAction == "Release")
            {
                response = await ReturnMockReleaseResponse(response);
            }

            return response;
        }

        /// <summary>
        /// Mock for release response
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        private Task<ApiItemModel<RecoveryModel>> ReturnMockReleaseResponse(ApiItemModel<RecoveryModel> response)
        {
            CaTransactionModel caTransactionModel = GetCaTransactionModel();
            response.Item.RecoveryResponse.Add(caTransactionModel);
            return Task.FromResult(response);
        }

        /// <summary>
        /// Mock for accept response
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        private Task<ApiItemModel<RecoveryModel>> ReturnMockAcceptResponse(ApiItemModel<RecoveryModel> response)
        {
            CaTransactionModel caTransactionModel = GetCaTransactionModel();

            // Fill completed fields
            caTransactionModel.CompleteDateTime = DateTime.UtcNow;
            caTransactionModel.CaFees.AddFee("001", "59");
            caTransactionModel.CaFees.AddFee("154", "2");
            caTransactionModel.CaFees.AddFee("002", "27");
            caTransactionModel.CaFees.AddFee("316", "54");
            caTransactionModel.CaFees.AddFee("004", "150");
            caTransactionModel.CaFees.AddFee("464", "1");
            caTransactionModel.CaFees.AddFee("008", "1");
            caTransactionModel.CaFees.AddFee("031", "1");
            caTransactionModel.CaFees.AddFee("039", "6");
            caTransactionModel.CaFees.AddFee("060", "6");
            caTransactionModel.CaFees.AddFee("061", "8");
            caTransactionModel.CaFees.AddFee("085", "6");
            caTransactionModel.CaFees.AddFee("086", "1");
            caTransactionModel.CaFees.AddFee("100", "3");
            caTransactionModel.CaFees.AdjustedAmount = "325";
            caTransactionModel.CaFees.PreviousPaidAmount = "0";
            caTransactionModel.ServiceFee = "20";
            caTransactionModel.OnlineProcessingFee = "5";
            caTransactionModel.CaFees.TotalDue = "325";
            caTransactionModel.Eft = "350";
            caTransactionModel.TransactionStatus = TransactionStatus.Success;

            response.Item.RecoveryResponse.Add(caTransactionModel);

            return Task.FromResult(response);
        }

        /// <summary>
        /// Mocked CA transaction model
        /// </summary>
        /// <returns></returns>
        private CaTransactionModel GetCaTransactionModel()
        {
            var request = new CaTransactionModel();
            request.Control = Guid.NewGuid().ToString();
            request.RequestId = Guid.NewGuid().ToString();
            request.TransactionType = TransactionType.NewIssue;
            request.TransactionOperation = TransactionOperation.Complete;
            request.TransactionVersion = "V01";
            request.ProductVersion = "CCAI0100";
            request.ImportVendor.Vendor = "Manual";
            request.ImportVendor.Method = "Manual";
            request.FirstPartnerId = "V07";
            request.SecondPartnerId = "BG";
            request.Vehicle.Odometer = "3";
            request.Vehicle.OdometerBrand = "A";
            request.Vehicle.OdometerUnit = "M";
            request.Registration.Plate = "2VUA601";
            request.Vehicle.LicenseTypeCode = "11";
            request.FeeAcceptedIndc = false;
            request.Sale.PurchaseDate = DateTime.Now.ToString("yyyyMMdd");
            request.Vehicle.Vin = "4T1BF1FK6CU154890";
            request.DealerDismantlerNumber = "1";
            request.Registration.Sticker = "X0000602";
            request.Vehicle.FuelType = "Gas";
            request.Vehicle.Make = "FORD";
            request.Vehicle.ModelYear = "2009";
            request.Sale.PurchasePrice = 40000;
            request.Vehicle.YearFirstSold = "2020";
            request.Vehicle.BodyStyle = "4D";
            request.Title.ReportOfSaleNumber = "12908799";
            request.Registration.InventoryCodes.Add("01R");
            request.Registration.InventoryCodes.Add("290");
            var owner = new CaOwnerModel();
            var address = new AddressBaseModel();
            address.City = "PLEASANTON";
            address.County = "1";
            address.State = "CA";
            address.StreetAddress1 = "23 ANYST";
            address.Zip = "94588";
            address.AddressType = "Residence";
            owner.DriverLicense = "N1234567";
            owner.FullName = "JOHN MILLER";
            owner.OwnerType = "Individual";
            owner.OwnerProfile = "Primary";
            owner.Addresses.Add(address);
            request.Owners.Add(owner);

            return request;
        }
    }
}
