﻿using System.Collections.Generic;
using cdk.evr.converge.cbe.ca.Models;
using cdk.evr.converge.cbe.common.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiController]
    public class InfoController : ControllerBase, IInfoController
    {
        private List<SystemInformationModel> _associatedSystems;

        public InfoController(IConfiguration configuration)
        {
            _associatedSystems = (List<SystemInformationModel>)configuration.GetSection("AssociatedSystems").Get(typeof(List<SystemInformationModel>));
        }

        /// <summary>
        /// Used to get a list of systems associated with this environent with a
        /// status indicating if we can communicate with them ("Up" or "Down").
        /// </summary>
        /// <returns>ActionResult with a list of system names and statuses.</returns>
        [HttpGet]
        public ActionResult<List<SystemInformationModel>> GetSystemStatus()
        {
            if (_associatedSystems == null)
            {
                return StatusCode(500, "Missing AssociatedSystems configuration.");
            }

            foreach (var system in _associatedSystems)
            {
                if (PingUtility.PingServer(system.Address))
                {
                    system.Status = "Up";
                }
                else
                {
                    system.Status = "Down";
                }
            }

            return Ok(_associatedSystems);
        }
    }
}

