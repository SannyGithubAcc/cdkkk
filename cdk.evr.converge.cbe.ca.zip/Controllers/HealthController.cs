﻿using cdk.evr.converge.cbe.ca.models;
using cdk.evr.converge.cbe.common.models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// Health controller. Since NGINX will be calling the Get method in this Controller for monitoring purposes, it is very important to
    /// keep this controller light and independent of any other calls.
    /// </summary>
    [Produces("application/json")]
    [Route("[controller]")]
    public class HealthController : Controller, IHealthController
    {
        /// <summary>
        /// Returns the health status of the application/database.
        /// This will be called by front office NGINX for monitoring purposes
        /// </summary>
        [HttpGet]
        public HealthResultModel Get()
        {
            HealthResultModel result = new HealthResultModel() { Status = "UP", Name = "CDK CBE CA" };

            return result;
        }
    }
}
