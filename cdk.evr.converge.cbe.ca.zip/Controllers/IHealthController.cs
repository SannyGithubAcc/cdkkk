﻿using cdk.evr.converge.cbe.common.models;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// Interface for the HealthController class.
    /// </summary>
    public interface IHealthController
    {
        /// <summary>
        /// Returns the health status of the application/database.
        /// This will be called by front office NGINX for monitoring purposes
        /// </summary>
        HealthResultModel Get();
    }
}