using System;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.ca.biz.Inventory;
using cdk.evr.converge.cbe.common;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.models.Inventory;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.ca.Controllers
{
    /// <summary>
    /// The InventoryController provides the API functions for processing a INVU Transaction.
    /// </summary>
    /// 
    [TokenAuthorizationFilter]
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase, IInventoryController
    {
        private readonly IInventoryProcessor _inventoryProcessor;
        private readonly ISplunkManager _splunkManager;
        private readonly IApplicationSettingsManager _settingsManager;
        private string _tmpLogPath = null;
        private string _logFilePath
        {
            get
            {
                if (string.IsNullOrEmpty(_tmpLogPath))
                    LoadSettings();

                return _tmpLogPath;
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="inventoryProcessor"></param>
        /// <param name="settingsManager"></param>
        /// <param name="splunkManager"></param>
        public InventoryController(IInventoryProcessor inventoryProcessor,
            IApplicationSettingsManager settingsManager,
            ISplunkManager splunkManager)
        {
            _inventoryProcessor = inventoryProcessor;
            _splunkManager = splunkManager;
            _settingsManager = settingsManager;
        }

        /// <summary>
        /// UpdateInventory is used to submit inventory status to DMV for given status and range of inventory.
        /// For single item, range start and end will indicate the single item with count being 1.
        /// </summary>
        /// <param name="request">Json string representation of a InventoryRangeUpdateModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing InventoryRangeUpdateModel object with the specified request properties and either the response properties or error objects specified.</returns>
        /// 
        [HttpPost("UpdateInventory")]
        [ProducesResponseType(typeof(ApiItemModel<InventoryRangeUpdateModel>), 200)]
        public async Task<IActionResult> UpdateInventory([FromBody] ApiItemModel<InventoryRangeUpdateModel> request)
        {
            var response = new ApiItemModel<InventoryRangeUpdateModel>(request);
            try
            {
                response = await _inventoryProcessor.UpdateInventoryWithDMV(request);
            }
            catch (Exception ex)
            {
                var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, "Unhandled exception while updating Inventory Range.", ex);
                response.Errors.Add(error);
            }

            return Ok(response);
        }

        /// <summary>
        /// ReceiveInventory is used to submit inventory receipts to DMV for given range of inventory.
        /// </summary>
        /// <param name="request">Json string representation of a InventoryRangeModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing InventoryRangeModel object with the specified request properties and either the response properties or error objects specified.</returns>
        [HttpPost("ReceiveInventory")]
        [ProducesResponseType(typeof(ApiItemModel<InventoryRangeModel>), 200)]
        public async Task<IActionResult> ReceiveInventory([FromBody] ApiItemModel<InventoryRangeModel> request)
        {
            var response = new ApiItemModel<InventoryRangeModel>(request);
            try
            {
                response = await _inventoryProcessor.ReceiveInventoryWithDMV(request);
            }
            catch (Exception ex)
            {
                var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, "Unhandled exception while receiving Inventory Range.", ex);
                response.Errors.Add(error);
            }

            return Ok(response);
        }

        /// <summary>
        /// TransferInventory is used to submit inventory out and in to DMV for given range of inventory.
        /// This will actually call internal funcitons of InventoryUpdate calls twice one for "out" from current location and the other for "in" to the target location
        /// For single item, range start and end will indicate the single item with count being 1.
        /// </summary>
        /// <param name="request">Json string representation of a InventoryRangeTransferModel containing the properties associated with the specified request.</param>
        /// <returns>ActionResult with a content containing InventoryRangeTransferModel object with the specified request properties and either the response properties or error objects specified.</returns>
        [HttpPost("TransferInventory")]
        [ProducesResponseType(typeof(ApiItemModel<InventoryRangeTransferModel>), 200)]
        public async Task<IActionResult> TransferInventory([FromBody] ApiItemModel<InventoryRangeTransferModel> request)
        {
            var response = new ApiItemModel<InventoryRangeTransferModel>(request);
            try
            {
                response = await _inventoryProcessor.TransferInventoryWithDMV(request);
            }
            catch (Exception ex)
            {
                var error = _splunkManager.InitializeAndLogException(request.Identification, _logFilePath, "Unhandled exception while transferring Inventory Range.", ex);
                response.Errors.Add(error);
            }

            return Ok(response);
        }

        /// <summary>
        /// Used to load the full path name of the exception file for logging purposes.
        /// </summary>
        private void LoadSettings()
        {
            var response = _settingsManager.ReadAsync("CA", "Logging", "Exceptions").Result;
            if (response != null)
            {
                var setting = JsonConvert.DeserializeObject<PathSetting>(response.Item.Settings.AsJsonString());
                _tmpLogPath = setting.Path;
            }
        }

    }
}
