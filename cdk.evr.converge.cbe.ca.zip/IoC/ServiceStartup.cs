﻿using cdk.evr.converge.cbe.ca.Controllers;
using cdk.evr.converge.cbe.common.ioc;
using Microsoft.Extensions.DependencyInjection;

namespace cdk.evr.converge.cbe.ca.IoC
{

    /// <summary>
    /// Service startup.
    /// </summary>
    public class ServiceStartup : IIoCStartup
    {
        /// <summary>
        /// Configures the services.
        /// </summary>
        /// <param name="services">Services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IHealthController, HealthController>();
            services.AddTransient<ITransactionServiceController, TransactionServiceController>();
            services.AddTransient<IInventoryController, InventoryController>();
            services.AddTransient<IRescueController, RescueController>();
            services.AddTransient<IInfoController, InfoController>();
            services.AddTransient<ITokenManager, TokenManager>();
        }
    }
}