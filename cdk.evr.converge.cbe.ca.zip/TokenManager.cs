﻿using cdk.evr.converge.cbe.common;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Extensions;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.ca
{
    public class TokenManager : ITokenManager
    {
        protected readonly IApplicationSettingsManager _settingsManager; 
        public static string token = null;

        /// <summary>
        /// Constructor with dependency injection.
        /// </summary>
        /// <param name="applicationSettingsManager">IApplicationSettingsManager responseible for accessing the application_settings table.</param>
        public TokenManager(IApplicationSettingsManager applicationSettingsManager)
        {
            _settingsManager = applicationSettingsManager;
        }

        /// <summary>
        /// This method is to validate supplied token from application settings along with tokenType
        /// </summary>
        /// <returns>True if the supplied token is valid and appropriate; false otherwise.</returns>
        public bool ValidateToken(string authToken)
        {
            if (token == null)
            {
                var settingresponse = _settingsManager.ReadAsync("CA", "Authentication", "Tokens").Result;

                if (settingresponse == null || settingresponse.HasErrors)
                {
                    return false;
                }

                token = JsonConvert.DeserializeObject<CompanyTokenSetting>(settingresponse.Item.Settings.AsJsonString()).Write;
            }

            if (authToken == token)
            {
                return true;
            }

            return false;
        }
    }
}


