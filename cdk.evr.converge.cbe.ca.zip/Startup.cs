﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text.Json.Serialization;
using cdk.evr.converge.cbe.ca.Controllers;
using cdk.evr.converge.cbe.ca.Formatters;
using cdk.evr.converge.cbe.ca.models;
using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.ioc;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace cdk.evr.converge.cbe.ca
{
    /// <summary>
    /// Startup code, called part of building a web host.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        /// <summary>
        /// Application configuration containing a set of name/value pairs that
        /// represent the configuration settings.
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Constructor that sets the public Configuration property with the
        /// configuration object being passed into the constructor.
        /// </summary>
        /// <param name="configuration">IConfiguration object containing a set of name/value pairs representing the current configuration.</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services">ServiceCollection object that identifies all of the services provided by the application.  This collection is also used as part of dependency injection.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            IoCRegister.RegisterIocStartup(services, new[] { "cdk.evr.converge.cbe" });

            services.AddMvc(o => o.InputFormatters.Insert(0, new RawRequestBodyFormatter()))
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                // replacing obsolete option setting
                //  options.JsonSerializerOptions.IgnoreNullValues = true;
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            });
            var sqlConnectString = Configuration["ConnectionString"];
            services.AddDbContext<PostgreSqlContext>(options => options.UseNpgsql(sqlConnectString));
            services.AddMemoryCache();
            
            services.AddControllers();

                //Loading AppSetting to AppConfigModel properties
                var appConfig = new AppConfigModel();
            appConfig.CVRCAInquriyReqesterCode = Configuration["CVRCAInquriyRequesterCode"];
            services.AddSingleton(appConfig);
            
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "cdk.evr.converge.cbe.ca", Version = "v1" });
                c.CustomSchemaIds(type => type.ToString());
                c.AddSecurityDefinition("CvrTokenValidation", new OpenApiSecurityScheme
                {
                    Description = "Token Authorization header",
                    In = ParameterLocation.Header,
                    Name = "CvrToken",
                    Type = SecuritySchemeType.ApiKey
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                  {
                    {
                      new OpenApiSecurityScheme
                      {
                        Reference = new OpenApiReference
                          {
                            Type = ReferenceType.SecurityScheme,
                            Id = "CvrTokenValidation"
                          }
                      },
                        new string[] { }
                      }
                });
                // Include all of the xml files in our base directory to pickup the XML comments from the project as well as
                // dependencies that have XML comments.
                foreach (var xmlFile in Directory.GetFiles(AppContext.BaseDirectory, "*.xml", SearchOption.AllDirectories))
                {
                    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                    c.IncludeXmlComments(xmlPath);
                }
            });
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //    app.UseSwagger();
            //    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "cdk.evr.converge.cbe.ca v1"));
            //}

            //app.UseHttpsRedirection();

            app.UseDeveloperExceptionPage();

            //if (env.IsEnvironment("Local"))
            if (Debugger.IsAttached)
            {
                app.UseSwagger();
            }
            else // if (env.IsDevelopment() || env.IsEnvironment("QA"))
            {
                var basepath = Configuration.GetSection("BasePath").Get<string>();
                basepath = string.IsNullOrEmpty(basepath) ? string.Empty : basepath;

                // Add base path to the swagger url so that all our APIs can be accessed even in DEV and QA
                app.UseSwagger((options) =>
                {
                    options.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                    {
                        swaggerDoc.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"{httpReq.Scheme}://{httpReq.Host.Value}{basepath}" } };
                    });
                });
            }

            app.UseSwaggerUI(c => c.SwaggerEndpoint($"v1/swagger.json", "cdk.evr.converge.cbe.ca v1"));

            app.UseRouting();

            app.UseAuthorization();

            app.UseAuthentication();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
