﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.ca.models.Rescue;
using cdk.evr.converge.cbe.ca.models.Transaction;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Enumerations;
using cdk.evr.converge.cbe.common.models.Inventory;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.ca
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class TokenAuthorizationFilter : Attribute, IAuthorizationFilter
    {
        /// <summary>
        /// OnAuthorization is called before a service is run that has the [Authorize] attribute associated with
        /// it or with the class that provided the service.  OnAuthorization will check to see if the use of tokens
        /// is enable and if so, will call TokenManager.ValidateToken to ensure the token is valid.  If not and
        /// if the request is a known type, then an error model will be added to the Errors list and returned;
        /// otherwise, Forbidden will be returned with an authentication failure message.
        /// </summary>
        /// <param name="filterContext">AuthorizationFilterContext containing the HttpContext information.</param>
        public async void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            var _tokenManager = (ITokenManager)filterContext.HttpContext.RequestServices.GetService(typeof(ITokenManager));
            var _configuration = (IConfiguration)filterContext.HttpContext.RequestServices.GetService(typeof(IConfiguration));
            if (filterContext != null)
            {
                bool enableToken = bool.Parse(_configuration.GetSection("TokenSettings:EnableToken").Value);
                if (!enableToken)
                {
                    return;
                }

                Microsoft.Extensions.Primitives.StringValues authTokens;
                filterContext.HttpContext.Request.Headers.TryGetValue("CvrToken", out authTokens);
                var _token = authTokens.FirstOrDefault();
                if (_token != null && _tokenManager.ValidateToken(_token))
                {
                    return;
                }

                var errorMessage = "Unable to process request, authentication failure.";
                var request = filterContext.HttpContext.Request;
                var path = filterContext.HttpContext.Request.Path.Value;
                var res = await DeserializeObject(request, path, errorMessage);
                if (res == null)
                {
                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                    filterContext.Result = new JsonResult(errorMessage)
                    {
                        Value = new
                        {
                            Status = errorMessage,
                            Message = res,
                        }
                    };
                }
                else
                {
                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.OK;
                    filterContext.Result = new JsonResult(res)
                    {
                        Value = res
                    };
                }
            }
        }

        /// <summary>
        /// Used to deserialize the request object and if it is a known type (ApiItemModel object)
        /// then add an ErrorModel object to the Errors list; otherwise, return null.
        /// </summary>
        /// <param name="request">HttpRequest object containing the request that was submitted to the service.</param>
        /// <param name="path">String representing the path of the service in the URL.</param>
        /// <param name="errorMessage">String representing the error message to return to the user.</param>
        /// <returns>Dynamic object representing the new response object to be returned or null if the type was not recognized.</returns>
        private static async Task<dynamic> DeserializeObject(Microsoft.AspNetCore.Http.HttpRequest request, string path, string errorMessage)
        {
            dynamic res;
            using (var reader = new StreamReader(request.Body))
            {
                var content = await reader.ReadToEndAsync();
                if (path == "/api/Inventory/UpdateInventory")
                {
                    res = JsonConvert.DeserializeObject<ApiItemModel<InventoryRangeUpdateModel>>(content);
                }
                else if (path == "/api/Inventory/ReceiveInventory")
                {
                    res = JsonConvert.DeserializeObject<ApiItemModel<InventoryRangeModel>>(content);
                }
                else if (path == "/api/Inventory/TransferInventory")
                {
                    res = JsonConvert.DeserializeObject<ApiItemModel<InventoryRangeTransferModel>>(content);
                }
                else if (path == "/api/Rescue/TransactionRescue")
                {
                    res = JsonConvert.DeserializeObject<ApiItemModel<RecoveryModel>>(content);
                }
                else if (path == "/api/TransactionService")
                {
                    res = JsonConvert.DeserializeObject<ApiItemModel<CaTransactionModel>>(content);
                }
                else
                {
                    return null;
                }
            }

            res.Errors.Add(new ErrorModel(false, false, true, ErrorSeverityEnum.Fatal, errorMessage));
            return res;
        }
    }
}


