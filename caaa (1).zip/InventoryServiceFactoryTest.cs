﻿using System;
using System.Diagnostics.CodeAnalysis;
using cdk.evr.converge.cbe.common.Factory;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TestUtilities;

namespace cdk.evr.converge.cbe.common.tests
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class InventoryServiceFactoryTest : TestStartup
    {
        private readonly IInventoryServiceFactory _inventoryServiceFactory;
        private readonly IMemoryCache _memoryCache;

        public InventoryServiceFactoryTest()
        {
            _memoryCache = new MemoryCache(new MemoryCacheOptions());
            var settingsManagerMock = new ApplicationSettingsManager(new MockedApplicationSettingsProvider().GetMocked(), _memoryCache);
            var splunkManagerMock = new Mock<ISplunkManager>();
            _inventoryServiceFactory = new InventoryServiceFactory(settingsManagerMock, splunkManagerMock.Object);
        }

        [TestMethod]
        [DataRow("CA", "TransferInventory", "TransferInventoryWithDMV")]
        [DataRow("CA", "UpdateInventory", "UpdateInventoryWithDMV")]
        [DataRow("CA", "Unknown", null)]
        public void GetInventoryServiceURLTest(string state, string action, string expectedUrl)
        {
            try
            {
                string url = _inventoryServiceFactory.GetInventoryServiceURL(state, action);
                Assert.AreEqual(expectedUrl, url);
            }
            catch (Exception ex)
            {
                Assert.Fail("Unhandled exception occured" + ex.Message);
            }

        }


    }
}
