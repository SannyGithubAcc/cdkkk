﻿using cdk.evr.converge.cbe.common.nacha.Eft;
using cdk.evr.converge.cbe.common.dal.Models;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.nacha;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using TestUtilities;

namespace cdk.evr.converge.cbe.common.ach.avrs.tests
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class NACHAGeneratorTest : TestStartup
    {
        private readonly Mock<ITransactionProvider> _transactionProviderMock;
        private readonly Mock<IMiscellaneousChargesProvider> _miscellaneousChargesProviderMock;
        private readonly Mock<ICmfEftManager> _cmfEftManagerMock;
        private readonly Mock<IStateManager> _stateManagerMock;
        private readonly IFileWriter _fileWriter;
        private readonly INACHAGenerator _nachaGenerator;
        private readonly Mock<IFeeSummaryProvider> _feeSummaryProviderMock;

        public NACHAGeneratorTest()
        {
            _transactionProviderMock = new Mock<ITransactionProvider>();
            _miscellaneousChargesProviderMock = new Mock<IMiscellaneousChargesProvider>();
            _cmfEftManagerMock = new Mock<ICmfEftManager>();
            _stateManagerMock = new Mock<IStateManager>();
            _fileWriter = new FileWriter();

            var memoryCache = new MemoryCache(new MemoryCacheOptions());
            var context = new PostgreSqlContextMock().GetMocked();
            var settingsManager = new ApplicationSettingsManager(new ApplicationSettingsProvider(context), memoryCache);
            var splunkManager = new SplunkManager();
            _feeSummaryProviderMock = new Mock<IFeeSummaryProvider>();
            _nachaGenerator = new NACHAGenerator(_transactionProviderMock.Object, _miscellaneousChargesProviderMock.Object,
                _cmfEftManagerMock.Object, _stateManagerMock.Object, _fileWriter, _feeSummaryProviderMock.Object, splunkManager, settingsManager);
        }

        [TestMethod]
        public async Task TestGenerateNACHAFile_WithNullDateRange()
        {
            //Arrange
            _transactionProviderMock.Setup(x => x.ReadCompletedByStateEftModelAndDateRangeAsync(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<string>())).ReturnsAsync(BuildTransactionRecords());
            _miscellaneousChargesProviderMock.Setup(x => x.ReadByStateAndEftModelFSPAsync(It.IsAny<string>(), It.IsAny<List<FilterModel>>(), It.IsAny<List<SortModel>>(), It.IsAny<PageModel>(), It.IsAny<string>())).ReturnsAsync(BuildMiscellaneousChargesRecords());
            _cmfEftManagerMock.Setup(x => x.ReadByCmfAsync(It.IsAny<string>())).ReturnsAsync(BuildCmfEftModel());
            _stateManagerMock.Setup(x => x.ReadByBillingModelAndBillingType(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(BuildStateModels());
            string path = Assembly.GetExecutingAssembly().Location + @"\NACHAFile.Txt";

            //Act
            await _nachaGenerator.GenerateNACHAFile(path, null, null);

            //Assert
            Assert.IsNotNull(_fileWriter);
            Assert.IsFalse(_nachaGenerator.Debug);
        }

        [TestMethod]
        public async Task TestGenerateNACHAFile()
        {
            //Arrange
            _transactionProviderMock.Setup(x => x.ReadCompletedByStateEftModelAndDateRangeAsync(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<string>())).ReturnsAsync(BuildTransactionRecords());
            _miscellaneousChargesProviderMock.Setup(x => x.ReadByStateAndEftModelFSPAsync(It.IsAny<string>(), It.IsAny<List<FilterModel>>(), It.IsAny<List<SortModel>>(), It.IsAny<PageModel>(), It.IsAny<string>())).ReturnsAsync(BuildMiscellaneousChargesRecords());
            _cmfEftManagerMock.Setup(x => x.ReadByCmfAsync(It.IsAny<string>())).ReturnsAsync(BuildCmfEftModel());
            _stateManagerMock.Setup(x => x.ReadByBillingModelAndBillingType(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(BuildStateModels());
            string path = Directory.GetCurrentDirectory() + @"\NACHAFile.Txt";

            //Act
            await _nachaGenerator.GenerateNACHAFile(path, DateTime.Now.AddDays(-1), DateTime.Now);

            //Assert
            Assert.IsNotNull(_fileWriter);
            Assert.IsFalse(_nachaGenerator.Debug);
        }

        [TestMethod]
        public async Task GenerateNachaFileShouldHandleNoStatesFound()
        {
            _stateManagerMock.Setup(x => x.ReadByBillingModelAndBillingType(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(new ApiListModel<StateModel>());
            string path = Directory.GetCurrentDirectory() + @"\NACHAFile.Txt";

            await _nachaGenerator.GenerateNACHAFile(path, DateTime.Now.AddDays(-1), DateTime.Now);

            Assert.IsNotNull(_fileWriter);
        }

        [TestMethod]
        public async Task TestGenerateNACHAFileForGrandTotalValueShouldSucceed()
        {
            //Arrange
            _stateManagerMock.Setup(x => x.ReadByBillingModelAndBillingType(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(BuildStateModels());
            _transactionProviderMock.Setup(x => x.ReadCompletedByStateEftModelAndDateRangeAsync(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<string>())).ReturnsAsync(BuildTransactionRecords());
            _miscellaneousChargesProviderMock.Setup(x => x.ReadByStateAndEftModelFSPAsync(It.IsAny<string>(), It.IsAny<List<FilterModel>>(), It.IsAny<List<SortModel>>(), It.IsAny<PageModel>(), It.IsAny<string>())).ReturnsAsync(BuildMiscellaneousChargesRecords());
            _cmfEftManagerMock.Setup(x => x.ReadByCmfAsync(It.IsAny<string>())).ReturnsAsync(BuildCmfEftModel());
            _feeSummaryProviderMock.Setup(x => x.ReadByStateWorkDateAsync(It.IsAny<string>(), It.IsAny<DateTime>())).ReturnsAsync(111.04M);

            string path = Directory.GetCurrentDirectory() + @"\NACHAFile.Txt";

            //Act
            var result = await _nachaGenerator.GenerateNACHAFile(path, DateTime.Now.AddDays(-1), DateTime.Now);

            //Assert
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public async Task TestGenerateNACHAFileForGrandTotalValueShouldFailForDispreancies()
        {
            //Arrange
            _stateManagerMock.Setup(x => x.ReadByBillingModelAndBillingType(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(BuildStateModels());
            _transactionProviderMock.Setup(x => x.ReadCompletedByStateEftModelAndDateRangeAsync(It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<string>())).ReturnsAsync(BuildTransactionRecords());
            _miscellaneousChargesProviderMock.Setup(x => x.ReadByStateAndEftModelFSPAsync(It.IsAny<string>(), It.IsAny<List<FilterModel>>(), It.IsAny<List<SortModel>>(), It.IsAny<PageModel>(), It.IsAny<string>())).ReturnsAsync(BuildMiscellaneousChargesRecords());
            _cmfEftManagerMock.Setup(x => x.ReadByCmfAsync(It.IsAny<string>())).ReturnsAsync(BuildCmfEftModel());
            _feeSummaryProviderMock.Setup(x => x.ReadByStateWorkDateAsync(It.IsAny<string>(), It.IsAny<DateTime>())).ReturnsAsync(172.44m);

            string path = Directory.GetCurrentDirectory() + @"\NACHAFile.Txt";

            //Act
            var result = await _nachaGenerator.GenerateNACHAFile(path, DateTime.Now.AddDays(-1), DateTime.Now);

            //Assert
            Assert.AreEqual(result, false);
        }

        private List<TransactionDbModel> BuildTransactionRecords()
        {
            var result = new List<TransactionDbModel>
            {
                new TransactionDbModel
                {
                    State = "CA",
                    Cmf= "CAREGS01",
                    TotalCurrentEft = "100.92",
                    Details = new List<TransactionDetailDbModel>
                    {
                        new TransactionDetailDbModel
                        {
                            TransactionDetail = JsonDocument.Parse("{\"Item\":{\"Eft\":\"7.00\",\"Control\":\"f0ceabd5-bf8e-4091-890c-4c87cb0ae2e2\",\"RequestId\":\"3d5577d2-d142-45d0-be73-ba762442a999\",\"TransactionMocking\":{\"MockingId\":null,\"UseMocking\":false,\"ReturnStatus\":null,\"ReturnMessage\":null,\"UseHostMocking\":false,\"HostMockingRecords\":[]},\"TransactionVersion\":\"V01\"},\"Errors\":[],\"HasErrors\":false,\"Identification\":{\"Cmf\":\"TEST0001\",\"State\":\"CA\",\"UserId\":\"IntegrationTest@cdk.com\",\"ClientIp\":null,\"CdkStoreId\":\"S000000100\",\"ComputerId\":\"2a3019d9-cd78-47da-9e8a-f86ac7d0093d\",\"InventorySite\":\"BG\",\"ProcessForCmf\":null,\"CdkEnterpriseId\":\"E000100\"}}")
                        }
                    }
                },
                new TransactionDbModel
                {
                    State = "CA",
                    Cmf= "CAREGS01",
                    TotalCurrentEft = "10.12",
                    Details = new List<TransactionDetailDbModel>
                    {
                        new TransactionDetailDbModel
                        {
                            TransactionDetail = JsonDocument.Parse("{\"Item\":{\"Eft\":\"7.00\",\"Control\":\"f0ceabd5-bf8e-4091-890c-4c87cb0ae2e2\",\"RequestId\":\"3d5577d2-d142-45d0-be73-ba762442a999\",\"TransactionMocking\":{\"MockingId\":null,\"UseMocking\":false,\"ReturnStatus\":null,\"ReturnMessage\":null,\"UseHostMocking\":false,\"HostMockingRecords\":[]},\"TransactionVersion\":\"V01\"},\"Errors\":[],\"HasErrors\":false,\"Identification\":{\"Cmf\":\"TEST0001\",\"State\":\"CA\",\"UserId\":\"IntegrationTest@cdk.com\",\"ClientIp\":null,\"CdkStoreId\":\"S000000100\",\"ComputerId\":\"2a3019d9-cd78-47da-9e8a-f86ac7d0093d\",\"InventorySite\":\"BG\",\"ProcessForCmf\":null,\"CdkEnterpriseId\":\"E000100\"}}")
                        }
                    }
                }
            };
            return result; ;
        }

        private ApiListModel<MiscellaneousChargesDbModel> BuildMiscellaneousChargesRecords()
        {
            ApiListModel<MiscellaneousChargesDbModel> result = new ApiListModel<MiscellaneousChargesDbModel>();
            result.Items = new List<MiscellaneousChargesDbModel>
            {
                new MiscellaneousChargesDbModel
                {
                    State = "CA",
                    Cmf = "CAREGS01",
                    TotalCurrentEft = "20.20"
                },
                new MiscellaneousChargesDbModel
                {
                    State = "CA",
                    Cmf = "CAREGS01",
                    TotalCurrentEft = "40.20"
                },

            };

            return result;
        }

        private ApiItemModel<CmfEftModel> BuildCmfEftModel()
        {
            ApiItemModel<CmfEftModel> result = new ApiItemModel<CmfEftModel>();
            result.Item = new CmfEftModel
            {
                State = "CA",
                Cmf = "CAREGS01",
                AbaNumber = "123",
                AccountNumber = "456"
            };

            return result;
        }

        private ApiListModel<StateModel> BuildStateModels()
        {
            ApiListModel<StateModel> result = new ApiListModel<StateModel>();
            var stateModel = new StateModel
            {
                State = "CA",
                Name = "Name1",
                BillingModel = "AVRS",
                AgencyInitials = "AgencyInitials",
                AgencyName = "AgencyName",
                AgencyTimezone = "AgencyTimezone",
                BillingType = "Daily",
                Eft = true,
                Ims = true,
                ImsType = "Imstype",
                Status = "Status",
                UserAgreementRequired = true
            };
            result.Items.Add(stateModel);

            return result;
        }
    }
}