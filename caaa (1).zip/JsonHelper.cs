﻿using System.IO;
using System.Text;
using System.Text.Json;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.common
{
    public static class JsonHelper
    {
        static JsonHelper()
        {
        }

        public static string Serialize(object value)
        {
            string json = JsonConvert.SerializeObject(value);
            return json;
        }

        public static T Deserialize<T>(string json)
        {
            T value = JsonConvert.DeserializeObject<T>(json);
            return value;
        }

        public static string ToJsonString(JsonDocument jdoc)
        {
            string json;
            using (var stream = new MemoryStream())
            {
                Utf8JsonWriter writer = new Utf8JsonWriter(stream, new JsonWriterOptions { Indented = true });
                jdoc.WriteTo(writer);
                writer.Flush();
                json = Encoding.UTF8.GetString(stream.ToArray());
            }

            return json;
        }
    }
}
