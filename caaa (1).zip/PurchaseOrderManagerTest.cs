﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Models;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Constants;
using cdk.evr.converge.cbe.common.models.Enumerations;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.models.Inventory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TestUtilities;

namespace cdk.evr.converge.cbe.common.tests
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class PurchaseOrderManagerTest : TestStartup
    {
        public class TestSetting
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }

        private readonly Mock<IStoresProvider> _companyProviderMock;
        private readonly Mock<IPurchaseOrderProvider> _purchaseOrderProviderMock;
        private readonly IPurchaseOrderManager _purchaseOrderManager;
        private readonly Mock<IInventoryManager> _inventoryManager;

        private readonly IPostgreSqlContext _context;
        private readonly IPurchaseOrderProvider _newPurchaseOrderProvider;
        private readonly IPurchaseOrderManager _newPurchaseOrderManager;
        private readonly IPurchaseOrderManager _poManagerForLineDetailValidation;


        public PurchaseOrderManagerTest()
        {
            _companyProviderMock = new Mock<IStoresProvider>();
            _purchaseOrderProviderMock = new Mock<IPurchaseOrderProvider>();
            _inventoryManager = new Mock<IInventoryManager>();
            var settingsManagerMock = new Mock<IApplicationSettingsManager>();
            var splunkManagerMock = new Mock<ISplunkManager>();
            splunkManagerMock.Setup(s => s.InitializeAndLogException(It.IsAny<IdentificationModel>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Exception>(), It.IsAny<object[]>())).Returns((IdentificationModel identification, string path, string message, Exception ex, object[] data) =>
            {
                return new ErrorModel(false, true, false, ErrorSeverityEnum.Fatal, message, data as string[]);
            });
            splunkManagerMock.Setup(s => s.LogErrorModel(It.IsAny<ErrorModel>(), It.IsAny<Exception>(), It.IsAny<object[]>())).Returns((ErrorModel errorModel, Exception ex, object[] data) =>
            {
                return errorModel;
            }); var settingObject = new TestSetting { Name = "Test", Value = "TestValue" };
            var setting = new ApiItemModel<ApplicationSettingsModel>
            {
                Identification = new IdentificationModel { Cmf = "TEST0001", InventorySite = "XX" },
                Item = new ApplicationSettingsModel
                {
                    State = "NONE",
                    System = "NONE",
                    Subsystem = "NONE",
                    Settings = settingObject.AsJsonDocument()
                }
            };
            settingsManagerMock
                .Setup(ip => ip.ReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(setting);

            _context = new PostgreSqlContextMock().GetMocked();

            _companyProviderMock.Setup(c => c.ReadByCmfAsync(It.IsAny<string>()))
                .ReturnsAsync(new StoresDbModel { Cmf = "TEST0001", Name = "Test Company" });

            IInventoryProvider inventoryProvider = new InventoryProvider(_context);
            IInventoryTypesProvider inventoryTypesProvider = new InventoryTypesProvider(_context);
            IInventoryPoolsProvider poolsProvider = new InventoryPoolsProvider(_context);
            IInventoryManager inventoryManager = (IInventoryManager)TestServiceProvider.GetService(typeof(IInventoryManager));

            _purchaseOrderManager = new PurchaseOrderManager(_purchaseOrderProviderMock.Object, settingsManagerMock.Object, _companyProviderMock.Object, splunkManagerMock.Object, _inventoryManager.Object, inventoryProvider, inventoryTypesProvider, poolsProvider);

            _newPurchaseOrderProvider = new PurchaseOrderProvider(_context);
            _newPurchaseOrderManager = new PurchaseOrderManager(_newPurchaseOrderProvider, settingsManagerMock.Object, _companyProviderMock.Object, splunkManagerMock.Object, _inventoryManager.Object, inventoryProvider, inventoryTypesProvider, poolsProvider);

            _poManagerForLineDetailValidation = new PurchaseOrderManager(_purchaseOrderProviderMock.Object, settingsManagerMock.Object, _companyProviderMock.Object, splunkManagerMock.Object, inventoryManager, inventoryProvider, inventoryTypesProvider, poolsProvider);

        }


        [TestMethod]
        [DataRow("zzzz", null, null, null, null, 0)]
        [DataRow("TEST0001", -2.0, 0.0, "TEST", PurchaseOrderStatus.Open, 2)]
        [DataRow("TEST0001", -5.0, 0.0, "TEST", PurchaseOrderStatus.Open, 4)]
        [DataRow("TEST0001", -5.0, 0.0, "TEST", PurchaseOrderStatus.Closed, 2)]
        public async Task POListAsyncShouldSucceed(string cmf, double? iBeginDate, double? iEndDate, string orderBy, string status, int expectedCount)
        {
            var request = new ApiListModel<POListModel>();

            request.Filters = new List<FilterModel>
            {
                { new FilterModel { FieldName = "Cmf", Value = cmf } },
                { new FilterModel { FieldName = "OrderBy", Value = orderBy} },
                { new FilterModel { FieldName = "Status", Value = status} }
            };

            if (iBeginDate != null && iEndDate != null)
            {
                DateTime? beginDate = iBeginDate == null ? null : DateTime.Now.AddDays(iBeginDate.Value).Date;
                DateTime? endDate = iEndDate == null ? null : DateTime.Now.AddDays(iEndDate.Value).Date;

                request.Filters.Add(new FilterModel { FieldName = "OrderDate", RangeFromValue = beginDate.Value.ToString("MM/dd/yyyy"), RangeToValue = endDate.Value.ToString("MM/dd/yyyy") });
            }

            var items = await _newPurchaseOrderManager.PoListAsync("CA", request);

            Assert.AreEqual(expectedCount, items.Items.Count);
        }

        [TestMethod]
        public async Task PoListAsyncShouldHandleException()
        {
            _purchaseOrderProviderMock.Setup(p => p.ReadByApiListModelAsync(It.IsAny<string>(), It.IsAny<ApiListModel<PurchaseOrderDbModel>>())).Returns((string state, ApiListModel<PurchaseOrderDbModel> record) =>
            {
                if (state == "EXCEPTION")
                {
                    throw new Exception("Exception from unit test.");
                }

                var result = new ApiListModel<PurchaseOrderDbModel>();
                result.Items = new List<PurchaseOrderDbModel>();
                return Task.FromResult(result);
            });

            var request = new ApiListModel<PurchaseOrderModel>();
            var items = await _purchaseOrderManager.PoListAsync("EXCEPTION", new ApiListModel<POListModel>());

            Assert.IsTrue(items.HasErrors);
            Assert.IsTrue(items.Errors.First().Message == "Error reading data from the purchase order table.");
        }

        [TestMethod]
        // Note, 3 below = number of recrods defined in PostgreSqlContextMock.InventoryTypes.
        [DataRow("CA", "TEST0001", 3, false)]
        [DataRow("CA", "UNKNOWN", 3, false)]
        [DataRow("XX", "UNKNOWN", 0, true)]
        public async Task GetTypesAndCounts(string state, string cmf, int expectedRecords, bool expectedError)
        {
            var items = await _newPurchaseOrderManager.GetTypesAndCountsAsync(state, cmf);

            Assert.IsTrue(items.Items.Count == expectedRecords);
            Assert.IsTrue(items.HasErrors == expectedError);
        }


        [TestMethod]
        [Ignore]
        public async Task GetTypesAndCountsIntegrationTest()
        {
            var manager = (IPurchaseOrderManager)TestServiceProvider.GetService(typeof(IPurchaseOrderManager));
            var items = await manager.GetTypesAndCountsAsync("CA", "CAWHSE07");

            Assert.IsNotNull(items);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderByIdAsync_ShouldSuccess()
        {
            //Arrange
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                Status = InventoryStatusEnum.Available.Value(),
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> { new PurchaseOrderLineItemDbModel() { QuantityOrdered = 2, InventoryType = "fuel", QuantityReceived = 1, RevisedQuantity = 1, Status = InventoryStatusEnum.Available.Value(), ItemDetails = new List<PurchaseOrderItemDetailDbModel>() { new PurchaseOrderItemDetailDbModel { } } } }
            };

            var purchaseOrderModel = new PurchaseOrderModel
            {
                Id = 1,
                OrderDate = DateTime.Now,
                Status = "A",
                OfficeId = "V07",
                SiteId = "BG",
                LineItems = new List<PurchaseOrderLineItemModel> { new PurchaseOrderLineItemModel() { QuantityOrdered = 2, InventoryType = "fuel", QuantityReceived = 1, RevisedQuantity = 1, Status = InventoryStatusEnum.Available.Value() } }
            };

            var apiItemModel = new ApiItemModel<PurchaseOrderModel>() { Item = purchaseOrderModel, Identification = { Cmf = "cmf", UserId = "CAUser" }, };
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(purchaseOrderDbModel);
            var result = await _purchaseOrderManager.GetByPurchaseOrderIdAsync(purchaseOrderModel.Id);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(!result.HasErrors);
            Assert.AreEqual("fuel", result.Item.LineItems[0].InventoryType);
            Assert.AreEqual("A", result.Item.LineItems[0].Status);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderIdAsync_ShouldFail_IfDataNotFound()
        {
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(() => null);
            //Act
            var result = await _purchaseOrderManager.GetByPurchaseOrderIdAsync(1);
            //Assert
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.AreEqual("Unble to read purchase order for id = 1", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task AsyncGetByPurchaseOrderId_ShouldFail_IfDbException()
        {
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ThrowsAsync(new InvalidOperationException());
            //Act
            var result = await _purchaseOrderManager.GetByPurchaseOrderIdAsync(1);
            //Assert
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.AreEqual("Unable to read data from the purchase order table.", result.Errors[0].Message);
        }


        [TestMethod]
        public async Task GetByPurchaseOrderListByCmfAsync_ShouldSuccess()
        {
            //Arrange
            var purchaseOrderDbModel = new List<PurchaseOrderDbModel>() { new PurchaseOrderDbModel
            {
                Id = 1,
                Status = InventoryStatusEnum.Available.Value(),
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> { new PurchaseOrderLineItemDbModel() {
                    Id = 10,
                    PurchaseOrderId = 1 ,
                    QuantityOrdered = 2,
                    InventoryType = "fuel",
                    QuantityReceived = 1,
                    RevisedQuantity = 1,
                    Status = InventoryStatusEnum.Available.Value(),
                    ItemDetails = new List<PurchaseOrderItemDetailDbModel> { new PurchaseOrderItemDetailDbModel {
                        PurchaseOrderLineItemId = 10
                    } } } }
            } };
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByCmfAsync(It.IsAny<string>()))
                .ReturnsAsync(purchaseOrderDbModel);
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFAsync("cmf");
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("fuel", result.Items[0].LineItems[0].InventoryType);
            Assert.AreEqual("A", result.Items[0].LineItems[0].Status);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderListByCmfAsync_ShouldFail_ForDBException()
        {
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByCmfAsync(It.IsAny<string>()))
                .ThrowsAsync(new InvalidOperationException());
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFAsync("cmf");
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Error reading data from the purchase order table.", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task AsyncGetByPurchaseOrderListByCmfAsync_ShouldFail_IfDataNotFound()
        {
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByCmfAsync(It.IsAny<string>()))
                .ReturnsAsync(() => new List<PurchaseOrderDbModel>());
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFAsync("cmf");
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("No purchase orders were found for CMF: cmf", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderListByCMFAsync_ShouldFail_MissingParameters()
        {
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFAsync("");
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Missing required parameter CMF.", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderByCmfandStatusAsync_ShouldSuccess()
        {
            //Arrange
            var purchaseOrderDbModel = new List<PurchaseOrderDbModel>() { new PurchaseOrderDbModel
            {
                Id = 1,
                Status = InventoryStatusEnum.Available.Value(),
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> { new PurchaseOrderLineItemDbModel() {
                    Id = 10,
                    PurchaseOrderId = 1 ,
                    QuantityOrdered = 2,
                    InventoryType = "fuel",
                    QuantityReceived = 1,
                    RevisedQuantity = 1,
                    Status = InventoryStatusEnum.Available.Value(),
                    ItemDetails = new List<PurchaseOrderItemDetailDbModel> { new PurchaseOrderItemDetailDbModel {
                        PurchaseOrderLineItemId = 10
                    } } } }
            } };
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByCmfStatusAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(purchaseOrderDbModel);
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFandStatusAsync("cmf", "A");
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("fuel", result.Items[0].LineItems[0].InventoryType);
            Assert.AreEqual("A", result.Items[0].LineItems[0].Status);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderListByCMFandStatusAsync_ShouldFail_ForNullData()
        {
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByCmfStatusAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(() => new List<PurchaseOrderDbModel>());
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFandStatusAsync("cmf", "A");
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Unable to identify purchase orders for CMF: cmf matching status: A", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderListByCMFandStatusAsync_ShouldFail_ForAnyInvalidOperation()
        {
            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByCmfStatusAsync(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new InvalidOperationException());
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFandStatusAsync("cmf", "A");
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Error reading data from the purchase order table.", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task GetByPurchaseOrderListByCMFandStatusAsync_ShouldFail_MissingParameters()
        {
            var result = await _purchaseOrderManager.GetByPurchaseOrderListByCMFandStatusAsync("", "");
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Missing required parameters: CMF,Status", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task DeletePurchaseOrderAsync_ShouldSuccess()
        {
            //Arrange;
            long id = 1;
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = id,
                Status = InventoryStatusEnum.Available.Value(),
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> { new PurchaseOrderLineItemDbModel() {
                    Id = 10,
                    PurchaseOrderId = 1 ,
                    QuantityOrdered = 2,
                    InventoryType = "fuel",
                    QuantityReceived = 1,
                    RevisedQuantity = 1,
                    Status = InventoryStatusEnum.Available.Value(),
                    ItemDetails = new List<PurchaseOrderItemDetailDbModel> { new PurchaseOrderItemDetailDbModel {
                        PurchaseOrderLineItemId = 10
                    } } } }
            };
            var record = new PurchaseOrderModel
            {
                Id = 1,
                OrderDate = DateTime.Now,
                Status = "D",
                LineItems = new List<PurchaseOrderLineItemModel> { new PurchaseOrderLineItemModel() { QuantityOrdered = 2, InventoryType = "fuel", QuantityReceived = 1, RevisedQuantity = 1, Status = InventoryStatusEnum.Available.Value(), } }
            };
            // act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(purchaseOrderDbModel);

            // set up the repository’s Delete call
            _purchaseOrderProviderMock.Setup(r => r.DeleteAsync(It.IsAny<PurchaseOrderDbModel>()));

            // act

            var result = await _purchaseOrderManager.DeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });

            Assert.IsFalse(result.Errors.Count > 0);
            Assert.IsFalse(result.HasErrors);
        }

        [TestMethod]
        public async Task AsyncDeletePurchaseOrder_ShouldFail_MissingParameters()
        {
            //Arrange;
            var record = new PurchaseOrderModel();
            // act
            var result = await _purchaseOrderManager.DeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("You must specify an purchase order number to delete.", result.Errors[0].Message);

        }

        [TestMethod]
        public async Task AsyncDeletePurchaseOrder_ShouldFail_ForAnyInvalidDbOperation()
        {
            //Arrange;
            var record = new PurchaseOrderModel
            {
                Id = 1,
            };
            var PO = new PurchaseOrderDbModel() { Id = 2 };
            // act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ThrowsAsync(new InvalidOperationException());
            // act
            var result = await _purchaseOrderManager.DeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Unable to delete from the purchase order table.", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task AsyncDeletePurchaseOrder_ShouldFail_IfDataNotFound()
        {
            //Arrange;
            var record = new PurchaseOrderModel
            {
                Id = 1,
            };
            var PO = new PurchaseOrderDbModel() { Id = 1 };

            // act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<Int32>()))
                .ReturnsAsync(() => null);

            // act
            var result = await _purchaseOrderManager.DeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("No purchase order was associated with purchase order number 1", result.Errors[0].Message);
        }


        [TestMethod]
        public async Task SoftDeletePurchaseOrderAsync_ShouldSuccess()
        {
            //Arrange;
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1234,
                Status = InventoryStatusEnum.Available.Value(),
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> { new PurchaseOrderLineItemDbModel() {
                    Id = 10,
                    PurchaseOrderId = 1 ,
                    QuantityOrdered = 2,
                    InventoryType = "fuel",
                    QuantityReceived = 1,
                    RevisedQuantity = 1,
                    Status = InventoryStatusEnum.Available.Value(),
                    ItemDetails = new List<PurchaseOrderItemDetailDbModel> { new PurchaseOrderItemDetailDbModel {
                        PurchaseOrderLineItemId = 10
                    } } } }
            };
            var record = new PurchaseOrderModel
            {
                Id = 1234,
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                Status = "D",
                LineItems = new List<PurchaseOrderLineItemModel> { new PurchaseOrderLineItemModel() { QuantityOrdered = 2, InventoryType = "fuel", QuantityReceived = 1, RevisedQuantity = 1, Status = InventoryStatusEnum.Available.Value(), } }
            };
            // act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(purchaseOrderDbModel);

            // set up the repository’s Delete call
            _purchaseOrderProviderMock.Setup(r => r.SoftDeleteAsync(purchaseOrderDbModel));

            // act

            var result = await _purchaseOrderManager.SoftDeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });

            Assert.IsFalse(result.Errors.Count > 0);
            Assert.IsFalse(result.HasErrors);
            Assert.AreEqual(record.Cmf, result.Item.Cmf);
        }

        [TestMethod]
        public async Task SoftDeletePurchaseOrder_ShouldFail_MissingParameters()
        {
            //Arrange;
            var record = new PurchaseOrderModel
            {
                Id = 0,

            };
            // act
            var result = await _purchaseOrderManager.SoftDeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("You must specify an purchase order number to delete.", result.Errors[0].Message);
        }


        [TestMethod]
        public async Task SoftDeletePurchaseOrder_ShouldFail_ForAnyInvalidDbOperation()
        {
            //Arrange;
            var record = new PurchaseOrderModel
            {
                Id = 1,

            };
            var PO = new PurchaseOrderDbModel() { Id = 2 };
            // act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ThrowsAsync(new InvalidOperationException());
            // act
            var result = await _purchaseOrderManager.SoftDeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("Unable to delete from the purchase order table.", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task SoftDeletePurchaseOrder_ShouldFail_IfDataNotFound()
        {
            //Arrange;
            var record = new PurchaseOrderModel
            {
                Id = 1,

            };
            var PO = new PurchaseOrderDbModel() { Id = 1 };

            // act
            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<Int32>()))
                .ReturnsAsync(() => null);

            // act
            var result = await _purchaseOrderManager.SoftDeletePurchaseOrder(new ApiItemModel<PurchaseOrderModel>() { Item = record });
            //Assert
            Assert.IsTrue(result.Errors.Count > 0);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual("No purchase order was associated with purchase order number 1", result.Errors[0].Message);
        }

        [TestMethod]
        public async Task GetListByFilterAsync_Success()
        {
            //Arrange

            //Arrange;
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1234,
                Status = InventoryStatusEnum.Available.Value(),
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> { new PurchaseOrderLineItemDbModel() {
                    Id = 10,
                    PurchaseOrderId = 1 ,
                    QuantityOrdered = 2,
                    InventoryType = "fuel",
                    QuantityReceived = 1,
                    RevisedQuantity = 1,
                    Status = InventoryStatusEnum.Available.Value(),
                    ItemDetails = new List<PurchaseOrderItemDetailDbModel> { new PurchaseOrderItemDetailDbModel {
                        PurchaseOrderLineItemId = 10
                    } } } }
            };

            var model = new List<PurchaseOrderDbModel>() { purchaseOrderDbModel };
            var record = new PurchaseOrderModel
            {
                Id = 1234,
                OrderDate = DateTime.Now,
                Status = "D",
                LineItems = new List<PurchaseOrderLineItemModel> { new PurchaseOrderLineItemModel() { QuantityOrdered = 2, InventoryType = "fuel", QuantityReceived = 1, RevisedQuantity = 1, Status = InventoryStatusEnum.Available.Value(), } }
            };
            _purchaseOrderProviderMock.Setup(x => x.ReadByFiltersAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>())).ReturnsAsync(model);

            //Act
            var result = await _purchaseOrderManager.GetListByFilterAsync("CA", "CaUser", DateTime.UtcNow, DateTime.UtcNow);

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Items.Count);
            Assert.IsFalse(result.HasErrors);
            Assert.AreEqual(0, result.Errors.Count);

        }

        [TestMethod]
        public async Task GetListByFilterAsync_Error_With_Invalid_Params()
        {
            //Act
            DateTime startDate = new DateTime(); ;
            DateTime endDate = new DateTime(); ;
            var result = await _purchaseOrderManager.GetListByFilterAsync("", "", startDate, endDate);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);

        }

        [TestMethod]
        public async Task GetListByFilterAsync_Error()
        {
            //Arrange
            _purchaseOrderProviderMock.Setup(x => x.ReadByFiltersAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>())).ThrowsAsync(new OutOfMemoryException());

            //Act
            var result = await _purchaseOrderManager.GetListByFilterAsync("CA", "CAUser", DateTime.UtcNow, DateTime.UtcNow);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            Assert.AreEqual(1, result.Errors.Count);

        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldSucceed()
        {
            var record = new PurchaseOrderModel
            {
                Id = 0,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = "OPEN",
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Open,
                    }
                }
            };

            _purchaseOrderProviderMock
                .Setup(ip => ip.SaveAsync(It.IsAny<PurchaseOrderDbModel>()))
                .ReturnsAsync(1);

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            Assert.IsNotNull(result);
            Assert.IsFalse(result.HasErrors);
        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldSucceedWithShipping()
        {
            //Arrange
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Shipped,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel> {
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 10,
                                Id = 1,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 10,
                                Id = 2,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 10,
                                Id = 3,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "MS01",
                                Status = PurchaseOrderStatus.Shipped,
                                QuantityShipped = 100
                            }
                        }
                    }
                }
            };
            //Arrange
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                State = "CA",
                Status = PurchaseOrderStatus.Shipped,
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 20,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel> {
                            new PurchaseOrderItemDetailDbModel {
                                Id = 1,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 2,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 3,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "MS01",
                                Status = PurchaseOrderStatus.Shipped,
                                QuantityShipped = 100
                            }
                        }
                    }
                }
            };
            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.SaveAsync(It.IsAny<PurchaseOrderDbModel>()))
                .ReturnsAsync(1);

            _inventoryManager
                .Setup(ip => ip.UpdateInventoryRangeAsync(It.IsAny<ApiItemModel<InventoryRangeUpdateModel>>()))
                .ReturnsAsync(new ApiItemModel<InventoryRangeUpdateModel>());

            _inventoryManager
                .Setup(ip => ip.TransferInventoryAsync(It.IsAny<ApiItemModel<InventoryRangeTransferModel>>()))
                .ReturnsAsync(new ApiItemModel<InventoryRangeTransferModel>());


            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("fuel", result.Item.LineItems[0].InventoryType);
            Assert.AreEqual(2, result.Item.LineItems[0].QuantityOrdered);
            Assert.AreEqual(PurchaseOrderStatus.Shipped, result.Item.Status);
            Assert.AreEqual(3, result.Item.LineItems[0].LineItemDetails.Count);

        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldSucceedWithDirectReceipt()
        {
            //Arrange
            var record = new PurchaseOrderModel
            {
                Id = 0,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "GG",
                PoolType = "UIP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Received,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 20,
                        Status = PurchaseOrderStatus.Received,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel> {
                            new PurchaseOrderLineItemDetailModel {
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Received,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Received,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "MS01",
                                Status = PurchaseOrderStatus.Received,
                                QuantityShipped = 100
                            }
                       }
                    }
                }
            };
            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(() => null);

            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.SaveAsync(It.IsAny<PurchaseOrderDbModel>()))
                .ReturnsAsync(1);

            _inventoryManager
                .Setup(ip => ip.ReceiveInventoryRangesAsync(It.IsAny<ApiItemModel<InventoryReceiveModel>>()))
                .ReturnsAsync(new ApiItemModel<InventoryReceiveModel>());


            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });
            //Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.HasErrors);
            Assert.AreEqual("fuel", result.Item.LineItems[0].InventoryType);
            Assert.AreEqual(2, result.Item.LineItems[0].QuantityOrdered);
            Assert.AreEqual(PurchaseOrderStatus.Closed, result.Item.Status);
            Assert.AreEqual(3, result.Item.LineItems[0].LineItemDetails.Count);

        }

        [TestMethod]
        [DataRow(0, null, "CAWHSE07", "V07", "BG", "IPP", "CA", "Test_User", "OPEN", "01R", 10, "State", true)]
        [DataRow(0, "CA", null, "V07", "BG", "IPP", "CA", "Test_User", "OPEN", "01R", 10, "Cmf", true)]
        [DataRow(0, "CA", "CAWHSE07", null, "BG", "IPP", "CA", "Test_User", "OPEN", "01R", 10, "OfficeId", true)]
        [DataRow(0, "CA", "CAWHSE07", "V07", null, "IPP", "CA", "Test_User", "OPEN", "01R", 10, "SiteId", true)]
        [DataRow(0, "CA", "CAWHSE07", "V07", "BG", null, "CA", "Test_User", "OPEN", "01R", 10, "PoolType", true)]
        [DataRow(0, "CA", "CAWHSE07", "V07", "BG", "IPP", "CA", "Test_User", "CLOSED", "01R", 10, "Invalid status to create a Purchase Order", false)]
        [DataRow(1, "CA", "CAWHSE07", "V07", "BG", "IPP", "CA", "Test_User", "OPEN", null, 10, "A minimum of 1 inventory type is required", false)]
        [DataRow(1, "CA", "CAWHSE07", "V07", "BG", "IPP", "CA", "Test_User", "OPEN", "01R", 0, "Each inventory item must contain a quantity ordered", false)]
        public async Task SavePurchaseOrderAysnc_ShouldFailWithParameter(long id, string state, string cmf, string officeId, string siteId, string poolType, string id_state, string userId, string status, string invType, int qtyOrdered, string errorToCheck, bool propError)
        {
            List<PurchaseOrderLineItemModel> lineItems = new List<PurchaseOrderLineItemModel>();
            if (!string.IsNullOrEmpty(invType))
            {
                lineItems.Add(
                     new PurchaseOrderLineItemModel()
                     {
                         QuantityOrdered = qtyOrdered,
                         InventoryType = invType,
                         QuantityReceived = 1,
                         RevisedQuantity = 1,
                         Status = PurchaseOrderStatus.Open
                     }
                );
            }

            var record = new PurchaseOrderModel
            {
                Id = id,
                State = state,
                Cmf = cmf,
                OfficeId = officeId,
                SiteId = siteId,
                PoolType = poolType,
                OrderDate = DateTime.Now,
                Status = status,
                LineItems = lineItems
            };

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = id_state,
                    UserId = userId,
                    Cmf = cmf
                },
            });
            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            if (propError)
            {
                Assert.IsTrue(result.Errors[0].PropertyInError.Contains(errorToCheck), $"Expected: {errorToCheck} Actual: {result.Errors[0].PropertyInError[0]}");
            }
            else
            {
                Assert.IsTrue(result.Errors[0].Message.Contains(errorToCheck), $"Expected: {errorToCheck} Actual: {result.Errors[0].Message}");
            }
        }

        [TestMethod]
        [DataRow(0, "CAWHSE07", "V07", "GG", "01R", "2VUA200", "2VUA224", "Line:0-Detail:0 - QuantityShipped", true)]
        [DataRow(25, "CAWHSE07", "V07", "GG", null, "2VUA200", "2VUA224", "Line:0-Detail:0 - InventoryType", true)]
        [DataRow(25, "CAWHSE07", "V07", "GG", "01R", null, "2VUA224", "Line:0-Detail:0 - BeginningSerial", true)]
        [DataRow(25, "CAWHSE07", "V07", "GG", "01R", "2VUA200", null, "Line:0-Detail:0 - EndingSerial", true)]
        [DataRow(25, "TEST0001", "V07", "GG", "01R", "2VUA200", "2VUA224", "PO Cmf does not match with provided Pool information", false)]
        [DataRow(23, "CAWHSE07", "V07", "GG", "01R", "2VUA200", "2VUA224", "Line:0-Detail:0 - Serno Error", false)]
        public async Task SavePurchaseOrderAysnc_ShouldFailWithDetailParameter(int qtyShipped, string cmf, string fromOfficeId, string fromSiteId, string invType, string serialBegin, string serialEnd, string errorToCheck, bool propError)
        {
            List<PurchaseOrderLineItemDetailModel> detailItems = new List<PurchaseOrderLineItemDetailModel>();
            detailItems.Add(
                     new PurchaseOrderLineItemDetailModel()
                     {
                         Id = 0,
                         QuantityShipped = qtyShipped,
                         InventoryType = invType,
                         BeginningSerial = serialBegin,
                         EndingSerial = serialEnd,
                         FromOfficeId = fromOfficeId,
                         FromSiteId = fromSiteId,
                         Status = PurchaseOrderStatus.Received
                     }
                );

            var record = new PurchaseOrderModel
            {
                Id = 0,
                State = "CA",
                Cmf = cmf,
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Received,
                LineItems = new List<PurchaseOrderLineItemModel>
                {
                    new PurchaseOrderLineItemModel{
                        Id = 0,
                        QuantityOrdered = 25,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 25,
                        Status = PurchaseOrderStatus.Received,
                        LineItemDetails = detailItems
                    }
                },
            };
            var result = await _poManagerForLineDetailValidation.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });
            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            if (propError)
            {
                Assert.IsTrue(result.Errors[0].PropertyInError.Contains(errorToCheck), $"Expected: {errorToCheck} Actual: {result.Errors[0].PropertyInError[0]}");
            }
            else
            {
                Assert.IsTrue(result.Errors[0].Message.Contains(errorToCheck), $"Expected: {errorToCheck} Actual: {result.Errors[0].Message}");
            }
        }

        [TestMethod]
        [DataRow(null, "GG", "Line:0-Detail:0 - FromOfficeId", true)]
        [DataRow("V07", null, "Line:0-Detail:0 - FromSiteId", true)]
        [DataRow("V07", "Z0", "Line:0-Detail:0 - Unable to identify Inventory Pool by provided office id, site id", false)]
        public async Task SavePurchaseOrderAysnc_ShouldFailWithDetailWarehouse(string fromOfficeId, string fromSiteId, string errorToCheck, bool propError)
        {
            var dbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Open,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
                {
                    new PurchaseOrderLineItemDbModel
                    {
                        Id = 10,
                        QuantityOrdered = 25,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 25,
                        Status = PurchaseOrderStatus.Open,
                    }
                }

            };

            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Open,
                LineItems = new List<PurchaseOrderLineItemModel>
                {
                    new PurchaseOrderLineItemModel{
                        Id = 10,
                        QuantityOrdered = 25,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 25,
                        Status = PurchaseOrderStatus.Open,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel>
                        {
                             new PurchaseOrderLineItemDetailModel()
                             {
                                 Id = 0,
                                 QuantityShipped = 25,
                                 InventoryType = "01R",
                                 BeginningSerial = "2VUA200",
                                 EndingSerial = "2VUA224",
                                 FromOfficeId = fromOfficeId,
                                 FromSiteId = fromSiteId,
                                 Status = PurchaseOrderStatus.Shipped
                             }
                        }
                    }
                },
            };

            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(dbModel);

            var result = await _poManagerForLineDetailValidation.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });
            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            if (propError)
            {
                Assert.IsTrue(result.Errors[0].PropertyInError.Contains(errorToCheck), $"Expected: {errorToCheck} Actual: {result.Errors[0].PropertyInError[0]}");
            }
            else
            {
                Assert.IsTrue(result.Errors[0].Message.Contains(errorToCheck), $"Expected: {errorToCheck} Actual: {result.Errors[0].Message}");
            }
        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldFailWithNoRecordToSave()
        {
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OrderDate = DateTime.Now,
                Status = "D",
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = InventoryStatusEnum.Available.Value(),
                    }
                }
            };

            _purchaseOrderProviderMock
                .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
                .ReturnsAsync(() => null);

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>() { Item = record });

            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors[0].Message.Contains("Missing or invalid required parameters"));

        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldFailWithShippingError()
        {
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Shipped,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel> {
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 10,
                                Id = 1001,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 11,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                Id = 1002,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };

            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                State = "CA",
                Status = PurchaseOrderStatus.Open,
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Open,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel> {
                            new PurchaseOrderItemDetailDbModel {
                                Id = 1001,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Open,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 1002,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Open,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };

            var RangeUpdationError = new ApiItemModel<InventoryRangeUpdateModel>
            {
                Errors = new List<ErrorModel>{
                    new ErrorModel
                    {
                        IsCvrError= true,
                        Severity = ErrorSeverityEnum.Fatal,
                        Message = "Inventory Manager Error"
                    }
                }
            };
            var RangeTransferError = new ApiItemModel<InventoryRangeTransferModel>
            {
                Errors = new List<ErrorModel>{
                    new ErrorModel
                    {
                        IsCvrError= true,
                        Severity = ErrorSeverityEnum.Fatal,
                        Message = "Inventory Manager Error"
                    }
                }
            };

            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            _purchaseOrderProviderMock
                .Setup(ip => ip.SaveAsync(It.IsAny<PurchaseOrderDbModel>()))
                .ReturnsAsync(1);

            _inventoryManager
                .Setup(ip => ip.TransferInventoryAsync(It.IsAny<ApiItemModel<InventoryRangeTransferModel>>()))
                .ReturnsAsync(RangeTransferError);

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors[0].Message.Contains("Inventory Manager Error"), result.Errors[0].Message);

        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldFailWithShippingException()
        {
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Shipped,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel> {
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 10,
                                Id = 1,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                PurchaseOrderLineItemId = 10,
                                Id = 2,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };

            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                State = "CA",
                Status = PurchaseOrderStatus.Open,
                Cmf = "cmf",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Open,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel> {
                            new PurchaseOrderItemDetailDbModel {
                                Id = 1,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Open,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 2,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Open,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };

            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            _purchaseOrderProviderMock
                .Setup(ip => ip.SaveAsync(It.IsAny<PurchaseOrderDbModel>()))
                .ReturnsAsync(1);

            _inventoryManager
                .Setup(ip => ip.TransferInventoryAsync(It.IsAny<ApiItemModel<InventoryRangeTransferModel>>()))
                .ThrowsAsync(new InvalidOperationException("Unable to complete Inventory Manager Method"));

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors[0].Message.Contains("Unable to save Purchase Order."), result.Errors[0].Message);

        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_ShouldFailWithProviderException()
        {
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Shipped,
                LineItems = new List<PurchaseOrderLineItemModel>
                {
                    new PurchaseOrderLineItemModel()
                    {
                        Id = 10,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped
                    }
                }
            };
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                State = "CA",
                Status = PurchaseOrderStatus.Shipped,
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "fuel",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel> {
                            new PurchaseOrderItemDetailDbModel {
                                Id = 100,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 101,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };


            _purchaseOrderProviderMock
                .Setup(ip => ip.SaveAsync(It.IsAny<PurchaseOrderDbModel>()))
                .ThrowsAsync(new InvalidOperationException("ProviderExceptionHere"));

            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors[0].Message.Contains("Unable to save Purchase Order."), result.Errors[0].Message);
        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_AllLineItemsReceivedShouldMarkPurchaseOrderStatusAsClosed()
        {
            //Arrange
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Shipped,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 1,
                        RevisedQuantity = 20,
                        Status = PurchaseOrderStatus.Received,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel> {
                            new PurchaseOrderLineItemDetailModel {
                                Id = 1,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                PurchaseOrderLineItemId = 10,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Received,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                Id = 2,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                PurchaseOrderLineItemId = 10,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Received,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };
            //Arrange
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                State = "CA",
                Status = PurchaseOrderStatus.Shipped,
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 1,
                        RevisedQuantity = 20,
                        Status = PurchaseOrderStatus.Shipped,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel> {
                            new PurchaseOrderItemDetailDbModel {
                                Id = 1,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 2,
                                PurchaseOrderLineItemId = 10,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };
            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.UpdateAsync(It.IsAny<PurchaseOrderDbModel>()));

            _inventoryManager
                .Setup(ip => ip.UpdateInventoryRangeAsync(It.IsAny<ApiItemModel<InventoryRangeUpdateModel>>()))
                .ReturnsAsync(new ApiItemModel<InventoryRangeUpdateModel>());


            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });
            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(PurchaseOrderStatus.Closed, result.Item.Status);
            Assert.AreEqual(PurchaseOrderStatus.Received, result.Item.LineItems[0].Status);
            Assert.AreEqual(PurchaseOrderStatus.Received, result.Item.LineItems[0].LineItemDetails[0].Status);
            Assert.AreEqual(PurchaseOrderStatus.Received, result.Item.LineItems[0].LineItemDetails[1].Status);
            Assert.AreEqual(20, result.Item.LineItems[0].QuantityReceived);
            Assert.IsNotNull(result.Item.CloseDate);
        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_AnyLineItemsReceivedShouldMarkInventoryStatusAsAvailable()
        {
            //Arrange
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Shipped,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Received,
                        LineItemDetails = new List<PurchaseOrderLineItemDetailModel> {
                            new PurchaseOrderLineItemDetailModel {
                                Id = 1,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                PurchaseOrderLineItemId = 10,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Received,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderLineItemDetailModel {
                                Id = 2,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                PurchaseOrderLineItemId = 10,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Received,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };
            //Arrange
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                Status = PurchaseOrderStatus.Shipped,
                State = "CA",
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 1,
                        RevisedQuantity = 1,
                        Status = PurchaseOrderStatus.Shipped,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel> {
                            new PurchaseOrderItemDetailDbModel {
                                Id = 1,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                PurchaseOrderLineItemId = 10,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC000",
                                EndingSerial = "2ABC009",
                                QuantityShipped = 10
                            },
                            new PurchaseOrderItemDetailDbModel {
                                Id = 2,
                                FromOfficeId = "V07",
                                FromSiteId = "GG",
                                PurchaseOrderLineItemId = 10,
                                InventoryType = "01R",
                                Status = PurchaseOrderStatus.Shipped,
                                BeginningSerial = "2ABC100",
                                EndingSerial = "2ABC109",
                                QuantityShipped = 10
                            }
                        }
                    }
                }
            };
            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.UpdateAsync(It.IsAny<PurchaseOrderDbModel>()));

            _inventoryManager
                .Setup(ip => ip.UpdateInventoryRangeAsync(It.IsAny<ApiItemModel<InventoryRangeUpdateModel>>()))
                .ReturnsAsync(new ApiItemModel<InventoryRangeUpdateModel>());

            _inventoryManager
                .Setup(ip => ip.TransferInventoryAsync(It.IsAny<ApiItemModel<InventoryRangeTransferModel>>()))
                .ReturnsAsync(new ApiItemModel<InventoryRangeTransferModel>());

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            //Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.HasErrors);

        }

        [TestMethod]
        [DataRow(10, "With a postive quantity ordered value")]
        [DataRow(0, "With zero quantity ordered")]
        public async Task SavePurchaseOrderAsync_DeleteAnLineItemShouldSucceed(int qtyOrdered, string testDesc)
        {
            //Arrange
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Open,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Open
                    },
                    new PurchaseOrderLineItemModel() {
                        Id = 11,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = qtyOrdered,
                        InventoryType = "02R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Deleted
                    }
                }
            };
            //Arrange
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                Status = PurchaseOrderStatus.Open,
                State = "CA",
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Open,
                    },
                    new PurchaseOrderLineItemDbModel() {
                        Id = 11,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "02R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Open,
                    }
                }
            };
            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.UpdateAsync(It.IsAny<PurchaseOrderDbModel>()));

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            //Assert
            Assert.IsNotNull(result, testDesc);
            Assert.IsFalse(result.HasErrors, testDesc);

        }

        [TestMethod]
        public async Task SavePurchaseOrderAsync_DeleteAnLineItemShouldFail()
        {
            //Arrange
            var record = new PurchaseOrderModel
            {
                Id = 1,
                State = "CA",
                Cmf = "CAWHSE07",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                Status = PurchaseOrderStatus.Open,
                LineItems = new List<PurchaseOrderLineItemModel> {
                    new PurchaseOrderLineItemModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Open
                    },
                    new PurchaseOrderLineItemModel() {
                        Id = 11,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "02R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Deleted
                    }
                }
            };
            //Arrange
            var purchaseOrderDbModel = new PurchaseOrderDbModel
            {
                Id = 1,
                Status = PurchaseOrderStatus.Open,
                State = "CA",
                Cmf = "cmf",
                OfficeId = "V07",
                SiteId = "BG",
                PoolType = "IPP",
                OrderDate = DateTime.Now,
                PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel> {
                    new PurchaseOrderLineItemDbModel() {
                        Id = 10,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "01R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Open,
                    },
                    new PurchaseOrderLineItemDbModel() {
                        Id = 11,
                        PurchaseOrderId = 1 ,
                        QuantityOrdered = 2,
                        InventoryType = "02R",
                        QuantityReceived = 0,
                        RevisedQuantity = 0,
                        Status = PurchaseOrderStatus.Shipped,
                        ItemDetails = new List<PurchaseOrderItemDetailDbModel>
                        {
                            new PurchaseOrderItemDetailDbModel
                            {
                                Id = 102,
                                Status = PurchaseOrderStatus.Shipped
                            }
                        }
                    }
                }
            };
            _purchaseOrderProviderMock
               .Setup(ip => ip.ReadByIdAsync(It.IsAny<long>()))
               .ReturnsAsync(purchaseOrderDbModel);

            //Act
            _purchaseOrderProviderMock
                .Setup(ip => ip.UpdateAsync(It.IsAny<PurchaseOrderDbModel>()));

            var result = await _purchaseOrderManager.SavePurchaseOrderAsync(new ApiItemModel<PurchaseOrderModel>()
            {
                Item = record,
                Identification = new IdentificationModel
                {
                    State = "CA",
                    UserId = "EJP",
                    Cmf = "TEST001"
                },
            });

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.HasErrors);
            Assert.IsTrue(result.Errors.AsJsonString().Contains("Line:1 - Unable to delete item with Shipping/Receiving records"), result.Errors.AsJsonString());

        }

    }
}
