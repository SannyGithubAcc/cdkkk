﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace cdk.evr.converge.cbe.common.ioc
{
    public interface IIoCStartup
    {
        void ConfigureServices(IServiceCollection services);

    }

    /// <summary>
    /// Used to register interfaces and concreat classes with the service collection.
    /// </summary>
    public class IoCStartup : IIoCStartup
    {
        /// <summary>
        /// Called by RegisterIocStartup methods when the application is started.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient(typeof(IIoCFactory), typeof(IoCFactory));
        }
    }
}
