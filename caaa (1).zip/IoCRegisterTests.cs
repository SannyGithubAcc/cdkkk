﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using TestUtilities;
using System.Diagnostics.CodeAnalysis;

namespace cdk.evr.converge.cbe.common.ioc.Tests
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class IoCRegisterTests: TestStartup
    {
        [TestMethod]
        public void RegisterIocStartupForAssemblyTest()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            IServiceCollection services = IoCRegister.RegisterIocStartupForAssembly(assembly, new[] { "cdk.evr.converge.cbe" });
            object _coValidator = services.BuildServiceProvider().GetService(typeof(IStoreValidator));

            Assert.IsNotNull(_coValidator);
        }

    }
}