using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Models;
using cdk.evr.converge.cbe.common.models.Constants;
using cdk.evr.converge.cbe.common.models.Enumerations;
using cdk.evr.converge.cbe.common.models.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using MockQueryable.Moq;
using Moq;

namespace TestUtilities
{
    [ExcludeFromCodeCoverage]
    public class PostgreSqlContextMock
    {
        private readonly Mock<IPostgreSqlContext> _mock;

        public PostgreSqlContextMock()
        {
            _mock = new Mock<IPostgreSqlContext>();
            _mock.Setup(m => m.SaveChangesAsync(It.IsAny<CancellationToken>())).Returns(Task.FromResult(1));
            var seqNumbers = new List<SequenceNumberDbModel> { new SequenceNumberDbModel { GetNextValue = 1001 } }.AsQueryable();
            _mock.Setup(m => m.RunSql<SequenceNumberDbModel>(It.IsAny<string>())).Returns(seqNumbers);

            // Add DbSet mocks
            SetupCmfEft();
            SetupZipDecode();
            SetupFeeSummaryAndDetail();
            SetupFeeCodes();
            SetupApplicationSettings();
            SetupInventoryPools();
            SetupInventory();
            SetupInventoryTypes();
            SetupMiscellaneousCharges();
            SetupStores();
            SetupAccountingCodes();
            SetupDefaultFees();
            SetupFeeSchedule();
            SetupDmvLog();
            SetupInventoryHistory();
            SetupRegion();
            SetupRegionEft();
            SetupSeedData();
            SetupStateLog();
            SetupTransaction();
            SetupTransactionDetail();
            SetupTransactionLog();
            SetupPurchaseOrder();
            SetupInventoryTransferLog();
            SetupInventoryReOrderPoint();
            SetupPendingEft();
            SetupInventoryReOrderPoint();
            SetupReconcilationChecks();
            SetupUserAgreement();
            SetupProcessLock();
            SetupFifoQueue();
            SetupLookup();
            SetupAccountingCreditAndDetail();
            SetupHostMocking();
            SetupAccountingCreditReturn();
            SetupDailyFeeSummary();
            SetupSystemStatus();
            SetupSystemPerformance();
            SetupDLDVLog();
            SetupBillingCategories();
            SetupTransactionInProcess();
            SetupState();
        }

        public IPostgreSqlContext GetMocked()
        {
            return _mock.Object;
        }

        private void SetupApplicationSettings()
        {
            // Create data for the zip_decode table.
            var settingsData = new List<ApplicationSettingsDbModel>()
            {
                new ApplicationSettingsDbModel { State = "COMMON", System = "Logging", Subsystem = "Exceptions", Settings = "{\"Path\": \"./Exception.log\"}".AsJsonDocument() },
                new ApplicationSettingsDbModel { State = "COMMON", System = "Reports", Subsystem = "Notification", Settings = "{\"Path\": \"./Exception.log\"}".AsJsonDocument() },
                new ApplicationSettingsDbModel { State = "CA", System = "Logging", Subsystem = "Exceptions", Settings = "{\"Path\": \"./Exception.log\"}".AsJsonDocument() },
                new ApplicationSettingsDbModel { State = "CA", System = "Testing", Subsystem = "Testing", Settings = "{\"Path\": \"./Exception.log\"}".AsJsonDocument() },
                new ApplicationSettingsDbModel { State = "Services", System = "Logging", Subsystem = "Exceptions", Settings = "{\"Path\": \"./Exception.log\"}".AsJsonDocument() },
                new ApplicationSettingsDbModel { State = "COMMON", System = "Authentication", Subsystem = "Eft", Settings = "{\"Path\": \"./Exception.log\"}".AsJsonDocument() }
            };


            // Create a dataset for the mock using the data above.
            var mockApplicationSettingsDbSet = settingsData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.ApplicationSettings).Returns(mockApplicationSettingsDbSet.Object);

            // Mock other required functions for CmfEft.
            _mock.Setup(m => m.ApplicationSettings.AddAsync(It.IsAny<ApplicationSettingsDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((ApplicationSettingsDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.System) ||
                        string.IsNullOrEmpty(data.Subsystem) ||
                        (data.Settings == null))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (settingsData.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    settingsData.Add(data);
                    return new ValueTask<EntityEntry<ApplicationSettingsDbModel>>();
                });

            _mock.Setup(m => m.ApplicationSettings.Add(It.IsAny<ApplicationSettingsDbModel>()))
                .Returns((ApplicationSettingsDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }


                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.System) ||
                        string.IsNullOrEmpty(data.Subsystem) ||
                        (data.Settings == null))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (settingsData.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    settingsData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ApplicationSettings.Update(It.IsAny<ApplicationSettingsDbModel>()))
                .Returns((ApplicationSettingsDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (settingsData.Find(c => c.State == data.State) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.State);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                          string.IsNullOrEmpty(data.System) ||
                          string.IsNullOrEmpty(data.Subsystem) ||
                          (data.Settings == null))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = settingsData.Find(r => r.State == data.State);
                    settingsData.Remove(record);
                    settingsData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ApplicationSettings.Remove(It.IsAny<ApplicationSettingsDbModel>()))
                .Returns((ApplicationSettingsDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (settingsData.Find(c => c.State == data.State) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    settingsData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.ApplicationSettings.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = settingsData.Find(r => r.State == keyValues[0].ToString() &&
                        r.System == keyValues[1].ToString() &&
                        r.Subsystem == keyValues[2].ToString());

                    return result;
                });
        }

        private void SetupCmfEft()
        {
            // Create data for the zip_decode table.
            var cmfEftData = new List<CmfEftDbModel>();

            // Create a dataset for the mock using the data above.
            var mockCmfEftDbSet = cmfEftData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.CmfEft).Returns(mockCmfEftDbSet.Object);

            // Mock other required functions for CmfEft.
            _mock.Setup(m => m.CmfEft.AddAsync(It.IsAny<CmfEftDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((CmfEftDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.AbaNumber) ||
                        string.IsNullOrEmpty(data.AccountType) ||
                        string.IsNullOrEmpty(data.AccountNumber) ||
                        string.IsNullOrEmpty(data.AccountName) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (cmfEftData.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    cmfEftData.Add(data);
                    return new ValueTask<EntityEntry<CmfEftDbModel>>();
                });

            _mock.Setup(m => m.CmfEft.Add(It.IsAny<CmfEftDbModel>()))
                .Returns((CmfEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.AbaNumber) ||
                        string.IsNullOrEmpty(data.AccountType) ||
                        string.IsNullOrEmpty(data.AccountNumber) ||
                        string.IsNullOrEmpty(data.AccountName) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (cmfEftData.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    cmfEftData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.CmfEft.Update(It.IsAny<CmfEftDbModel>()))
                .Returns((CmfEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (cmfEftData.Find(c => c.Cmf == data.Cmf) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Cmf);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.AbaNumber) ||
                        string.IsNullOrEmpty(data.AccountType) ||
                        string.IsNullOrEmpty(data.AccountNumber) ||
                        string.IsNullOrEmpty(data.AccountName) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = cmfEftData.Find(r => r.Cmf == data.Cmf);
                    cmfEftData.Remove(record);
                    cmfEftData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.CmfEft.Remove(It.IsAny<CmfEftDbModel>()))
                .Returns((CmfEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (cmfEftData.Find(c => c.Cmf == data.Cmf) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    cmfEftData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.CmfEft.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = cmfEftData.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });
        }
        private void SetupFeeSchedule()
        {
            // Create data for the FeeSchedule table
            var feeData = new List<FeeScheduleDbModel>
            {
                new FeeScheduleDbModel { Id = 1, AccountingCodeId = 1, State = "CA", Cmf = "CATEST01", IsDiscounted = false, Fee = "25.00", ToDate = DateTime.Now.AddDays(1), FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 1, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "3", TransactionName = "New Vehicle Report of Sale", AccountingCode = "3" } },
                new FeeScheduleDbModel { Id = 2, AccountingCodeId = 2, State = "CA", Cmf = "CATEST01", IsDiscounted = false, Fee = "25.00", ToDate = DateTime.Now.AddDays(1), FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 2, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "4", TransactionName = "Post Fees / Original", AccountingCode = "4" } },
                new FeeScheduleDbModel { Id = 3, AccountingCodeId = 3, State = "CA", Cmf = "CATEST01", IsDiscounted = false, Fee = "25.00", ToDate = DateTime.Now.AddDays(1), FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 3, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "5", TransactionName = "Registration Transfers", AccountingCode = "5" } },
                new FeeScheduleDbModel { Id = 4, AccountingCodeId = 1, State = "CA", Cmf = "TEST0001", IsDiscounted = false, Fee = "5.00", ToDate = DateTime.Now.AddDays(1), FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 1, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "3", TransactionName = "New Vehicle Report of Sale", AccountingCode = "3" } },
                new FeeScheduleDbModel { Id = 5, AccountingCodeId = 2, State = "CA", Cmf = "TEST0001", IsDiscounted = false, Fee = "5.00", ToDate = DateTime.Now.AddDays(1), FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 2, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "4", TransactionName = "Post Fees / Original", AccountingCode = "4" } },
                new FeeScheduleDbModel { Id = 6, AccountingCodeId = 3, State = "CA", Cmf = "TEST0001", IsDiscounted = false, Fee = "5.00", ToDate = DateTime.Now.AddDays(5), FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 3, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "5", TransactionName = "Registration Transfers", AccountingCode = "5" } },
                new FeeScheduleDbModel { Id = 7, AccountingCodeId = 1, State = "CA", Cmf = "CAREGS01", IsDiscounted = false, Fee = "10.00", ToDate = null, FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 1, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "3", TransactionName = "New Vehicle Report of Sale", AccountingCode = "3" } },
                new FeeScheduleDbModel { Id = 8, AccountingCodeId = 2, State = "CA", Cmf = "CAREGS01", IsDiscounted = false, Fee = "10.00", ToDate = null, FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 2, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "4", TransactionName = "Post Fees / Original", AccountingCode = "4" } },
                new FeeScheduleDbModel { Id = 9, AccountingCodeId = 3, State = "CA", Cmf = "CAREGS01", IsDiscounted = false, Fee = "10.00", ToDate = null, FromDate = DateTime.Now.AddDays(-1),
                    AccountingCode = new AccountingCodesDbModel { Id = 3, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "5", TransactionName = "Registration Transfers", AccountingCode = "5" } }
            };

            // Create a dateset for the mock using the data list above
            var mockFeeDbSet = feeData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.FeeSchedule).Returns(mockFeeDbSet.Object);

            // Mock other required functions for Fee Schedule
            _mock.Setup(m => m.FeeSchedule.AddAsync(It.IsAny<FeeScheduleDbModel>(), It.IsAny<CancellationToken>()))
               .Returns((FeeScheduleDbModel data, CancellationToken token) =>
               {
                   if (data == null)
                   {
                       throw new NullReferenceException();
                   }

                   if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf))
                   {
                       var innerException = new Exception("Missing required field.");
                       throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                   }

                   if (feeData.Find(r => r.Id == data.Id) != null)
                   {
                       var innerException = new Exception("duplicate key value violates unique constraint");
                       throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                   }

                   var maxId = feeData.Max(z => z.Id);
                   data.Id = maxId + 1;
                   feeData.Add(data);
                   return new ValueTask<EntityEntry<FeeScheduleDbModel>>();
               });

            _mock.Setup(m => m.FeeSchedule.Add(It.IsAny<FeeScheduleDbModel>()))
                .Returns((FeeScheduleDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (feeData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeSchedule.Update(It.IsAny<FeeScheduleDbModel>()))
                .Returns((FeeScheduleDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = feeData.Find(r => r.Id == data.Id);
                    feeData.Remove(record);
                    feeData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeSchedule.Remove(It.IsAny<FeeScheduleDbModel>()))
                .Returns((FeeScheduleDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    feeData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.FeeSchedule.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = feeData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupAccountingCodes()
        {
            // Create data for the AccountingCodes table.
            var accountingData = new List<AccountingCodesDbModel>
            {
                new AccountingCodesDbModel { Id = 1, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "3", TransactionName = "New Vehicle Report of Sale", AccountingCode = "3"},
                new AccountingCodesDbModel { Id = 2, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "4", TransactionName = "Post Fees / Original", AccountingCode = "4"},
                new AccountingCodesDbModel { Id = 3, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "5", TransactionName = "Registration Transfers", AccountingCode = "5"},
                new AccountingCodesDbModel { Id = 4, State = "CA", CategoryCode = "2", CategoryName = "Inquiry", TransactionType = null, TransactionName = "Vehicle", AccountingCode = "401"},
                new AccountingCodesDbModel { Id = 5, State = "CA", CategoryCode = "2", CategoryName = "Inquiry", TransactionType = null, TransactionName = "Person", AccountingCode = "402"},
                new AccountingCodesDbModel { Id = 6, State = "CA", CategoryCode = "2", CategoryName = "Inquiry", TransactionType = null, TransactionName = "Vehicle Bulk", AccountingCode = "403"},
                new AccountingCodesDbModel { Id = 7, State = "CA", CategoryCode = "3", CategoryName = "Business Fee", TransactionType = null, TransactionName = "Late Fee", AccountingCode = "801"},
                new AccountingCodesDbModel { Id = 8, State = "CA", CategoryCode = "3", CategoryName = "Business Fee", TransactionType = null, TransactionName = "Mail-In", AccountingCode = "802"},
                new AccountingCodesDbModel { Id = 9, State = "CA", CategoryCode = "3", CategoryName = "Business Fee", TransactionType = null, TransactionName = "Bnk Chrg", AccountingCode = "803"},
            };

            // Create a dateset for the mock using the data list above
            var mockAccountingDbSet = accountingData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.AccountingCodes).Returns(mockAccountingDbSet.Object);

            // Mock other required functions for Accounting Codes
            _mock.Setup(m => m.AccountingCodes.AddAsync(It.IsAny<AccountingCodesDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((AccountingCodesDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (accountingData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingData.Add(data);
                    return new ValueTask<EntityEntry<AccountingCodesDbModel>>();
                });

            _mock.Setup(m => m.AccountingCodes.Add(It.IsAny<AccountingCodesDbModel>()))
                .Returns((AccountingCodesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (accountingData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCodes.Update(It.IsAny<AccountingCodesDbModel>()))
                .Returns((AccountingCodesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = accountingData.Find(r => r.Id == data.Id);
                    accountingData.Remove(record);
                    accountingData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCodes.Remove(It.IsAny<AccountingCodesDbModel>()))
                .Returns((AccountingCodesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    accountingData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCodes.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = accountingData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupDefaultFees()
        {
            // Create date for the default_fees table
            var defaultData = new List<DefaultFeesDbModel>
            {
                new DefaultFeesDbModel { Id = 1, AccountingCodeId = 1, State = "CA", CompanyType = "Dealer", Fee = "25.00",
                     AccountingCode = new AccountingCodesDbModel { Id = 1, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "3", TransactionName = "New Vehicle Report of Sale", AccountingCode = "3" } },

                new DefaultFeesDbModel { Id = 2, AccountingCodeId = 2, State = "CA", CompanyType = "Dealer", Fee = "25.00",
                     AccountingCode = new AccountingCodesDbModel { Id = 2, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "4", TransactionName = "Post Fees / Original", AccountingCode = "4" } },

                new DefaultFeesDbModel { Id = 3, AccountingCodeId = 3, State = "CA", CompanyType = "Dealer", Fee = "25.00",
                    AccountingCode = new AccountingCodesDbModel { Id = 3, State = "CA", CategoryCode = "1", CategoryName = "Deal Transaction", TransactionType = "5", TransactionName = "Registration Transfers", AccountingCode = "5" } },
            };

            // Create a dataset for the mock using the data above.
            var mockDefaultDbSet = defaultData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.DefaultFees).Returns(mockDefaultDbSet.Object);

            // Mock other required functions for DefaultFees
            _mock.Setup(m => m.DefaultFees.AddAsync(It.IsAny<DefaultFeesDbModel>(), It.IsAny<CancellationToken>()))
               .Returns((DefaultFeesDbModel data, CancellationToken token) =>
               {
                   if (data == null)
                   {
                       throw new NullReferenceException();
                   }

                   if (string.IsNullOrEmpty(data.State))
                   {
                       var innerException = new Exception("Missing required field.");
                       throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                   }

                   if (defaultData.Find(r => r.Id == data.Id) != null)
                   {
                       var innerException = new Exception("duplicate key value violates unique constraint");
                       throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                   }

                   var maxId = defaultData.Max(z => z.Id);
                   data.Id = maxId + 1;
                   defaultData.Add(data);
                   return new ValueTask<EntityEntry<DefaultFeesDbModel>>();
               });

            _mock.Setup(m => m.DefaultFees.Add(It.IsAny<DefaultFeesDbModel>()))
                .Returns((DefaultFeesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (defaultData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = defaultData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    defaultData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DefaultFees.Update(It.IsAny<DefaultFeesDbModel>()))
                .Returns((DefaultFeesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (defaultData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = defaultData.Find(r => r.Id == data.Id);
                    defaultData.Remove(record);
                    defaultData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DefaultFees.Remove(It.IsAny<DefaultFeesDbModel>()))
                .Returns((DefaultFeesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (defaultData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    defaultData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.DefaultFees.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = defaultData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupZipDecode()
        {
            // Create data for the zip_decode table.
            var zipData = new List<ZipDecodeDbModel>
            {
                new ZipDecodeDbModel { Id = 1, State = "CA", City = "City1", County = "County1", Zip = "99991"},
                new ZipDecodeDbModel { Id = 2, State = "CA", City = "City1", County = "County1", Zip = "99992"},
                new ZipDecodeDbModel { Id = 3, State = "CA", City = "City1", County = "County1", Zip = "99993"},
                new ZipDecodeDbModel { Id = 4, State = "CA", City = "City1", County = "County1", Zip = "99994"},
                new ZipDecodeDbModel { Id = 5, State = "CA", City = "City1", County = "County1", Zip = "99995"},
                new ZipDecodeDbModel { Id = 6, State = "CA", City = "City2", County = "County1", Zip = "99991"},
                new ZipDecodeDbModel { Id = 7, State = "CA", City = "City3", County = "County1", Zip = "99991"},
                new ZipDecodeDbModel { Id = 8, State = "CA", City = "City1", County = "County2", Zip = "99991"}
            };

            // Create a dataset for the mock using the data above.
            var mockZipDbSet = zipData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.ZipDecode).Returns(mockZipDbSet.Object);

            // Mock other required functions for ZipDecode.
            _mock.Setup(m => m.ZipDecode.AddAsync(It.IsAny<ZipDecodeDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((ZipDecodeDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.City) ||
                        string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Zip))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (zipData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = zipData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    zipData.Add(data);
                    return new ValueTask<EntityEntry<ZipDecodeDbModel>>();
                });

            _mock.Setup(m => m.ZipDecode.Add(It.IsAny<ZipDecodeDbModel>()))
                .Returns((ZipDecodeDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.City) ||
                        string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Zip))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (zipData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = zipData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    zipData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ZipDecode.Update(It.IsAny<ZipDecodeDbModel>()))
                .Returns((ZipDecodeDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (zipData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.City) ||
                        string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Zip))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = zipData.Find(r => r.Id == data.Id);
                    zipData.Remove(record);
                    zipData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ZipDecode.Remove(It.IsAny<ZipDecodeDbModel>()))
                .Returns((ZipDecodeDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (zipData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    zipData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.ZipDecode.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = zipData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupFeeSummaryAndDetail()
        {
            var feeSummaryRecords = new List<FeeSummaryDbModel>
            {
                new FeeSummaryDbModel { Id = 1, FirstPartnerId = "V07", WorkDate = DateTime.Now.Date.AddDays(-2), State = "CA", GrandTotal = 50.00m,
                                        Details = new List<FeeDetailDbModel>
                                        {
                                            new FeeDetailDbModel { Id = 1, FeeSummaryId = 1, Cmf = "12345", SecondPartnerId = "BG", SubTotal = 25.00m, TransactionCount = 10,State = "CA" },
                                            new FeeDetailDbModel { Id = 2, FeeSummaryId = 1, Cmf = "12346", SecondPartnerId = "BO", SubTotal = 25.00m, TransactionCount = 20 }
                                        }
                                       },
                new FeeSummaryDbModel { Id = 2, FirstPartnerId = "V07", WorkDate = DateTime.Now.Date.AddDays(-1), State = "CA", GrandTotal = 80.00m,
                                        Details = new List<FeeDetailDbModel>
                                        {
                                            new FeeDetailDbModel { Id = 3, FeeSummaryId = 2, Cmf = "12345", SecondPartnerId = "BG", SubTotal = 35.00m, TransactionCount = 10,State = "CA"  },
                                            new FeeDetailDbModel { Id = 4, FeeSummaryId = 2, Cmf = "12346", SecondPartnerId = "BO", SubTotal = 45.00m, TransactionCount = 20 }
                                        }
                                       },
                new FeeSummaryDbModel { Id = 3, FirstPartnerId = "V07", WorkDate = DateTime.Now.Date, State = "CA", GrandTotal = 50.00m,
                                        Details = new List<FeeDetailDbModel>
                                        {
                                            new FeeDetailDbModel { Id = 5, FeeSummaryId = 3, Cmf = "12345", SecondPartnerId = "BG", SubTotal = 25.00m, TransactionCount = 10 ,State = "CA" },
                                            new FeeDetailDbModel { Id = 6, FeeSummaryId = 3, Cmf = "12346", SecondPartnerId = "BO", SubTotal = 25.00m, TransactionCount = 20,State = "CA"  }
                                        }
                                       },

            };
            var feeDeatilRecords = feeSummaryRecords.SelectMany(x => x.Details).ToList();

            var mockFeeSummaryDbSet = feeSummaryRecords.AsQueryable().BuildMockDbSet();
            var mockFeeDetailDbSet = feeDeatilRecords.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.FeeSummary).Returns(mockFeeSummaryDbSet.Object);
            _mock.Setup(m => m.FeeDetails).Returns(mockFeeDetailDbSet.Object);

            _mock.Setup(m => m.FeeSummary.AddAsync(It.IsAny<FeeSummaryDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((FeeSummaryDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (feeSummaryRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeSummaryRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeSummaryRecords.Add(data);
                    return new ValueTask<EntityEntry<FeeSummaryDbModel>>();
                });

            _mock.Setup(m => m.FeeSummary.Add(It.IsAny<FeeSummaryDbModel>()))
                .Returns((FeeSummaryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (feeSummaryRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeSummaryRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeSummaryRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeSummary.Update(It.IsAny<FeeSummaryDbModel>()))
                .Returns((FeeSummaryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeSummaryRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = feeSummaryRecords.Find(r => r.Id == data.Id);
                    feeSummaryRecords.Remove(record);
                    feeSummaryRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeSummary.Remove(It.IsAny<FeeSummaryDbModel>()))
                .Returns((FeeSummaryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeSummaryRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    feeSummaryRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.FeeSummary.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = feeSummaryRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });

            _mock.Setup(m => m.FeeDetails.AddAsync(It.IsAny<FeeDetailDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((FeeDetailDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeDeatilRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeDeatilRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeDeatilRecords.Add(data);
                    return new ValueTask<EntityEntry<FeeDetailDbModel>>();
                });

            _mock.Setup(m => m.FeeDetails.Add(It.IsAny<FeeDetailDbModel>()))
                .Returns((FeeDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeDeatilRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeDeatilRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeDeatilRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeDetails.Update(It.IsAny<FeeDetailDbModel>()))
                .Returns((FeeDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeDeatilRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = feeDeatilRecords.Find(r => r.Id == data.Id);
                    feeDeatilRecords.Remove(record);
                    feeDeatilRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeDetails.Remove(It.IsAny<FeeDetailDbModel>()))
                .Returns((FeeDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (feeDeatilRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    feeDeatilRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.FeeDetails.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = feeDeatilRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupFeeCodes()
        {
            // Create data for the fee_codes table.
            var feeCodeData = new List<FeeCodeDbModel>()
            {
                new FeeCodeDbModel() { Id= 1, State = "CA", Category = "Registration", Code = "100",  Abbreviation = "Reg Fee", Description = "Regsitartion fee" },
                new FeeCodeDbModel() { Id= 2, State = "CA", Category = "Title", Code = "200",  Abbreviation = "Title Fee", Description = "Title fee" },
                new FeeCodeDbModel() { Id= 3, State = "CA", Category = "AVRS", Code = "1000",  Abbreviation = "AVRS Fee", Description = "Processing fee" },
            };

            // Create a dataset for the mock using the data above.
            var mockFeeCodeDbSet = feeCodeData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.FeeCodes).Returns(mockFeeCodeDbSet.Object);

            // Mock other required functions for FeeCodes.
            _mock.Setup(m => m.FeeCodes.AddAsync(It.IsAny<FeeCodeDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((FeeCodeDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Category) ||
                        string.IsNullOrEmpty(data.Code) ||
                        string.IsNullOrEmpty(data.Abbreviation) ||
                        string.IsNullOrEmpty(data.Description) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (feeCodeData.Find(r => r.State == data.State && r.Code == data.Code) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeCodeData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeCodeData.Add(data);
                    return new ValueTask<EntityEntry<FeeCodeDbModel>>();
                });
            _mock.Setup(m => m.FeeCodes.Add(It.IsAny<FeeCodeDbModel>()))
                .Returns((FeeCodeDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Category) ||
                        string.IsNullOrEmpty(data.Code) ||
                        string.IsNullOrEmpty(data.Abbreviation) ||
                        string.IsNullOrEmpty(data.Description) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (feeCodeData.Find(r => r.State == data.State && r.Code == data.Code) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = feeCodeData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    feeCodeData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeCodes.Update(It.IsAny<FeeCodeDbModel>()))
                .Returns((FeeCodeDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (feeCodeData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Category) ||
                        string.IsNullOrEmpty(data.Code) ||
                        string.IsNullOrEmpty(data.Abbreviation) ||
                        string.IsNullOrEmpty(data.Description) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = feeCodeData.Find(r => r.Id == data.Id);
                    feeCodeData.Remove(record);
                    feeCodeData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FeeCodes.Remove(It.IsAny<FeeCodeDbModel>()))
                .Returns((FeeCodeDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (feeCodeData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    feeCodeData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.FeeCodes.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = feeCodeData.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });
        }

        private void SetupInventoryPools()
        {
            // Create data for the inventory_pools table.
            var inventoryPoolData = new List<InventoryPoolsDbModel>
            {
                new InventoryPoolsDbModel { Id = 1, State = "CA", Cmf = "CAWHSE07", OfficeId = "V07" , SiteId = "BG", PoolType = "IPP" , Description ="Issuing Plate Pool"},
                new InventoryPoolsDbModel { Id = 2, State = "CA", Cmf = "CAWHSE07", OfficeId = "V07" , SiteId = "GG", PoolType = "UIP" , Description ="Unassigned Inventory Pool"},
                new InventoryPoolsDbModel { Id = 3, State = "CA", Cmf = "USER0002", OfficeId = "A51" , SiteId = "CD", PoolType = "IPP" , Description ="Local Issuing Pool"},
                new InventoryPoolsDbModel { Id = 4, State = "CA", Cmf = "USER0001", OfficeId = "D45" , SiteId = "DC", PoolType = "IPP" , Description ="Local Issuing Pool"},
                new InventoryPoolsDbModel { Id = 5, State = "CA", Cmf = "CAWHSE10", OfficeId = "B45" , SiteId = "NL", PoolType = "UIP" , Description ="Unassigned Inventory Pool"},
                new InventoryPoolsDbModel { Id = 6, State = "CA", Cmf = "CAWHSE10", OfficeId = "B45" , SiteId = "AL", PoolType = "IPP" , Description ="Local Inventory Pool 1 for B45"},
                new InventoryPoolsDbModel { Id = 7, State = "CA", Cmf = "CAWHSE10", OfficeId = "B45" , SiteId = "LA", PoolType = "IPP" , Description ="Local Inventory Pool 2 for B45"},
            };

            // Create a dataset for the mock using the data above.
            var mockInventoryPoolsDbSet = inventoryPoolData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.InventoryPools).Returns(mockInventoryPoolsDbSet.Object);

            // Mock other required functions for InventoryPools.
            _mock.Setup(m => m.InventoryPools.AddAsync(It.IsAny<InventoryPoolsDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((InventoryPoolsDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.OfficeId) ||
                        string.IsNullOrEmpty(data.SiteId) ||
                        string.IsNullOrEmpty(data.PoolType))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryPoolData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryPoolData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryPoolData.Add(data);
                    return new ValueTask<EntityEntry<InventoryPoolsDbModel>>();
                });

            _mock.Setup(m => m.InventoryPools.Add(It.IsAny<InventoryPoolsDbModel>()))
                .Returns((InventoryPoolsDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.OfficeId) ||
                        string.IsNullOrEmpty(data.SiteId) ||
                        string.IsNullOrEmpty(data.PoolType))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryPoolData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryPoolData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryPoolData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryPools.Update(It.IsAny<InventoryPoolsDbModel>()))
                .Returns((InventoryPoolsDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryPoolData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.OfficeId) ||
                        string.IsNullOrEmpty(data.SiteId) ||
                        string.IsNullOrEmpty(data.PoolType))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = inventoryPoolData.Find(r => r.Id == data.Id);
                    inventoryPoolData.Remove(record);
                    inventoryPoolData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryPools.Remove(It.IsAny<InventoryPoolsDbModel>()))
                .Returns((InventoryPoolsDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryPoolData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    inventoryPoolData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryPools.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = inventoryPoolData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupInventory()
        {
            // Create data for the inventory_pools table.
            var inventoryData = new List<InventoryDbModel>
            {
                new InventoryDbModel { Id = 1, State = "CA", Cmf = "CAWHSE07", Type = "292", Serial = "G0000676", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 2, StatusChangeDate = DateTime.Now.AddDays(-10)},
                new InventoryDbModel { Id = 2, State = "CA", Cmf = "CAWHSE07", Type = "01R", Serial = "2VUA664", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "A", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 2, StatusChangeDate = DateTime.Now.AddDays(-20)},
                new InventoryDbModel { Id = 3, State = "CA", Cmf = "CAWHSE07", Type = "292", Serial = "2VUA663", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-20)},
                new InventoryDbModel { Id = 4, State = "CA", Cmf = "CAWHSE07", Type = "292", Serial = "G0000676", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-20)},
                new InventoryDbModel { Id = 5, State = "CA", Cmf = "CAWHSE07", Type = "01R", Serial = "2VUA686", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-100)},
                new InventoryDbModel { Id = 6, State = "CA", Cmf = "CAWHSE07", Type = "01R", Serial = "2VUA683", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-90)},
                new InventoryDbModel { Id = 7, State = "CA", Cmf = "CAWHSE07", Type = "01R", Serial = "2VUA662", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-20)},
                new InventoryDbModel { Id = 8, State = "CA", Cmf = "CAWHSE07", Type = "01R", Serial = "2VUA660", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "A", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-100)},
                new InventoryDbModel { Id = 9, State = "CA", Cmf = "CAWHSE10", Type = "292", Serial = "B9000682", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 5, StatusChangeDate = DateTime.Now.AddDays(-90)},
                new InventoryDbModel { Id = 10, State = "CA", Cmf = "CAWHSE10", Type = "02R", Serial = "6J00680", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 5, StatusChangeDate = DateTime.Now.AddDays(-20)},
                new InventoryDbModel { Id = 11, State = "CA", Cmf = "TEST0001", Type = "01R", Serial = "2VUA786", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-80)},
                new InventoryDbModel { Id = 12, State = "CA", Cmf = "TEST0001", Type = "01R", Serial = "2VUA783", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-90)},
                new InventoryDbModel { Id = 13, State = "CA", Cmf = "TEST0001", Type = "01R", Serial = "2VUA762", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "A", Control = null, BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-100)},
                new InventoryDbModel { Id = 14, State = "CA", Cmf = "TEST0001", Type = "01R", Serial = "2VUA760", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "A", Control = "CNTRL123", BoxId = null, Notes = null, AssessedFee = null, PoolId = 1, StatusChangeDate = DateTime.Now.AddDays(-100)},                new InventoryDbModel { Id = 9, State = "CA", Cmf = "CAWHSE10", Type = "292", Serial = "B9000682", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = "CNTRL123", BoxId = null, Notes = null, AssessedFee = null, PoolId = 5, StatusChangeDate = DateTime.Now.AddDays(-90)},
                new InventoryDbModel { Id = 15, State = "CA", Cmf = "TEST0001", Type = "292", Serial = "B9000683", AgencyPoNumber = null, ClientPoNumber = null, AgencyCmf = null, InventorySiteId = null, IsSerialized = true, Items = null, CollatingNumber = null, Status = "IF", Control = "CNTRL123", BoxId = null, Notes = null, AssessedFee = null, PoolId = 5, StatusChangeDate = DateTime.Now.AddDays(-90)},

            };

            // Create a dataset for the mock using the data above.
            var mockInventoryDbSet = inventoryData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.Inventory).Returns(mockInventoryDbSet.Object);

            // Mock other required functions for InventoryPools.
            _mock.Setup(m => m.Inventory.AddAsync(It.IsAny<InventoryDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((InventoryDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Type) ||
                        string.IsNullOrEmpty(data.Serial) ||
                        string.IsNullOrEmpty(data.Status)
                        )
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryData.Add(data);
                    return new ValueTask<EntityEntry<InventoryDbModel>>();
                });

            _mock.Setup(m => m.Inventory.Add(It.IsAny<InventoryDbModel>()))
                .Returns((InventoryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Type) ||
                        string.IsNullOrEmpty(data.Serial) ||
                        string.IsNullOrEmpty(data.Status)
                        )
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Inventory.Update(It.IsAny<InventoryDbModel>()))
                .Returns((InventoryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Type) ||
                        string.IsNullOrEmpty(data.Serial) ||
                        string.IsNullOrEmpty(data.Status)
                        )
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = inventoryData.Find(r => r.Id == data.Id);
                    inventoryData.Remove(record);
                    inventoryData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Inventory.Remove(It.IsAny<InventoryDbModel>()))
                .Returns((InventoryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    inventoryData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.Inventory.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = inventoryData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupInventoryTypes()
        {
            // Create data for the inventory_pools table.
            var inventoryTypesData = new List<InventoryTypesDbModel>
            {
                new InventoryTypesDbModel { Id = 1, State ="CA", Type = "01R", Description = "Reflectorized Automobile Plate", IsSerialized = true, DmvType = "01R", DmvSubType = null, DmvYear = null, StandardPackageSize = 25, PackageStartsWith = null, RestrictedView = null, Status = "Active" ,Patterns = new List<InventoryPatternDbModel>{ new InventoryPatternDbModel() {TemplatePattern = "abc",BeginPattern = "a", EndPattern = "b",SequencePattern = "c" }  } },
                new InventoryTypesDbModel { Id = 2, State ="CA", Type = "292", Description = "Year Decal (XXX2)", IsSerialized = true, DmvType = "292", DmvSubType = null, DmvYear = null, StandardPackageSize = null, PackageStartsWith = null, RestrictedView = null, Status = "Active"  ,Patterns = new List<InventoryPatternDbModel>{ new InventoryPatternDbModel() {TemplatePattern = "abc",BeginPattern = "a", EndPattern = "b",SequencePattern = "c" }  } },
                new InventoryTypesDbModel { Id = 3, State ="CA", Type = "02R", Description = "Reflectorized Commercial Plate", IsSerialized = true, DmvType = "02R", DmvSubType = null, DmvYear = null, StandardPackageSize = null, PackageStartsWith = null, RestrictedView = null, Status = "Active" ,Patterns = new List<InventoryPatternDbModel>{ new InventoryPatternDbModel() {TemplatePattern = "abc",BeginPattern = "a", EndPattern = "b",SequencePattern = "c" }  } },
                new InventoryTypesDbModel { Id = 4, State ="CA", Type = "MS01", Description = "January Month Sticker", IsSerialized = false, DmvType = null, DmvSubType = null, DmvYear = null, StandardPackageSize = null, PackageStartsWith = null, RestrictedView = null, Status = "Active" ,Patterns = null },
                new InventoryTypesDbModel { Id = 5, State ="CA", Type = "MS02", Description = "Febuary Month Sticker", IsSerialized = false, DmvType = null, DmvSubType = null, DmvYear = null, StandardPackageSize = null, PackageStartsWith = null, RestrictedView = null, Status = "Active" ,Patterns = null }
            };

            // Create a dataset for the mock using the data above.
            var mockInventoryTypesDbSet = inventoryTypesData.AsQueryable().BuildMockDbSet();
            _mock.Setup(m => m.InventoryTypes).Returns(mockInventoryTypesDbSet.Object);

            // Mock other required functions for InventoryPools.
            _mock.Setup(m => m.InventoryTypes.AddAsync(It.IsAny<InventoryTypesDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((InventoryTypesDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Type) ||
                        string.IsNullOrEmpty(data.Description) ||
                        string.IsNullOrEmpty(data.DmvType)
                        )
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryTypesData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryTypesData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryTypesData.Add(data);
                    return new ValueTask<EntityEntry<InventoryTypesDbModel>>();
                });

            _mock.Setup(m => m.InventoryTypes.Add(It.IsAny<InventoryTypesDbModel>()))
                .Returns((InventoryTypesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Type) ||
                        string.IsNullOrEmpty(data.Description) ||
                        string.IsNullOrEmpty(data.DmvType)
                        )
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryTypesData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryTypesData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryTypesData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryTypes.Update(It.IsAny<InventoryTypesDbModel>()))
                .Returns((InventoryTypesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryTypesData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Type) ||
                        string.IsNullOrEmpty(data.Description) ||
                        string.IsNullOrEmpty(data.DmvType)
                        )
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = inventoryTypesData.Find(r => r.Id == data.Id);
                    inventoryTypesData.Remove(record);
                    inventoryTypesData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryTypes.Remove(It.IsAny<InventoryTypesDbModel>()))
                .Returns((InventoryTypesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryTypesData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    inventoryTypesData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryTypes.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = inventoryTypesData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupMiscellaneousCharges()
        {
            // Create data for the miscellaneous_charges table.
            var miscChargesDbData = new List<MiscellaneousChargesDbModel>()
            {
                new MiscellaneousChargesDbModel() { Id= 1, State = "CA", Cmf = "123456", Control= "ABCDEF12", MiscellaneousTransactionType = MiscellaneousTransactionType.Inventory, RunOn = DateTime.UtcNow.AddDays(-10), TotalCurrentEft = "10", CurrentEftDate = DateTime.UtcNow.AddDays(-8), Data = JsonDocument.Parse("{\"plate\":\"FZV456\"}") },
                new MiscellaneousChargesDbModel() { Id= 2, State = "CA", Cmf = "123457", Control= "ABCDEF13", MiscellaneousTransactionType = MiscellaneousTransactionType.Shipping, RunOn = DateTime.UtcNow.AddDays(-9), TotalCurrentEft = "10", CurrentEftDate = DateTime.UtcNow.AddDays(-7), Data = JsonDocument.Parse("{\"Bundle\":\"AZv1234\"}") },
                new MiscellaneousChargesDbModel() { Id= 3, State = "CA", Cmf = "123458", Control= "ABCDEF14", MiscellaneousTransactionType = MiscellaneousTransactionType.ReconciliationCheckRefund, RunOn = DateTime.UtcNow.AddDays(-8), TotalCurrentEft = "10", CurrentEftDate = DateTime.UtcNow.AddDays(-6), Data = JsonDocument.Parse("{\"CheckId\":111}") },
            };

            // Create a dataset for the mock using the data above.
            var mockMiscChargesDbSet = miscChargesDbData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.MiscellaneousCharges).Returns(mockMiscChargesDbSet.Object);

            // Mock other required functions for MiscellaneousCharges.
            _mock.Setup(m => m.MiscellaneousCharges.AddAsync(It.IsAny<MiscellaneousChargesDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((MiscellaneousChargesDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Control) ||
                        string.IsNullOrEmpty(data.MiscellaneousTransactionType) ||
                        data.Data == null)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (miscChargesDbData.Find(r => r.Cmf == data.Cmf && r.Control == data.Control) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = miscChargesDbData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    miscChargesDbData.Add(data);
                    return new ValueTask<EntityEntry<MiscellaneousChargesDbModel>>();
                });
            _mock.Setup(m => m.MiscellaneousCharges.Add(It.IsAny<MiscellaneousChargesDbModel>()))
                .Returns((MiscellaneousChargesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Control) ||
                        string.IsNullOrEmpty(data.MiscellaneousTransactionType) ||
                        data.Data == null)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (miscChargesDbData.Find(r => r.Cmf == data.Cmf && r.Control == data.Control) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = miscChargesDbData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    miscChargesDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.MiscellaneousCharges.Update(It.IsAny<MiscellaneousChargesDbModel>()))
                .Returns((MiscellaneousChargesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (miscChargesDbData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Control) ||
                        string.IsNullOrEmpty(data.MiscellaneousTransactionType) ||
                        data.Data == null)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = miscChargesDbData.Find(r => r.Id == data.Id);
                    miscChargesDbData.Remove(record);
                    miscChargesDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.MiscellaneousCharges.Remove(It.IsAny<MiscellaneousChargesDbModel>()))
                .Returns((MiscellaneousChargesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (miscChargesDbData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    miscChargesDbData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.MiscellaneousCharges.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = miscChargesDbData.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });

        }

        private void SetupStores()
        {
            // Create data for the company table.
            var stores = new List<StoresDbModel>()
            {
                new StoresDbModel (){ Cmf = "123456", State = "CA",Region = "01",WeekdayHours = "0000-2359",SatHours = "0000-2359",Dms = "CVR",Name = "TestCompany",PhysicalAddress1 = "11122 Test Ave",PhysicalCity = "Orange County",PhysicalState = "CA",PhysicalZip = "90210",MailingAddress1 = "11122 Test Ave",MailingCity = "Orange County",MailingState = "CA",MailingZip = "90210",BillingAddress1 = "11122 Test Ave",BillingCity = "Orange County",BillingState = "CA",BillingZip = "90210",Contact = "CVR",Phone = "5031112222",CDKEnterpriseId = "1E",CDKStoreId = "1S", CentralProcessingCmf = "NCMF1111", AtcID = "A123", AtcDealerID = "AD123", CarfaxID = "cf123", BillingType = "Monthly",IsTest=false, EftModel = "Legacy"},
                new StoresDbModel (){ Cmf = "123457", State = "CA",Region = "01",WeekdayHours = "0000-2359",SatHours = "0000-2359",Dms = "CVR",Name = "TestCompany",PhysicalAddress1 = "11122 Test Ave",PhysicalCity = "Orange County",PhysicalState = "CA",PhysicalZip = "90210",MailingAddress1 = "11122 Test Ave",MailingCity = "Orange County",MailingState = "CA",MailingZip = "90210",BillingAddress1 = "11122 Test Ave",BillingCity = "Orange County",BillingState = "CA",BillingZip = "90210",Contact = "CVR",Phone = "5031112222",CDKEnterpriseId = "1E",CDKStoreId = "1S", CentralProcessingCmf = "NCMF1111", AtcID = "A123", AtcDealerID = "AD123", CarfaxID = "cf123", BillingType = "Monthly",IsTest=false, EftModel = "CBE"},
                new StoresDbModel (){ Cmf = "123458", State = "CA",Region = "01",WeekdayHours = "0000-2359",SatHours = "0000-2359",Dms = "CVR",Name = "TestCompany",PhysicalAddress1 = "11122 Test Ave",PhysicalCity = "Orange County",PhysicalState = "CA",PhysicalZip = "90210",MailingAddress1 = "11122 Test Ave",MailingCity = "Orange County",MailingState = "CA",MailingZip = "90210",BillingAddress1 = "11122 Test Ave",BillingCity = "Orange County",BillingState = "CA",BillingZip = "90210",Contact = "CVR",Phone = "5031112222",CDKEnterpriseId = "1E",CDKStoreId = "1S", CentralProcessingCmf = "NCMF1111", AtcID = "A123", AtcDealerID = "AD123", CarfaxID = "cf123", BillingType = "Monthly",IsTest=false, EftModel = "Legacy"},
            };

            // Create a dataset for the mock using the data above.
            var mockstoresDbSet = stores.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.Stores).Returns(mockstoresDbSet.Object);

            // Mock other required functions for stores.
            _mock.Setup(m => m.Stores.AddAsync(It.IsAny<StoresDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((StoresDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Region))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (stores.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    stores.Add(data);
                    return new ValueTask<EntityEntry<StoresDbModel>>();
                });

            // Mock other required functions for stores.
            _mock.Setup(m => m.Stores.Add(It.IsAny<StoresDbModel>()))
                .Returns((StoresDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Region))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (stores.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    stores.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Stores.Update(It.IsAny<StoresDbModel>()))
                .Returns((StoresDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }
                    if (string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Region))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = stores.Find(r => r.Cmf == data.Cmf);
                    stores.Remove(record);
                    stores.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Stores.Remove(It.IsAny<StoresDbModel>()))
                .Returns((StoresDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (stores.Find(c => c.Cmf == data.Cmf) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    stores.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.Stores.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = stores.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });
        }

        private void SetupDmvLog()
        {
            // Create data for the DmvLogDb table.
            var dmvLogDbs = new List<DmvLogDbModel>()
            {
               new DmvLogDbModel (){
                Id = 1,
                State = "CA",
                Cmf = "TEST0001",
                TransactionType = TransactionType.NewIssue,
                TransactionOperation = TransactionOperation.Complete,
                TransactionStatus = TransactionStatus.Success,
                ProductVersion = "CCAC0100",
                ComputerId = Guid.NewGuid().ToString(),
                RequestId = Guid.NewGuid().ToString(),
                Control = Guid.NewGuid().ToString(),
                Dms = "MAN",
                DmsInterface = "MAN",
                OwnerName = "Mike Barnes",
                Vin = "12345678901234567",
                Plate = "ABC123",
                ProcessedBy = "MWB",
                ProcessedOn = DateTime.Now,
                TotalTaxAmount = "1000.00",
                TotalRegistrationFee = "100.00",
                TotalTitleFee = "10.00",
                BillingFlags = BillingFlags.BillingCharge
               },
               new DmvLogDbModel (){
                Id =2,
                State = "CA",
                Cmf = "TEST0002",
                TransactionType = TransactionType.NewIssue,
                TransactionOperation = TransactionOperation.Complete,
                TransactionStatus = TransactionStatus.Success,
                ProductVersion = "CCAC0100",
                ComputerId = Guid.NewGuid().ToString(),
                RequestId = Guid.NewGuid().ToString(),
                Control = Guid.NewGuid().ToString(),
                Dms = "MAN",
                DmsInterface = "MAN",
                OwnerName = "Mike Barnes",
                Vin = "12345678901234567",
                Plate = "ABC123",
                ProcessedBy = "MWB",
                ProcessedOn = DateTime.Now,
                TotalTaxAmount = "1000.00",
                TotalRegistrationFee = "100.00",
                TotalTitleFee = "10.00",
                BillingFlags = BillingFlags.BillingCharge
               }
            };

            // Create a dataset for the mock using the data above.
            var mock = dmvLogDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.DmvLog).Returns(mock.Object);

            // Mock other required functions for DMVLOG.
            _mock.Setup(m => m.DmvLog.AddAsync(It.IsAny<DmvLogDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((DmvLogDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (dmvLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    dmvLogDbs.Add(data);
                    return new ValueTask<EntityEntry<DmvLogDbModel>>();
                });

            // Mock other required functions for DMVLog.
            _mock.Setup(m => m.DmvLog.Add(It.IsAny<DmvLogDbModel>()))
                .Returns((DmvLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (dmvLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = dmvLogDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    dmvLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DmvLog.Update(It.IsAny<DmvLogDbModel>()))
                .Returns((DmvLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }
                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = dmvLogDbs.Find(r => r.Id == data.Id);
                    dmvLogDbs.Remove(record);
                    dmvLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DmvLog.Remove(It.IsAny<DmvLogDbModel>()))
                .Returns((DmvLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (dmvLogDbs.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    dmvLogDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.DmvLog.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = dmvLogDbs.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });



        }

        private void SetupInventoryHistory()
        {
            // Create data for the inventory history table.
            var inventoryHistoryModel = new List<InventoryHistoryDbModel>
            {
                new InventoryHistoryDbModel()
                {
                    Id = 1,
                    InventoryId = 1,
                    State = "CA",
                    Cmf = "123456",
                    Type = "01R",
                    Serial = "Ser0001",
                    AgencyPoNumber = "PO0001",
                    ClientPoNumber = "PO0001",
                    AgencyCmf = "CA0001",
                    InventorySiteId = "TC1",
                    IsSerialized = true,
                    ReceivedOn = DateTime.Now,
                    Status = InventoryStatusEnum.AvailableSerial.Value(),
                    Control = "Ctrl001",
                    Notes = "From Integration Test for Inventory History",
                    AssessedFee = "",
                    PoolId = 999999
                },
                new InventoryHistoryDbModel()
                {
                    Id = 2,
                    InventoryId = 1,
                    State = "CA",
                    Cmf = "123456",
                    Type = "01R",
                    Serial = "Ser0001",
                    AgencyPoNumber = "PO0001",
                    ClientPoNumber = "PO0001",
                    AgencyCmf = "CA0001",
                    InventorySiteId = "TC1",
                    IsSerialized = true,
                    ReceivedOn = DateTime.Now,
                    Status = InventoryStatusEnum.IssuedFinal.Value(),
                    Control = "Ctrl001",
                    Notes = "From Integration Test for Inventory History",
                    AssessedFee = "",
                    PoolId = 999999
                }
            };

            // Create a dataset for the mock using the data above.
            var mockInventoryHistorysDbSet = inventoryHistoryModel.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.InventoryHistory).Returns(mockInventoryHistorysDbSet.Object);

            // Mock other required functions for InventoryHistory.
            _mock.Setup(m => m.InventoryHistory.AddAsync(It.IsAny<InventoryHistoryDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((InventoryHistoryDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                       string.IsNullOrEmpty(data.Serial) ||
                       string.IsNullOrEmpty(data.Type) ||
                       string.IsNullOrEmpty(data.Cmf))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryHistoryModel.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryHistoryModel.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryHistoryModel.Add(data);
                    return new ValueTask<EntityEntry<InventoryHistoryDbModel>>();
                });

            _mock.Setup(m => m.InventoryHistory.Add(It.IsAny<InventoryHistoryDbModel>()))
                .Returns((InventoryHistoryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                                 string.IsNullOrEmpty(data.Serial) ||
                                 string.IsNullOrEmpty(data.Type) ||
                                 string.IsNullOrEmpty(data.Cmf))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryHistoryModel.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryHistoryModel.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryHistoryModel.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryHistory.Update(It.IsAny<InventoryHistoryDbModel>()))
                .Returns((InventoryHistoryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryHistoryModel.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                                 string.IsNullOrEmpty(data.Serial) ||
                                 string.IsNullOrEmpty(data.Type) ||
                                 string.IsNullOrEmpty(data.Cmf))


                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = inventoryHistoryModel.Find(r => r.Id == data.Id);
                    inventoryHistoryModel.Remove(record);
                    inventoryHistoryModel.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryHistory.Remove(It.IsAny<InventoryHistoryDbModel>()))
                .Returns((InventoryHistoryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (inventoryHistoryModel.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    inventoryHistoryModel.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryHistory.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = inventoryHistoryModel.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });


        }

        private void SetupRegion()
        {
            // Create data for the region  table.
            var regionDbs = new List<RegionDbModel>();
            //{
            //    new RegionDbModel()
            //    {
            //        State = "OR",
            //        Region = "01",
            //        Name = "Test 1"
            //    },
            //    new RegionDbModel()
            //    {
            //        State = "OR",
            //        Region = "02",
            //        Name = "Test 2"
            //    },
            //    new RegionDbModel()
            //    {
            //        State = "CA",
            //        Region = "03",
            //        Name = "Test 3"
            //    }
            //};

            // Create a dataset for the mock using the data above.
            var mockRegionbSet = regionDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.Regions).Returns(mockRegionbSet.Object);

            // Mock other required functions for Region.
            _mock.Setup(m => m.Regions.AddAsync(It.IsAny<RegionDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((RegionDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                       string.IsNullOrEmpty(data.Region) ||
                        string.IsNullOrEmpty(data.Name))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (regionDbs.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    regionDbs.Add(data);
                    return new ValueTask<EntityEntry<RegionDbModel>>();
                });

            _mock.Setup(m => m.Regions.Add(It.IsAny<RegionDbModel>()))
                .Returns((RegionDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                         string.IsNullOrEmpty(data.Region) ||
                        string.IsNullOrEmpty(data.Name
                        ))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (regionDbs.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    regionDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Regions.Update(It.IsAny<RegionDbModel>()))
                .Returns((RegionDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (regionDbs.Find(c => c.State == data.State) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Region);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Region) ||
                         string.IsNullOrEmpty(data.Name))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = regionDbs.Find(r => r.Region == data.Region);
                    regionDbs.Remove(record);
                    regionDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Regions.Remove(It.IsAny<RegionDbModel>()))
                .Returns((RegionDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (regionDbs.Find(c => c.State == data.State) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    regionDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.Regions.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = regionDbs.Find(r => r.State == keyValues[0].ToString());

                    return result;
                });


        }

        private void SetupRegionEft()
        {
            var regionEftDbs = new List<RegionEftDbModel>()
            {
                { new RegionEftDbModel { State = "OR", Region = "01", Status = "APPROVED", AbaNumber = "12345", AccountNumber = "54321", AccountType = "SAV", AccountName = "Test Account", updated_by = "NB" } },
                { new RegionEftDbModel { State = "OR", Region = "02", Status = "APPROVED", AbaNumber = "12345", AccountNumber = "54321", AccountType = "SAV", AccountName = "Test Account", updated_by = "NB" } },
                { new RegionEftDbModel { State = "CA", Region = "02", Status = "APPROVED", AbaNumber = "12345", AccountNumber = "54321", AccountType = "SAV", AccountName = "Test Account", updated_by = "NB" } },
            };

            // Create a dataset for the mock using the data above.
            var mockRegionEftDbSet = regionEftDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.RegionEft).Returns(mockRegionEftDbSet.Object);

            // Mock other required functions for RegionEFT.
            _mock.Setup(m => m.RegionEft.AddAsync(It.IsAny<RegionEftDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((RegionEftDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                       string.IsNullOrEmpty(data.Region) ||
                        string.IsNullOrEmpty(data.AbaNumber) ||
                        string.IsNullOrEmpty(data.AccountType) ||
                        string.IsNullOrEmpty(data.AccountNumber) ||
                        string.IsNullOrEmpty(data.AccountName))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (regionEftDbs.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    regionEftDbs.Add(data);
                    return new ValueTask<EntityEntry<RegionEftDbModel>>();
                });

            _mock.Setup(m => m.RegionEft.Add(It.IsAny<RegionEftDbModel>()))
                .Returns((RegionEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                         string.IsNullOrEmpty(data.Region) ||
                        string.IsNullOrEmpty(data.AbaNumber) ||
                        string.IsNullOrEmpty(data.AccountType) ||
                        string.IsNullOrEmpty(data.AccountNumber) ||
                        string.IsNullOrEmpty(data.AccountName))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (regionEftDbs.Find(r => r.State == data.State && r.Region == data.Region) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    // Ensure Foreign key constraint is satisified
                    //var context = new PostgreSqlContextMock().GetMocked();
                    //var regionProvider = new RegionsProvider(context);

                    //if (regionProvider.ReadByStateRegionAsync(data.State, data.Region).Result == null)
                    //{
                    //    throw new DbUpdateException("Mocked ForeignKey Flag.");
                    //}

                    regionEftDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.RegionEft.Update(It.IsAny<RegionEftDbModel>()))
                .Returns((RegionEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (regionEftDbs.Find(c => c.State == data.State) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Region);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Region) ||
                         string.IsNullOrEmpty(data.AbaNumber) ||
                         string.IsNullOrEmpty(data.AccountType) ||
                         string.IsNullOrEmpty(data.AccountNumber) ||
                         string.IsNullOrEmpty(data.AccountName))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = regionEftDbs.Find(r => r.State == data.State);
                    regionEftDbs.Remove(record);
                    regionEftDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.RegionEft.Remove(It.IsAny<RegionEftDbModel>()))
                .Returns((RegionEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (regionEftDbs.Find(c => c.State == data.State) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    regionEftDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.RegionEft.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = regionEftDbs.Find(r => r.State == keyValues[0].ToString());

                    return result;
                });

        }

        private void SetupSeedData()
        {

            // Create data for the SeedData table.
            var record = new SeedDataDbModel();
            record.Id = 1;
            record.Property = "TransactionOperation";
            record.States = new List<string>();
            record.States.Add("CA");
            record.CvrCode = "test";
            record.StateCodes = new List<string>();
            record.StateCodes.Add("TEST");
            record.Description = "This is a test";
            record.Display = "Unit Test";
            var seedDataDbs = new List<SeedDataDbModel>() { record };


            // Create a dataset for the mock using the data above.
            var mockseedDataDbSet = seedDataDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.SeedData).Returns(mockseedDataDbSet.Object);

            // Mock other required functions for SeedData.
            _mock.Setup(m => m.SeedData.AddAsync(It.IsAny<SeedDataDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((SeedDataDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Property) ||
                       data.States?.Any() == false)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (seedDataDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = seedDataDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    seedDataDbs.Add(data);
                    return new ValueTask<EntityEntry<SeedDataDbModel>>();
                });

            _mock.Setup(m => m.SeedData.Add(It.IsAny<SeedDataDbModel>()))
                .Returns((SeedDataDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Property) ||
                       data.States?.Any() == false)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (seedDataDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    seedDataDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.SeedData.Update(It.IsAny<SeedDataDbModel>()))
                .Returns((SeedDataDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (seedDataDbs.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Property);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Property) ||
                      data.States?.Any() == false)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = seedDataDbs.Find(r => r.Id == data.Id);
                    seedDataDbs.Remove(record);
                    seedDataDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.SeedData.Remove(It.IsAny<SeedDataDbModel>()))
                .Returns((SeedDataDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (seedDataDbs.Find(c => c.Property == data.Property) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    seedDataDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.SeedData.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = seedDataDbs.Find(r => r.Property == keyValues[0].ToString());

                    return result;
                });


        }

        private void SetupStateLog()
        {

            var _record = new StateLogDbModel();
            _record.Id = 1;
            _record.State = "OR";
            _record.Cmf = "TEST001";
            _record.ComputerId = "333333";
            _record.ClientIp = "127.0.0.1";
            _record.RequestId = Guid.NewGuid().ToString();
            _record.Control = Guid.NewGuid().ToString();
            _record.StartDtm = DateTime.UtcNow;
            _record.EndDtm = DateTime.UtcNow.AddDays(1);
            _record.Request = "Test Request";
            _record.Response = "Test Response";

            // Create data for the StateLogDb table.
            var stateLogDbs = new List<StateLogDbModel>() { _record };

            // Create a dataset for the mock using the data above.
            var mockstateLogDbsDbSet = stateLogDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.StateLog).Returns(mockstateLogDbsDbSet.Object);

            // Mock other required functions for StateLogDb.
            _mock.Setup(m => m.StateLog.AddAsync(It.IsAny<StateLogDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((StateLogDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (stateLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = stateLogDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    stateLogDbs.Add(data);
                    return new ValueTask<EntityEntry<StateLogDbModel>>();
                });

            _mock.Setup(m => m.StateLog.Add(It.IsAny<StateLogDbModel>()))
                .Returns((StateLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (stateLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    stateLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.StateLog.Update(It.IsAny<StateLogDbModel>()))
                .Returns((StateLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (stateLogDbs.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.State);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = stateLogDbs.Find(r => r.State == data.State);
                    stateLogDbs.Remove(record);
                    stateLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.StateLog.Remove(It.IsAny<StateLogDbModel>()))
                .Returns((StateLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (stateLogDbs.Find(c => c.State == data.State) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    stateLogDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.StateLog.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = stateLogDbs.Find(r => r.State == keyValues[0].ToString());

                    return result;
                });

        }

        private void SetupTransaction()
        {

            var result = new TransactionDetailDbModel
            {
                Id = 1,
                State = "CA",
                Cmf = "TEST0001",
                Control = "Test01",
                RequestId = "111-111-111"
            };
            result.TransactionDetail = JsonDocument.Parse("{\"Test\": \"Hello\"}");

            var transactionDb = new TransactionDbModel
            {
                Id = 1,
                Cmf = "TEST0001",
                State = "CA",
                RequestId = "111-111-111",
                Control = "Test01",
                TransactionType = "NewIssue",
                TransactionOperation = "GetFees",
                TransactionStatus = "Success",
                TransactionVersion = "1",
                ProductVersion = "CCAC0100"
            };
            transactionDb.Details = new List<TransactionDetailDbModel>();
            transactionDb.Details.Add(result);
            // Create data for the Transaction table.
            var transactionDbs = new List<TransactionDbModel>() { transactionDb };

            // Create a dataset for the mock using the data above.
            var mocktransactionDbSet = transactionDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.Transactions).Returns(mocktransactionDbSet.Object);

            // Mock other required functions for Transaction.
            _mock.Setup(m => m.Transactions.AddAsync(It.IsAny<TransactionDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((TransactionDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    transactionDbs.Add(data);
                    return new ValueTask<EntityEntry<TransactionDbModel>>();
                });

            _mock.Setup(m => m.Transactions.Add(It.IsAny<TransactionDbModel>()))
                .Returns((TransactionDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    transactionDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Transactions.Update(It.IsAny<TransactionDbModel>()))
                .Returns((TransactionDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (transactionDbs.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Cmf);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = transactionDbs.Find(r => r.Cmf == data.Cmf);
                    transactionDbs.Remove(record);
                    transactionDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Transactions.Remove(It.IsAny<TransactionDbModel>()))
                .Returns((TransactionDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (transactionDbs.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    transactionDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.Transactions.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = transactionDbs.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });

        }

        private void SetupTransactionDetail()
        {

            var _record = new TransactionDetailDbModel();
            _record.Id = 1;
            _record.TransactionId = 999999;
            _record.State = "CA";
            _record.Cmf = "TEST01";
            _record.ClientIp = "127.0.0.1";
            _record.ComputerId = Guid.NewGuid().ToString();
            _record.RequestId = Guid.NewGuid().ToString();
            _record.Control = "1234";
            _record.Transaction = new TransactionDbModel()
            {
                Id = 1,
                State = "CA",
                Cmf = "TEST0001",
                Control = "Test01",
                TransactionType = "NewIssue",
                TransactionOperation = "GetFees",
                TransactionStatus = "Success",
                TransactionVersion = "1",
                ProductVersion = "CCAC0100",
            };
            _record.TransactionDetail = JsonDocument.Parse(JsonSerializer.Serialize("{setting1: Testing, setting2: Provider}"));
            // Create data for the TransactionDetail  table.
            var transactionDetailDbs = new List<TransactionDetailDbModel>() { _record };

            // Create a dataset for the mock using the data above.
            var mocktransactionDetailDbSet = transactionDetailDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.TransactionDetails).Returns(mocktransactionDetailDbSet.Object);

            // Mock other required functions for TransactionDetail.
            _mock.Setup(m => m.TransactionDetails.AddAsync(It.IsAny<TransactionDetailDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((TransactionDetailDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionDetailDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionDetailDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    transactionDetailDbs.Add(data);
                    return new ValueTask<EntityEntry<TransactionDetailDbModel>>();
                });

            _mock.Setup(m => m.TransactionDetails.Add(It.IsAny<TransactionDetailDbModel>()))
                .Returns((TransactionDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionDetailDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionDetailDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    transactionDetailDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionDetails.Update(It.IsAny<TransactionDetailDbModel>()))
                .Returns((TransactionDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (transactionDetailDbs.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Cmf);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = transactionDetailDbs.Find(r => r.Cmf == data.Cmf);
                    transactionDetailDbs.Remove(record);
                    transactionDetailDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionDetails.Remove(It.IsAny<TransactionDetailDbModel>()))
                .Returns((TransactionDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (transactionDetailDbs.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    transactionDetailDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionDetails.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = transactionDetailDbs.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });


        }

        private void SetupTransactionLog()
        {
            var _record = new TransactionLogDbModel();
            _record.Id = 1;
            _record.State = "CA";
            _record.Cmf = "TEST01";
            _record.ComputerId = "12345678";
            _record.ClientIp = "127.0.0.1";
            _record.Control = "1234";
            _record.ProductVersion = "CCAC0100";
            _record.ClientVersion = "1.0.0.0";
            _record.StartDtm = DateTime.UtcNow;
            _record.EndDtm = DateTime.UtcNow;
            _record.Request = "This is a request record.";
            _record.Response = "This is a response record.";

            // Create data for the TransactionLog table.
            var transactionLogDbs = new List<TransactionLogDbModel>() { _record };

            // Create a dataset for the mock using the data above.
            var mocktransactionLogDbsSet = transactionLogDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.TransactionLog).Returns(mocktransactionLogDbsSet.Object);

            // Mock other required functions for TransactionLog.
            _mock.Setup(m => m.TransactionLog.AddAsync(It.IsAny<TransactionLogDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((TransactionLogDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionLogDbs.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionLogDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    transactionLogDbs.Add(data);
                    return new ValueTask<EntityEntry<TransactionLogDbModel>>();
                });

            _mock.Setup(m => m.TransactionLog.Add(It.IsAny<TransactionLogDbModel>()))
                .Returns((TransactionLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionLogDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    transactionLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionLog.Update(It.IsAny<TransactionLogDbModel>()))
                .Returns((TransactionLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (transactionLogDbs.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Cmf);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = transactionLogDbs.Find(r => r.Cmf == data.Cmf);
                    transactionLogDbs.Remove(record);
                    transactionLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionLog.Remove(It.IsAny<TransactionLogDbModel>()))
                .Returns((TransactionLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (transactionLogDbs.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    transactionLogDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionLog.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = transactionLogDbs.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });
        }

        private void SetupPurchaseOrder()
        {

            // Create data for the PurchaseOrder table.
            var purchaseOrderDbs = new List<PurchaseOrderDbModel>
            {
                { new PurchaseOrderDbModel { Id = 1, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.Date, Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderDbModel { Id = 2, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.AddDays(-1).Date, Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderDbModel { Id = 3, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.AddDays(-2).Date, Status = PurchaseOrderStatus.Closed, ShipmentTracking = new List<string> { "12345", "12346" }.AsJsonDocument(), InventorySite = "BG", created_by = "TEST" } },
                { new PurchaseOrderDbModel { Id = 4, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.AddDays(-3).Date, Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderDbModel { Id = 5, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.AddDays(-4).Date, Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderDbModel { Id = 10, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.AddDays(-2).Date, Status = PurchaseOrderStatus.Deleted, ShipmentTracking = new List<string> { "12345", "12346" }.AsJsonDocument(), InventorySite = "BG", created_by = "TEST" } },
                { new PurchaseOrderDbModel { Id = 11, State = "CA", Cmf = "TEST0001", OfficeId = "V07", SiteId = "BG", OrderBy = "TEST", OrderDate = DateTime.Now.AddDays(-2).Date, Status = PurchaseOrderStatus.Closed, ShipmentTracking = new List<string> { "12345", "12346" }.AsJsonDocument(), InventorySite = "BG", created_by = "TEST" } }
            };

            purchaseOrderDbs[0].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 1, PurchaseOrderId = 1, InventoryType = "01R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 2, PurchaseOrderId = 1, InventoryType = "02R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 3, PurchaseOrderId = 1, InventoryType = "03R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 4, PurchaseOrderId = 1, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } }
            };

            purchaseOrderDbs[1].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 5, PurchaseOrderId = 2, InventoryType = "01R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 6, PurchaseOrderId = 2, InventoryType = "02R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 7, PurchaseOrderId = 2, InventoryType = "03R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 8, PurchaseOrderId = 2, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } }
            };

            purchaseOrderDbs[2].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 9, PurchaseOrderId = 3, InventoryType = "01R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Closed, created_by = "TEST" } }
            };

            purchaseOrderDbs[2].PurchaseOrderLineItems[0].ItemDetails = new List<PurchaseOrderItemDetailDbModel>
            {
                { new PurchaseOrderItemDetailDbModel { Id = 1, PurchaseOrderLineItemId = 9, State = "CA", Status = InventoryStatusEnum.Available.Value(), InventoryType = "01R", BeginningSerial = "AAA001", EndingSerial = "AAA100", QuantityShipped = 100 } }
            };

            purchaseOrderDbs[3].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 10, PurchaseOrderId = 4, InventoryType = "01R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 11, PurchaseOrderId = 4, InventoryType = "02R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 12, PurchaseOrderId = 4, InventoryType = "03R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 13, PurchaseOrderId = 4, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } }
            };

            purchaseOrderDbs[4].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 14, PurchaseOrderId = 5, InventoryType = "01R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 15, PurchaseOrderId = 5, InventoryType = "02R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 16, PurchaseOrderId = 5, InventoryType = "03R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 17, PurchaseOrderId = 5, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } }
            };

            purchaseOrderDbs[5].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 18, PurchaseOrderId = 10, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Deleted, created_by = "TEST" } }
            };

            purchaseOrderDbs[6].PurchaseOrderLineItems = new List<PurchaseOrderLineItemDbModel>
            {
                { new PurchaseOrderLineItemDbModel { Id = 19, PurchaseOrderId = 11, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Open, created_by = "TEST" } },
                { new PurchaseOrderLineItemDbModel { Id = 20, PurchaseOrderId = 11, InventoryType = "04R", QuantityOrdered = 100, State = "CA", Status = PurchaseOrderStatus.Deleted, created_by = "TEST" } }
            };

            // Create a dataset for the mock using the data above.
            var mockpurchaseOrderDbSet = purchaseOrderDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.PurchaseOrder).Returns(mockpurchaseOrderDbSet.Object);

            // Mock other required functions for PurchaseOrder.
            _mock.Setup(m => m.PurchaseOrder.AddAsync(It.IsAny<PurchaseOrderDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((PurchaseOrderDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        data.PurchaseOrderLineItems.Any() == false || data.PurchaseOrderLineItems.Exists(i => i.QuantityOrdered == 0 || string.IsNullOrEmpty(i.InventoryType)))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (purchaseOrderDbs.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = purchaseOrderDbs.Count > 0 ? purchaseOrderDbs.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    purchaseOrderDbs.Add(data);
                    return new ValueTask<EntityEntry<PurchaseOrderDbModel>>();
                });

            _mock.Setup(m => m.PurchaseOrder.Add(It.IsAny<PurchaseOrderDbModel>()))
                .Returns((PurchaseOrderDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                         data.PurchaseOrderLineItems.Any() == false || data.PurchaseOrderLineItems.Exists(i => i.QuantityOrdered == 0 || string.IsNullOrEmpty(i.InventoryType)))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (purchaseOrderDbs.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = purchaseOrderDbs.Count > 0 ? purchaseOrderDbs.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    purchaseOrderDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.PurchaseOrder.Update(It.IsAny<PurchaseOrderDbModel>()))
                .Returns((PurchaseOrderDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (purchaseOrderDbs.Find(c => c.Cmf == data.Cmf) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Cmf);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        data.PurchaseOrderLineItems.Any() == false || data.PurchaseOrderLineItems.Exists(i => i.QuantityOrdered == 0 || string.IsNullOrEmpty(i.InventoryType)))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = purchaseOrderDbs.Find(r => r.Cmf == data.Cmf);
                    purchaseOrderDbs.Remove(record);
                    purchaseOrderDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.PurchaseOrder.Remove(It.IsAny<PurchaseOrderDbModel>()))
                .Returns((PurchaseOrderDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (purchaseOrderDbs.Find(c => c.Cmf == data.Cmf) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    purchaseOrderDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.PurchaseOrder.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = purchaseOrderDbs.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });
        }

        private void SetupInventoryTransferLog()
        {
            // Create data for the InventoryTransferLogDb table.
            var _dbModel = new InventoryTransferLogDbModel();
            _dbModel.Id = 1;
            _dbModel.ActionDate = DateTime.UtcNow.AddDays(-10);
            _dbModel.created_by = "dev";
            _dbModel.created_on = DateTime.UtcNow;
            _dbModel.Description = "Test";
            _dbModel.Cmf = "CAWHSE07";
            _dbModel.FromOfficeId = "12";
            _dbModel.FromSiteId = "14";
            _dbModel.InventoryType = "Test1";
            _dbModel.LogDate = DateTime.Now;
            _dbModel.Quantity = 2;
            _dbModel.RangeEnd = "23";
            _dbModel.Status = "A";
            _dbModel.TargetCmf = "TEST0001";
            _dbModel.ToOfficeId = "21";
            _dbModel.ToSiteId = "22";
            _dbModel.updated_by = "dev";
            _dbModel.updated_on = DateTime.UtcNow;
            _dbModel.UserID = "dev";
            _dbModel.State = "CA";


            var inventoryTransferLogDbs = new List<InventoryTransferLogDbModel>() { _dbModel };

            // Create a dataset for the mock using the data above.
            var mock = inventoryTransferLogDbs.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.InventoryTransferLog).Returns(mock.Object);

            // Mock other required functions for DMVLOG.
            _mock.Setup(m => m.InventoryTransferLog.AddAsync(It.IsAny<InventoryTransferLogDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((InventoryTransferLogDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.FromOfficeId) || string.IsNullOrEmpty(data.FromSiteId) || string.IsNullOrEmpty(data.TargetCmf) || string.IsNullOrEmpty(data.ToOfficeId) || string.IsNullOrEmpty(data.ToSiteId) || string.IsNullOrEmpty(data.UserID))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryTransferLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryTransferLogDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryTransferLogDbs.Add(data);
                    return new ValueTask<EntityEntry<InventoryTransferLogDbModel>>();
                });

            // Mock other required functions for DMVLog.
            _mock.Setup(m => m.InventoryTransferLog.Add(It.IsAny<InventoryTransferLogDbModel>()))
                .Returns((InventoryTransferLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.FromOfficeId) || string.IsNullOrEmpty(data.FromSiteId) || string.IsNullOrEmpty(data.TargetCmf) || string.IsNullOrEmpty(data.ToOfficeId) || string.IsNullOrEmpty(data.ToSiteId) || string.IsNullOrEmpty(data.UserID))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (inventoryTransferLogDbs.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = inventoryTransferLogDbs.Max(z => z.Id);
                    data.Id = maxId + 1;
                    inventoryTransferLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryTransferLog.Update(It.IsAny<InventoryTransferLogDbModel>()))
                .Returns((InventoryTransferLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }
                    if (string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.FromOfficeId) || string.IsNullOrEmpty(data.FromSiteId) || string.IsNullOrEmpty(data.TargetCmf) || string.IsNullOrEmpty(data.ToOfficeId) || string.IsNullOrEmpty(data.ToSiteId) || string.IsNullOrEmpty(data.UserID))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = inventoryTransferLogDbs.Find(r => r.Id == data.Id);
                    inventoryTransferLogDbs.Remove(record);
                    inventoryTransferLogDbs.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryTransferLog.Remove(It.IsAny<InventoryTransferLogDbModel>()))
                .Returns((InventoryTransferLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (inventoryTransferLogDbs.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    inventoryTransferLogDbs.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryTransferLog.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = inventoryTransferLogDbs.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });
        }

        private void SetupInventoryReOrderPoint()
        {

            var InventoryReOrderPointDb = new List<InventoryReOrderPointDbModel>()
            {
                { new InventoryReOrderPointDbModel () { Id = 11 ,State = "CA" , Cmf = "123456", InventoryType = "01R", ReOrderPoint = 02 } },
                { new InventoryReOrderPointDbModel () { Id = 22 ,State = "CA" , Cmf = "123456", InventoryType = "01R", ReOrderPoint = 03 } },
                { new InventoryReOrderPointDbModel() { Id = 33, State = "CA", Cmf = "123456", InventoryType = "01R", ReOrderPoint = 04 } }
            };

            // Create a dataset for the mock using the data above.
            var mock = InventoryReOrderPointDb.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.InventoryReOrderPoint).Returns(mock.Object);

            // Mock other required functions for DMVLOG.
            _mock.Setup(m => m.InventoryReOrderPoint.AddAsync(It.IsAny<InventoryReOrderPointDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((InventoryReOrderPointDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.InventoryType) || string.IsNullOrEmpty(Convert.ToString(data.ReOrderPoint)))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (InventoryReOrderPointDb.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = InventoryReOrderPointDb.Max(z => z.Id);
                    data.Id = maxId + 1;
                    InventoryReOrderPointDb.Add(data);
                    return new ValueTask<EntityEntry<InventoryReOrderPointDbModel>>();
                });

            _mock.Setup(m => m.InventoryReOrderPoint.Add(It.IsAny<InventoryReOrderPointDbModel>()))
                .Returns((InventoryReOrderPointDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.InventoryType) || string.IsNullOrEmpty(Convert.ToString(data.ReOrderPoint)))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (InventoryReOrderPointDb.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = InventoryReOrderPointDb.Max(z => z.Id);
                    data.Id = maxId + 1;
                    InventoryReOrderPointDb.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryReOrderPoint.Update(It.IsAny<InventoryReOrderPointDbModel>()))
                .Returns((InventoryReOrderPointDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }
                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.Cmf) || string.IsNullOrEmpty(data.InventoryType) || string.IsNullOrEmpty(Convert.ToString(data.ReOrderPoint)))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = InventoryReOrderPointDb.Find(r => r.Id == data.Id);
                    InventoryReOrderPointDb.Remove(record);
                    InventoryReOrderPointDb.Add(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryReOrderPoint.Remove(It.IsAny<InventoryReOrderPointDbModel>()))
                .Returns((InventoryReOrderPointDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (InventoryReOrderPointDb.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    InventoryReOrderPointDb.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.InventoryReOrderPoint.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = InventoryReOrderPointDb.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });
        }

        private void SetupPendingEft()
        {
            var PendingEftDb = new List<PendingEftDbModel>()
            {
                { new PendingEftDbModel { Id = 1, State = "CA", Cmf = "TEST0001", RecordType = "CMF", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "12345", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 2, State = "CA", Cmf = "TEST0001", RecordType = "CMF", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "67890", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 3, State = "CA", Cmf = "TEST0001", RecordType = "CMF", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "abcde", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 4, State = "CA", Cmf = "TEST0001", RecordType = "CMF", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "fghij", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 5, State = "CA", Cmf = "TEST0001", RecordType = "CMF", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "klmno", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 6, State = "CA", Cmf = "TEST0001", RecordType = "CMF", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "pqrst", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 7, State = "CA", Region = "01", RecordType = "REGION", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "12345", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 8, State = "CA", Region = "01", RecordType = "REGION", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "67890", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 9, State = "CA", Region = "01", RecordType = "REGION", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "abcde", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 10, State = "CA", Region = "01", RecordType = "REGION", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "fghij", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 11, State = "CA", Region = "01", RecordType = "REGION", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "klmno", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } },
                { new PendingEftDbModel { Id = 12, State = "CA", Region = "01", RecordType = "REGION", Status = "PENDING", AbaNumber = "123456789", AccountType = "CHK", AccountNumber = "pqrst", AccountName = "TEST ACCOUNT", created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow } }
            };

            // Create a dataset for the mock using the data above.
            var mock = PendingEftDb.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.PendingEft).Returns(mock.Object);

            // Mock other required functions for pending_eft.
            _mock.Setup(m => m.PendingEft.AddAsync(It.IsAny<PendingEftDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((PendingEftDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.RecordType) || string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (PendingEftDb.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = PendingEftDb.Max(z => z.Id);
                    data.Id = maxId + 1;
                    PendingEftDb.Add(data);
                    return new ValueTask<EntityEntry<PendingEftDbModel>>();
                });

            _mock.Setup(m => m.PendingEft.Add(It.IsAny<PendingEftDbModel>()))
                .Returns((PendingEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.RecordType) || string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (PendingEftDb.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = PendingEftDb.Max(z => z.Id);
                    data.Id = maxId + 1;
                    PendingEftDb.Add(data);
                    return null;
                });

            _mock.Setup(m => m.PendingEft.Update(It.IsAny<PendingEftDbModel>()))
                .Returns((PendingEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }
                    if (string.IsNullOrEmpty(data.State) || string.IsNullOrEmpty(data.RecordType) || string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = PendingEftDb.Find(r => r.Id == data.Id);
                    PendingEftDb.Remove(record);
                    PendingEftDb.Add(data);
                    return null;
                });

            _mock.Setup(m => m.PendingEft.Remove(It.IsAny<PendingEftDbModel>()))
                .Returns((PendingEftDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (PendingEftDb.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    PendingEftDb.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.PendingEft.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = PendingEftDb.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });
        }


        private void SetupReconcilationChecks()
        {
            // Create data for the reconcilation_checks table.
            var reconcilationChecksDbData = new List<ReconciliationCheckDbModel>()
            {
                new ReconciliationCheckDbModel() { Id= 1, State = "CA", Cmf = "123456", Control= "ABCDEF12", CheckAmount = "10", Status ="Issued", CheckNumber = 1001, StateData = JsonDocument.Parse("{\"plate\":\"FZV456\"}") },
                new ReconciliationCheckDbModel() { Id= 2, State = "CA", Cmf = "123457", Control= "ABCDEF13", CheckAmount = "10", Status ="Pending", StateData = JsonDocument.Parse("{\"Bundle\":\"AZv1234\"}") },
                new ReconciliationCheckDbModel() { Id= 3, State = "CA", Cmf = "123458", Control= "ABCDEF14", CheckAmount = "10", Status ="Void", StateData = JsonDocument.Parse("{\"CheckId\":111}") },
            };

            // Create a dataset for the mock using the data above.
            var mockMiscChargesDbSet = reconcilationChecksDbData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.ReconciliationChecks).Returns(mockMiscChargesDbSet.Object);

            // Mock other required functions for ReconcilationChecks.
            _mock.Setup(m => m.ReconciliationChecks.AddAsync(It.IsAny<ReconciliationCheckDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((ReconciliationCheckDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Control))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (reconcilationChecksDbData.Find(r => r.Cmf == data.Cmf && r.Control == data.Control) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = reconcilationChecksDbData.Count > 0 ? reconcilationChecksDbData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;

                    reconcilationChecksDbData.Add(data);
                    return new ValueTask<EntityEntry<ReconciliationCheckDbModel>>();
                });
            _mock.Setup(m => m.ReconciliationChecks.Add(It.IsAny<ReconciliationCheckDbModel>()))
                .Returns((ReconciliationCheckDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Control))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (reconcilationChecksDbData.Find(r => r.Cmf == data.Cmf && r.Control == data.Control) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = reconcilationChecksDbData.Count > 0 ? reconcilationChecksDbData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    reconcilationChecksDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ReconciliationChecks.Update(It.IsAny<ReconciliationCheckDbModel>()))
                .Returns((ReconciliationCheckDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (reconcilationChecksDbData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.Control))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = reconcilationChecksDbData.Find(r => r.Id == data.Id);
                    reconcilationChecksDbData.Remove(record);
                    reconcilationChecksDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ReconciliationChecks.Remove(It.IsAny<ReconciliationCheckDbModel>()))
                .Returns((ReconciliationCheckDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (reconcilationChecksDbData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    reconcilationChecksDbData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.ReconciliationChecks.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = reconcilationChecksDbData.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });

        }

        private void SetupUserAgreement()
        {
            // Create data for the user_agreements table.
            var userAgreementDbData = new List<UserAgreementDbModel>()
            {
                new UserAgreementDbModel() { Id= 1, State = "CA", Cmf = "123456", UserId = "CAUser" , Product = "TestProduct1" , ExpirationDate =DateTime.Now.AddDays(1) },
                new UserAgreementDbModel() { Id= 2, State = "CA", Cmf = "123457", UserId = "CAUser" , Product = "TestProduct2" , ExpirationDate = DateTime.Now.AddDays(2) },
                new UserAgreementDbModel() { Id= 3, State = "CA", Cmf = "123458", UserId = "CAUser" , Product = "TestProduct3" , ExpirationDate = DateTime.Now.AddDays(3) },
            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = userAgreementDbData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.UserAgreement).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.UserAgreement.AddAsync(It.IsAny<UserAgreementDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((UserAgreementDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.UserId) ||
                        string.IsNullOrEmpty(data.Product))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (userAgreementDbData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = userAgreementDbData.Count > 0 ? userAgreementDbData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;

                    userAgreementDbData.Add(data);
                    return new ValueTask<EntityEntry<UserAgreementDbModel>>();
                });
            _mock.Setup(m => m.UserAgreement.Add(It.IsAny<UserAgreementDbModel>()))
                .Returns((UserAgreementDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.UserId) ||
                        string.IsNullOrEmpty(data.Product))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (userAgreementDbData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = userAgreementDbData.Count > 0 ? userAgreementDbData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    userAgreementDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.UserAgreement.Update(It.IsAny<UserAgreementDbModel>()))
                .Returns((UserAgreementDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (userAgreementDbData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.UserId) ||
                        string.IsNullOrEmpty(data.Product))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = userAgreementDbData.Find(r => r.Id == data.Id);
                    userAgreementDbData.Remove(record);
                    userAgreementDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.UserAgreement.Remove(It.IsAny<UserAgreementDbModel>()))
                .Returns((UserAgreementDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (userAgreementDbData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    userAgreementDbData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.UserAgreement.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = userAgreementDbData.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });

        }

        private void SetupProcessLock()
        {
            // Test data for process_locks table.
            var processLockDbData = new List<ProcessLockDbModel>
            {
                { new ProcessLockDbModel { Cmf = "TEST0001", ProcessType = "TEST1", Status = "INPROCESS", Started = DateTime.Now } },
                { new ProcessLockDbModel { Cmf = "TEST0001", ProcessType = "TEST2", Status = "INPROCESS", Started = DateTime.Now.AddDays(-1) } },
                { new ProcessLockDbModel { Cmf = "TEST0001", ProcessType = "TEST3", Status = "COMPLETED", Started = DateTime.Now.AddMinutes(-2), Finished = DateTime.Now } },
            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = processLockDbData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.ProcessLock).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.ProcessLock.AddAsync(It.IsAny<ProcessLockDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((ProcessLockDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.ProcessType) ||
                        string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (processLockDbData.Find(c => c.ProcessType == data.ProcessType && c.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    processLockDbData.Add(data);
                    return new ValueTask<EntityEntry<ProcessLockDbModel>>();
                });

            _mock.Setup(m => m.ProcessLock.Add(It.IsAny<ProcessLockDbModel>()))
                .Returns((ProcessLockDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.ProcessType) ||
                        string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (processLockDbData.Find(c => c.ProcessType == data.ProcessType && c.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    processLockDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ProcessLock.Update(It.IsAny<ProcessLockDbModel>()))
                .Returns((ProcessLockDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (processLockDbData.Find(c => c.ProcessType == data.ProcessType && c.Cmf == data.Cmf) == null)
                    {
                        var innerException = new Exception($"Unable to locate record for processType: {data.ProcessType} and cmf: {data.Cmf}");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.ProcessType) ||
                        string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    processLockDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.ProcessLock.Remove(It.IsAny<ProcessLockDbModel>()))
                .Returns((ProcessLockDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (processLockDbData.Find(c => c.ProcessType == data.ProcessType && c.Cmf == data.Cmf) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    processLockDbData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.ProcessLock.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = processLockDbData.Find(r => r.ProcessType == (string)keyValues[0] && r.Cmf == (string)keyValues[1]);

                    return result;
                });

        }

        private void SetupFifoQueue()
        {
            // Test data for process_locks table.
            var fifoQueueData = new List<FifoQueueDbModel>
            {
                new FifoQueueDbModel { Id = 1, State = "CA", Queue = "INQUIRY", Status = "QUEUED", Priority = FifoQueueConstants.LowPriority, Cmf = "TEST0001", Request = "REQUEST", Submitted = DateTime.Now },
                new FifoQueueDbModel { Id = 2, State = "CA", Queue = "INQUIRY", Status = "QUEUED", Priority = FifoQueueConstants.DefaultPriority, Cmf = "TEST0001", Request = "REQUEST", Submitted = DateTime.Now },
                new FifoQueueDbModel { Id = 3, State = "CA", Queue = "INQUIRY", Status = "QUEUED", Priority = FifoQueueConstants.HighPriority, Cmf = "TEST0001", Request = "REQUEST", Submitted = DateTime.Now },
            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = fifoQueueData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.FifoQueue).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.FifoQueue.AddAsync(It.IsAny<FifoQueueDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((FifoQueueDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Queue) ||
                        string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (fifoQueueData.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = fifoQueueData.Count > 0 ? fifoQueueData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    fifoQueueData.Add(data);
                    return new ValueTask<EntityEntry<FifoQueueDbModel>>();
                });

            _mock.Setup(m => m.FifoQueue.Add(It.IsAny<FifoQueueDbModel>()))
                .Returns((FifoQueueDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Queue) ||
                        string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (fifoQueueData.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = fifoQueueData.Count > 0 ? fifoQueueData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    fifoQueueData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FifoQueue.Update(It.IsAny<FifoQueueDbModel>()))
                .Returns((FifoQueueDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (fifoQueueData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception($"Unable to locate record for Id: {data.Id}");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Queue) ||
                        string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = fifoQueueData.Find(r => r.Id == data.Id);
                    fifoQueueData.Remove(record);
                    fifoQueueData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.FifoQueue.Remove(It.IsAny<FifoQueueDbModel>()))
                .Returns((FifoQueueDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (fifoQueueData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    fifoQueueData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.FifoQueue.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = fifoQueueData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupLookup()
        {
            // Test data for process_locks table.
            var LookupData = new List<LookupDbModel>
            {
                new LookupDbModel { Id = 1, State = "PA", Category = "TEST", Code = "1", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 2, State = "PA", Category = "TEST", Code = "2", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 3, State = "PA", Category = "TEST", Code = "3", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 4, State = "PA", Category = "TEST2", Code = "4", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 5, State = "PA", Category = "TEST2", Code = "5", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 6, State = "PA", Category = "TEST2", Code = "1", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 7, State = "PA", Category = "TEST3", Code = "2", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 8, State = "PA", Category = "TEST3", Code = "3", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 9, State = "PA", Category = "TEST3", Code = "4", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
                new LookupDbModel { Id = 10, State = "PA", Category = "TEST3", Code = "5", Value = "{\"Property\":\"Test1\"}".AsJsonDocument(), created_by = "TEST", created_on = DateTime.UtcNow, updated_by = "TEST", updated_on = DateTime.UtcNow },
            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = LookupData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.Lookup).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.Lookup.AddAsync(It.IsAny<LookupDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((LookupDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Category) ||
                        string.IsNullOrEmpty(data.Code) ||
                        data.Value == null)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (LookupData.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = LookupData.Count > 0 ? LookupData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    LookupData.Add(data);
                    return new ValueTask<EntityEntry<LookupDbModel>>();
                });

            _mock.Setup(m => m.Lookup.Add(It.IsAny<LookupDbModel>()))
                .Returns((LookupDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Category) ||
                        string.IsNullOrEmpty(data.Code) ||
                        data.Value == null)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (LookupData.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = LookupData.Count > 0 ? LookupData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    LookupData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Lookup.Update(It.IsAny<LookupDbModel>()))
                .Returns((LookupDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (LookupData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception($"Unable to locate record for Id: {data.Id}");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Category) ||
                        string.IsNullOrEmpty(data.Code) ||
                        data.Value == null)
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = LookupData.Find(r => r.Id == data.Id);
                    LookupData.Remove(record);
                    LookupData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.Lookup.Remove(It.IsAny<LookupDbModel>()))
                .Returns((LookupDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (LookupData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    LookupData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.Lookup.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = LookupData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupAccountingCreditAndDetail()
        {
            var accountingCreditRecords = new List<AccountingCreditDbModel>
            {
                new AccountingCreditDbModel { Id = 1, WorkDate = DateTime.Now.Date.AddDays(-2), State = "CA", Amount = 50.00m, Cmf = "12345", BatchId = 123, Memo = "Memo 1",
                                        Details = new List<AccountingCreditDetailDbModel>
                                        {
                                            new AccountingCreditDetailDbModel { Id = 1, AccountingCreditId = 1, State = "CA" },
                                            new AccountingCreditDetailDbModel { Id = 2, AccountingCreditId = 1,  State = "CA" }
                                        }
                                       },
                new AccountingCreditDbModel { Id = 2, WorkDate = DateTime.Now.Date.AddDays(-1), State = "CA", Amount = 80.00m, Cmf = "12346", BatchId = 124, Memo = "Memo 2",
                                        Details = new List<AccountingCreditDetailDbModel>
                                        {
                                            new AccountingCreditDetailDbModel { Id = 3, AccountingCreditId = 2,  State = "CA" },
                                            new AccountingCreditDetailDbModel { Id = 4, AccountingCreditId = 2, State = "CA" }
                                        }
                                       },
                new AccountingCreditDbModel { Id = 3, WorkDate = DateTime.Now.Date, State = "CA", Amount = 70.00m, Cmf = "12347",  BatchId = 125, Memo = "Memo 3",
                                        Details = new List<AccountingCreditDetailDbModel>
                                        {
                                            new AccountingCreditDetailDbModel { Id = 5, AccountingCreditId = 3, State = "CA" },
                                            new AccountingCreditDetailDbModel { Id = 6, AccountingCreditId = 3, State = "CA"  }
                                        }
                                       },

            };
            var accountingCreditDetailRecords = accountingCreditRecords.SelectMany(x => x.Details).ToList();

            var mockAccountingCreditDbSet = accountingCreditRecords.AsQueryable().BuildMockDbSet();
            var mockAccountingCreditDetailDbSet = accountingCreditDetailRecords.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.AccountingCredit).Returns(mockAccountingCreditDbSet.Object);
            _mock.Setup(m => m.AccountingCreditDetails).Returns(mockAccountingCreditDetailDbSet.Object);

            _mock.Setup(m => m.AccountingCredit.AddAsync(It.IsAny<AccountingCreditDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((AccountingCreditDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (accountingCreditRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingCreditRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingCreditRecords.Add(data);
                    return new ValueTask<EntityEntry<AccountingCreditDbModel>>();
                });

            _mock.Setup(m => m.AccountingCredit.Add(It.IsAny<AccountingCreditDbModel>()))
                .Returns((AccountingCreditDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (accountingCreditRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingCreditRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingCreditRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCredit.Update(It.IsAny<AccountingCreditDbModel>()))
                .Returns((AccountingCreditDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = accountingCreditRecords.Find(r => r.Id == data.Id);
                    accountingCreditRecords.Remove(record);
                    accountingCreditRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCredit.Remove(It.IsAny<AccountingCreditDbModel>()))
                .Returns((AccountingCreditDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    accountingCreditRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCredit.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = accountingCreditRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });

            _mock.Setup(m => m.AccountingCreditDetails.AddAsync(It.IsAny<AccountingCreditDetailDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((AccountingCreditDetailDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditDetailRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingCreditDetailRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingCreditDetailRecords.Add(data);
                    return new ValueTask<EntityEntry<AccountingCreditDetailDbModel>>();
                });

            _mock.Setup(m => m.AccountingCreditDetails.Add(It.IsAny<AccountingCreditDetailDbModel>()))
                .Returns((AccountingCreditDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditDetailRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingCreditDetailRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingCreditDetailRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCreditDetails.Update(It.IsAny<AccountingCreditDetailDbModel>()))
                .Returns((AccountingCreditDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditDetailRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = accountingCreditDetailRecords.Find(r => r.Id == data.Id);
                    accountingCreditDetailRecords.Remove(record);
                    accountingCreditDetailRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCreditDetails.Remove(It.IsAny<AccountingCreditDetailDbModel>()))
                .Returns((AccountingCreditDetailDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditDetailRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    accountingCreditDetailRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCreditDetails.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = accountingCreditDetailRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupAccountingCreditReturn()
        {
            var accountingCreditReturnRecords = new List<AccountingCreditReturnDbModel>
            {
                new AccountingCreditReturnDbModel{ Id = 1, State = "CA", AccountingCreditId = 1, ReturnDate = DateTime.Now.Date.AddDays(-1), ReturnAmount = 50.00m, BankCharge = 5.00m, Memo = "TEST 1",
                    AccountingCredit = new AccountingCreditDbModel{ Id = 1, WorkDate = DateTime.Now.Date.AddDays(-2), State = "CA", Amount = 50.00m, Cmf = "12345", BatchId = 123, Memo = "Memo 1" } },
                new AccountingCreditReturnDbModel{ Id = 2, State = "CA", AccountingCreditId = 3, ReturnDate = DateTime.Now.Date.AddDays(-1), ReturnAmount = 70.00m, BankCharge = 10.00m, Memo = "TEST 2",
                    AccountingCredit = new AccountingCreditDbModel{ Id = 3, WorkDate = DateTime.Now.Date, State = "CA", Amount = 70.00m, Cmf = "12347",  BatchId = 125, Memo = "Memo 3" } },
            };
            var mockAccountingCreditReturnDbSet = accountingCreditReturnRecords.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.AccountingCreditReturns).Returns(mockAccountingCreditReturnDbSet.Object);

            _mock.Setup(m => m.AccountingCreditReturns.AddAsync(It.IsAny<AccountingCreditReturnDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((AccountingCreditReturnDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditReturnRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingCreditReturnRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingCreditReturnRecords.Add(data);
                    return new ValueTask<EntityEntry<AccountingCreditReturnDbModel>>();
                });

            _mock.Setup(m => m.AccountingCreditReturns.Add(It.IsAny<AccountingCreditReturnDbModel>()))
                .Returns((AccountingCreditReturnDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditReturnRecords.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = accountingCreditReturnRecords.Max(z => z.Id);
                    data.Id = maxId + 1;
                    accountingCreditReturnRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCreditReturns.Update(It.IsAny<AccountingCreditReturnDbModel>()))
                .Returns((AccountingCreditReturnDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditReturnRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = accountingCreditReturnRecords.Find(r => r.Id == data.Id);
                    accountingCreditReturnRecords.Remove(record);
                    accountingCreditReturnRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCreditReturns.Remove(It.IsAny<AccountingCreditReturnDbModel>()))
                .Returns((AccountingCreditReturnDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (accountingCreditReturnRecords.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    accountingCreditReturnRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.AccountingCreditReturns.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = accountingCreditReturnRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupHostMocking()
        {
            var hostMockingRecords = new List<HostMockingDbModel>
            {

                new HostMockingDbModel { Id = 1, State = "PA", TransactionType = TransactionType.NewIssue, TransactionOperation = TransactionOperation.Complete, Description = "TEST", Request = "TEST Request", Response = "Test Response"},
                new HostMockingDbModel { Id = 2, State = "PA", TransactionType = TransactionType.NewIssueOutOfStock, TransactionOperation = TransactionOperation.Complete, Description = "TEST 1", Request = "TEST Request 1", Response = "Test Response 1"},
                new HostMockingDbModel { Id = 3, State = "PA", TransactionType = TransactionType.NewVessel, TransactionOperation = TransactionOperation.Complete, Description = "TEST 2", Request = "TEST Request 2", Response = "Test Response 2"}
            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = hostMockingRecords.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.HostMocking).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.HostMocking.AddAsync(It.IsAny<HostMockingDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((HostMockingDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.TransactionType) ||
                        string.IsNullOrEmpty(data.Request))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (hostMockingRecords.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = hostMockingRecords.Count > 0 ? hostMockingRecords.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    hostMockingRecords.Add(data);
                    return new ValueTask<EntityEntry<HostMockingDbModel>>();
                });

            _mock.Setup(m => m.HostMocking.Add(It.IsAny<HostMockingDbModel>()))
                .Returns((HostMockingDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.TransactionType) ||
                        string.IsNullOrEmpty(data.TransactionOperation) ||
                        string.IsNullOrEmpty(data.Request))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (hostMockingRecords.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = hostMockingRecords.Count > 0 ? hostMockingRecords.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    hostMockingRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.HostMocking.Update(It.IsAny<HostMockingDbModel>()))
                .Returns((HostMockingDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (hostMockingRecords.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception($"Unable to locate record for Id: {data.Id}");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.TransactionType) ||
                        string.IsNullOrEmpty(data.TransactionOperation))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = hostMockingRecords.Find(r => r.Id == data.Id);
                    hostMockingRecords.Remove(record);
                    hostMockingRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.HostMocking.Remove(It.IsAny<HostMockingDbModel>()))
                .Returns((HostMockingDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (hostMockingRecords.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    hostMockingRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.HostMocking.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = hostMockingRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupDailyFeeSummary()
        {
            var dailyFeeSummaryRecords = new List<DailyFeeSummaryDbModel>
            {

                new DailyFeeSummaryDbModel { Id = 1, State = "PA", created_by = "KVM", TransactionCount = 11, FinalSubTotal = Convert.ToDecimal("11.00"), WorkDate = DateTime.Parse("2022-03-11"), TransactionDetailId = 11 },
                new DailyFeeSummaryDbModel { Id = 2, State = "PA", created_by = "KVM", TransactionCount = 12, FinalSubTotal = Convert.ToDecimal("12.00"), WorkDate = DateTime.Parse("2022-03-12"), TransactionDetailId = 12 },
                new DailyFeeSummaryDbModel { Id = 3, State = "PA", created_by = "KVM", TransactionCount = 13, FinalSubTotal = Convert.ToDecimal("13.00"), WorkDate = DateTime.Parse("2022-03-13"), TransactionDetailId = 13 },
            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = dailyFeeSummaryRecords.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.DailyFeeSummary).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.DailyFeeSummary.AddAsync(It.IsAny<DailyFeeSummaryDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((DailyFeeSummaryDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.TransactionDetailId.ToString()) ||
                        string.IsNullOrEmpty(data.WorkDate.ToString()))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (dailyFeeSummaryRecords.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = dailyFeeSummaryRecords.Count > 0 ? dailyFeeSummaryRecords.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    dailyFeeSummaryRecords.Add(data);
                    return new ValueTask<EntityEntry<DailyFeeSummaryDbModel>>();
                });

            _mock.Setup(m => m.DailyFeeSummary.Add(It.IsAny<DailyFeeSummaryDbModel>()))
                .Returns((DailyFeeSummaryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.TransactionDetailId.ToString()) ||
                        string.IsNullOrEmpty(data.WorkDate.ToString()))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (dailyFeeSummaryRecords.Find(c => c.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = dailyFeeSummaryRecords.Count > 0 ? dailyFeeSummaryRecords.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    dailyFeeSummaryRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DailyFeeSummary.Update(It.IsAny<DailyFeeSummaryDbModel>()))
                .Returns((DailyFeeSummaryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (dailyFeeSummaryRecords.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception($"Unable to locate record for Id: {data.Id}");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.TransactionDetailId.ToString()) ||
                        string.IsNullOrEmpty(data.WorkDate.ToString()))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = dailyFeeSummaryRecords.Find(r => r.Id == data.Id);
                    dailyFeeSummaryRecords.Remove(record);
                    dailyFeeSummaryRecords.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DailyFeeSummary.Remove(It.IsAny<DailyFeeSummaryDbModel>()))
                .Returns((DailyFeeSummaryDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (dailyFeeSummaryRecords.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    dailyFeeSummaryRecords.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.DailyFeeSummary.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = dailyFeeSummaryRecords.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupSystemStatus()
        {
            // Create data for the System Status table.
            var systemStatusData = new List<SystemStatusDbModel>
            {
                new SystemStatusDbModel { Id = 1, State = "CA", System = "DMV", Subsystem = "DL", Status = "UP", StatusTimestamp = DateTime.Now},
                new SystemStatusDbModel { Id = 2, State = "CAA", System = "DMV", Subsystem = "DL", Status = "Down", StatusTimestamp = DateTime.Now}
            };


            // Create a dateset for the mock using the data list above
            var mockSystemStatusDbSet = systemStatusData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.SystemStatus).Returns(mockSystemStatusDbSet.Object);

            // Mock other required functions for SystemStatus 
            _mock.Setup(m => m.SystemStatus.AddAsync(It.IsAny<SystemStatusDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((SystemStatusDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.Status) && string.IsNullOrEmpty(data.Subsystem))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (systemStatusData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = systemStatusData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    systemStatusData.Add(data);
                    return new ValueTask<EntityEntry<SystemStatusDbModel>>();
                });

            _mock.Setup(m => m.SystemStatus.Add(It.IsAny<SystemStatusDbModel>()))
                .Returns((SystemStatusDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }


                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.Status) && string.IsNullOrEmpty(data.Subsystem))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (systemStatusData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = systemStatusData.Max(z => z.Id);
                    data.Id = maxId + 1;
                    systemStatusData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.SystemStatus.Update(It.IsAny<SystemStatusDbModel>()))
                .Returns((SystemStatusDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (systemStatusData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.Status))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.Status) && string.IsNullOrEmpty(data.Subsystem))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = systemStatusData.Find(r => r.Id == data.Id);
                    systemStatusData.Remove(record);
                    systemStatusData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.SystemStatus.Remove(It.IsAny<SystemStatusDbModel>()))
                .Returns((SystemStatusDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (systemStatusData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    systemStatusData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.SystemStatus.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = systemStatusData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupSystemPerformance()
        {
            // Create data for the System Perfomance table.
            var systemPerfomanceData = new List<SystemPerformanceDbModel>
            {
                new SystemPerformanceDbModel { Id = 1, State = "CA", System = "DMV", Subsystem = "Test", BeginDateTime = DateTime.Now.AddMinutes(2),EndDateTime = DateTime.Now.AddMinutes(6),RequestId= "2", Duration=4},
                new SystemPerformanceDbModel { Id = 2, State = "CA", System = "DMV", Subsystem = "Test", BeginDateTime = DateTime.Now.AddMinutes(2),EndDateTime = DateTime.Now.AddMinutes(6),RequestId= "1", Duration=4},
            };


            // Create a dateset for the mock using the data list above
            var mockSystemPerformanceDbSet = systemPerfomanceData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.SystemPerformance).Returns(mockSystemPerformanceDbSet.Object);

            // Mock other required functions for SystemPerformance 
            _mock.Setup(m => m.SystemPerformance.AddAsync(It.IsAny<SystemPerformanceDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((SystemPerformanceDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (systemPerfomanceData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.RequestId))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.System))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.System) && string.IsNullOrEmpty(data.Subsystem))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }


                    var maxId = systemPerfomanceData.Count > 0 ? systemPerfomanceData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    systemPerfomanceData.Add(data);
                    return new ValueTask<EntityEntry<SystemPerformanceDbModel>>();
                });

            _mock.Setup(m => m.SystemPerformance.Add(It.IsAny<SystemPerformanceDbModel>()))
                .Returns((SystemPerformanceDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (systemPerfomanceData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.RequestId))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.System))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.System) && string.IsNullOrEmpty(data.Subsystem))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }
                    var maxId = systemPerfomanceData.Count > 0 ? systemPerfomanceData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    systemPerfomanceData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.SystemPerformance.Update(It.IsAny<SystemPerformanceDbModel>()))
                .Returns((SystemPerformanceDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (systemPerfomanceData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.RequestId))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.System))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) && string.IsNullOrEmpty(data.System) && string.IsNullOrEmpty(data.Subsystem))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = systemPerfomanceData.Find(r => r.Id == data.Id);
                    systemPerfomanceData.Remove(record);
                    systemPerfomanceData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.SystemPerformance.Remove(It.IsAny<SystemPerformanceDbModel>()))
                .Returns((SystemPerformanceDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (systemPerfomanceData.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    systemPerfomanceData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.SystemPerformance.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = systemPerfomanceData.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupDLDVLog()
        {
            var record = new DLDVLogDbModel();
            record.Id = 1;
            record.State = "CA";
            record.Cmf = "TEST0001";
            record.ComputerId = "12345678";
            record.ClientIp = "127.0.0.1";
            record.Control = "UnitTestControl";
            record.DriverLicenseNumber = "TestDLNumber";
            record.ProductVersion = "CCAC0100";
            record.ClientVersion = "1.0.0.0";
            record.StartDtm = DateTime.UtcNow;
            record.EndDtm = DateTime.UtcNow;
            record.Request = "This is a request record.";
            record.Response = "This is a response record.";

            // Create data for the TransactionLog table.
            var DLDVLogDbEntries = new List<DLDVLogDbModel>() { record };

            // Create a dataset for the mock using the data above.
            var mockDLDVLogDbsSet = DLDVLogDbEntries.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.DLDVLog).Returns(mockDLDVLogDbsSet.Object);

            // Mock other required functions for TransactionLog.
            _mock.Setup(m => m.DLDVLog.AddAsync(It.IsAny<DLDVLogDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((DLDVLogDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))

                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (DLDVLogDbEntries.Find(r => r.Cmf == data.Cmf) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = DLDVLogDbEntries.Max(z => z.Id);
                    data.Id = maxId + 1;
                    DLDVLogDbEntries.Add(data);
                    return new ValueTask<EntityEntry<DLDVLogDbModel>>();
                });

            _mock.Setup(m => m.DLDVLog.Add(It.IsAny<DLDVLogDbModel>()))
                .Returns((DLDVLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (DLDVLogDbEntries.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = DLDVLogDbEntries.Max(z => z.Id);
                    data.Id = maxId + 1;
                    DLDVLogDbEntries.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DLDVLog.Update(It.IsAny<DLDVLogDbModel>()))
                .Returns((DLDVLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (DLDVLogDbEntries.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Cmf);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.Cmf) ||
                        string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = DLDVLogDbEntries.Find(r => r.Cmf == data.Cmf);
                    DLDVLogDbEntries.Remove(record);
                    DLDVLogDbEntries.Add(data);
                    return null;
                });

            _mock.Setup(m => m.DLDVLog.Remove(It.IsAny<DLDVLogDbModel>()))
                .Returns((DLDVLogDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (DLDVLogDbEntries.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    DLDVLogDbEntries.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.DLDVLog.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = DLDVLogDbEntries.Find(r => r.Cmf == keyValues[0].ToString());

                    return result;
                });
        }

        private void SetupBillingCategories()
        {
            // Create data for the Billing Categories table.
            var billingCategories = new List<BillingCategoriesDbModel>
            {
                new BillingCategoriesDbModel { Id = 1, State = "CA", TransactionType = "New Vehicle Report of Sale", TransactionOperation = "Complete", BillingCategory = "111111"},
                new BillingCategoriesDbModel { Id = 2, State = "CA", TransactionType = "Post Fees / Original", TransactionOperation = "RDF", BillingCategory = "111112"},
                new BillingCategoriesDbModel { Id = 3, State = "CA", TransactionType = "Registration Transfers", TransactionOperation = "Clear", BillingCategory = "111113"},
                new BillingCategoriesDbModel { Id = 4, State = "CA", TransactionType = "VehicleInquiry", TransactionOperation = "Online", BillingCategory = "222221"},
                new BillingCategoriesDbModel { Id = 5, State = "CA", TransactionType = "PersonInquiry", TransactionOperation = "Online", BillingCategory = "222222"},
                new BillingCategoriesDbModel { Id = 6, State = "CA", TransactionType = "VehicleInquiry", TransactionOperation = "Overnight", BillingCategory = "222223"},
                new BillingCategoriesDbModel { Id = 7, State = "CA", TransactionType = "OLInquiry", TransactionOperation = "Online", BillingCategory = "333331"},
                new BillingCategoriesDbModel { Id = 8, State = "CA", TransactionType = "NMVITS", TransactionOperation = "Online", BillingCategory = "333332"},
                new BillingCategoriesDbModel { Id = 9, State = "CA", TransactionType = "PersonInquiry", TransactionOperation = "Overnight", BillingCategory = "333333"},
            };

            // Create a dateset for the mock using the data list above
            var mockAccountingDbSet = billingCategories.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.BillingCategories).Returns(mockAccountingDbSet.Object);

            // Mock other required functions for Billing Categories
            _mock.Setup(m => m.BillingCategories.AddAsync(It.IsAny<BillingCategoriesDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((BillingCategoriesDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (billingCategories.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = billingCategories.Max(z => z.Id);
                    data.Id = maxId + 1;
                    billingCategories.Add(data);
                    return new ValueTask<EntityEntry<BillingCategoriesDbModel>>();
                });

            _mock.Setup(m => m.BillingCategories.Add(It.IsAny<BillingCategoriesDbModel>()))
                .Returns((BillingCategoriesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (billingCategories.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = billingCategories.Max(z => z.Id);
                    data.Id = maxId + 1;
                    billingCategories.Add(data);
                    return null;
                });

            _mock.Setup(m => m.BillingCategories.Update(It.IsAny<BillingCategoriesDbModel>()))
                .Returns((BillingCategoriesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (billingCategories.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = billingCategories.Find(r => r.Id == data.Id);
                    billingCategories.Remove(record);
                    billingCategories.Add(data);
                    return null;
                });

            _mock.Setup(m => m.BillingCategories.Remove(It.IsAny<BillingCategoriesDbModel>()))
                .Returns((BillingCategoriesDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (billingCategories.Find(r => r.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    billingCategories.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.BillingCategories.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = billingCategories.Find(r => r.Id == (long)keyValues[0]);

                    return result;
                });
        }

        private void SetupTransactionInProcess()
        {
            // Create data for the user_agreements table.
            var transactionInProcessDbData = new List<TransactionInProcessDbModel>()
            {
                new TransactionInProcessDbModel() { Id= 1, State = "CA", Cmf = "123456", TransactionDetailId = 1 , Control = "Test01",Vin = "KNDP63AC2M7855111",Plate = "2BPA369"},
                 new TransactionInProcessDbModel() { Id= 2, State = "CA", Cmf = "123456", TransactionDetailId = 1 , Control = "Test01",Vin = "KNDP63AC2M7855111",Plate = "2BPA369"},
                  new TransactionInProcessDbModel() { Id= 3, State = "CA", Cmf = "123456", TransactionDetailId = 2 , Control = "Test01",Vin = "KNDP63AC2M7855112",Plate = "2BPA367"},

            };

            // Create a dataset for the mock using the data above.
            var mockDbSet = transactionInProcessDbData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.TransactionInProcess).Returns(mockDbSet.Object);

            // Mock other required functions for UserAgreement.
            _mock.Setup(m => m.TransactionInProcess.AddAsync(It.IsAny<TransactionInProcessDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((TransactionInProcessDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                          (data.TransactionDetailId == 0) ||
                         string.IsNullOrEmpty(data.Control) ||
                        string.IsNullOrEmpty(data.Vin) ||
                         string.IsNullOrEmpty(data.Plate))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionInProcessDbData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionInProcessDbData.Count > 0 ? transactionInProcessDbData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;

                    transactionInProcessDbData.Add(data);
                    return new ValueTask<EntityEntry<TransactionInProcessDbModel>>();
                });
            _mock.Setup(m => m.TransactionInProcess.Add(It.IsAny<TransactionInProcessDbModel>()))
                .Returns((TransactionInProcessDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                       string.IsNullOrEmpty(data.Cmf) ||
                       (data.TransactionDetailId == 0) ||
                         string.IsNullOrEmpty(data.Control) ||
                       string.IsNullOrEmpty(data.Vin) ||
                        string.IsNullOrEmpty(data.Plate))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (transactionInProcessDbData.Find(r => r.Id == data.Id) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var maxId = transactionInProcessDbData.Count > 0 ? transactionInProcessDbData.Max(z => z.Id) : 0;
                    data.Id = maxId + 1;
                    transactionInProcessDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionInProcess.Update(It.IsAny<TransactionInProcessDbModel>()))
                .Returns((TransactionInProcessDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("key");
                    }

                    if (transactionInProcessDbData.Find(c => c.Id == data.Id) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.Id);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State) ||
                        string.IsNullOrEmpty(data.Cmf) ||
                          (data.TransactionDetailId == 0) ||
                         string.IsNullOrEmpty(data.Control) ||
                        string.IsNullOrEmpty(data.Vin) ||
                        string.IsNullOrEmpty(data.Plate))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = transactionInProcessDbData.Find(r => r.Id == data.Id);
                    transactionInProcessDbData.Remove(record);
                    transactionInProcessDbData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionInProcess.Remove(It.IsAny<TransactionInProcessDbModel>()))
                .Returns((TransactionInProcessDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new ArgumentNullException("entity");
                    }

                    if (transactionInProcessDbData.Find(c => c.Id == data.Id) == null)
                    {
                        throw new DbUpdateConcurrencyException("Database operation expected to affect 1 row(s) but actually affected 0 row(s). Data may have been modified or deleted since entities were loaded. See http://go.microsoft.com/fwlink/?LinkId=527962 for information on understanding and handling optimistic concurrency exceptions.");
                    }

                    transactionInProcessDbData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.TransactionInProcess.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    if (!keyValues.Any())
                    {
                        throw new ArgumentNullException("key");
                    }

                    var result = transactionInProcessDbData.Find(r => r.Id == Convert.ToInt64(keyValues[0]));

                    return result;
                });

        }

        private void SetupState()
        {
            // Create data for the State table.
            var stateData = new List<StateDbModel>
            {
                new StateDbModel
                {
                    State = "CA", Name = "Name1" , BillingModel = "BillingModel1", AgencyInitials = "AgencyInitials1", AgencyName = "AgencyName1", AgencyTimezone = "AgencyTimezone1", BillingType = "BillingType1", Eft = true, Ims = true, ImsType = "ImsType1", Status = "Status1", UserAgreementRequired = true
                },
                new StateDbModel
                {
                    State = "PA", Name = "Name2" , BillingModel = "BillingModel2", AgencyInitials = "AgencyInitials2", AgencyName = "AgencyName2", AgencyTimezone = "AgencyTimezone2", BillingType = "BillingType2", Eft = true, Ims = true, ImsType = "ImsType2", Status = "Status2", UserAgreementRequired = true
                }
            };

            // Create a dateset for the mock using the data list above
            var mockStateDbSet = stateData.AsQueryable().BuildMockDbSet();

            _mock.Setup(m => m.State).Returns(mockStateDbSet.Object);

            // Mock other required functions for State
            _mock.Setup(m => m.State.AddAsync(It.IsAny<StateDbModel>(), It.IsAny<CancellationToken>()))
                .Returns((StateDbModel data, CancellationToken token) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (stateData.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }
                                       
                    stateData.Add(data);
                    return new ValueTask<EntityEntry<StateDbModel>>();
                });

            _mock.Setup(m => m.State.Add(It.IsAny<StateDbModel>()))
                .Returns((StateDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (stateData.Find(r => r.State == data.State) != null)
                    {
                        var innerException = new Exception("duplicate key value violates unique constraint");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    stateData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.State.Update(It.IsAny<StateDbModel>()))
                .Returns((StateDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (stateData.Find(r => r.State == data.State) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.State);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    if (string.IsNullOrEmpty(data.State))
                    {
                        var innerException = new Exception("Missing required field.");
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    var record = stateData.Find(r => r.State == data.State);
                    stateData.Remove(record);
                    stateData.Add(data);
                    return null;
                });

            _mock.Setup(m => m.State.Remove(It.IsAny<StateDbModel>()))
                .Returns((StateDbModel data) =>
                {
                    if (data == null)
                    {
                        throw new NullReferenceException();
                    }

                    if (stateData.Find(r => r.State == data.State) == null)
                    {
                        var innerException = new Exception("Unable to locate record for " + data.State);
                        throw new DbUpdateException("An error occurred while updating the entries. See the inner exception for details.", innerException);
                    }

                    stateData.Remove(data);
                    return null;
                });

            _mock.Setup(m => m.State.Find(It.IsAny<object[]>()))
                .Returns((object[] keyValues) =>
                {
                    var result = stateData.Find(r => r.State == (string)keyValues[0]);

                    return result;
                });
        }
    }
}
