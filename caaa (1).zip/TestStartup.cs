﻿using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.ioc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace TestUtilities
{
    /// <summary>
    /// This class is derived from test objects that require the use of dependency injection.  This
    /// greatly simplifies the creation of objects that have other dependencies.  The TestServiceProvider
    /// object should be used with the GetService method to obtain a dependent object.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class TestStartup
    {
        private IServiceCollection _Services { get; set; }
        public ServiceProvider TestServiceProvider { get; set; }

        public TestStartup()
        {
            _Services = new ServiceCollection();
            IoCRegister.RegisterIocStartup(_Services, new[] { "cdk.evr.converge.cbe" });

            IConfigurationRoot Configuration = new ConfigurationBuilder()
               .AddJsonFile("appsettings.testing.json")
               .Build();

            var sqlConnectString = Configuration["ConnectionString"];
            _Services.AddDbContext<PostgreSqlContext>(options => options.UseNpgsql(sqlConnectString));
            _Services.AddMemoryCache();

            TestServiceProvider = _Services.BuildServiceProvider();
        }
    }
}
