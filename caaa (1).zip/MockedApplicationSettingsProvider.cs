﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using System.Collections.Generic;
using cdk.evr.converge.cbe.common.dal.Models;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models.Inventory;
using cdk.evr.converge.cbe.common.models.Extensions;
using Moq;
using cdk.evr.converge.cbe.common.models;

namespace TestUtilities
{
    [ExcludeFromCodeCoverage]
    public class MockedApplicationSettingsProvider
    {
        private class TestSetting
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }

        private class TestPathSetting
        {
            public string Path { get; set; }
        }

        private readonly Mock<IApplicationSettingsProvider> _mock;

        public MockedApplicationSettingsProvider()
        {
            _mock = new Mock<IApplicationSettingsProvider>();
            _mock.Setup(s => s.CreateAsync(It.IsAny<ApplicationSettingsDbModel>())).Returns((ApplicationSettingsDbModel arg) =>
            {
                return Task.FromResult<int>(1);
            });

            _mock.Setup(s => s.UpdateAsync(It.IsAny<ApplicationSettingsDbModel>())).Returns((ApplicationSettingsDbModel arg) =>
            {
                return Task.FromResult<int>(1);
            });

            _mock.Setup(s => s.ReadByStateSystemSubsystemAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns((string arg1, string arg2, string arg3) =>
            {
                if (arg1 == "NONE")
                {
                    return Task.FromResult<ApplicationSettingsDbModel>(null);
                }

                var result = new ApplicationSettingsDbModel
                {
                    State = arg1,
                    System = arg2,
                    Subsystem = arg3
                };

                if (arg2 == "Logging")
                {
                    var pathSetting = new TestPathSetting { Path = "./test.log" };
                    result.Settings = pathSetting.AsJsonDocument();
                }
                else if (arg2 == "Inventory" && arg3 == "InventoryStateUrls")
                {
                    var invUrls = new List<InventoryUrlSetting> {
                        new InventoryUrlSetting {
                            State = "CA",
                            Command = "UpdateInventory",
                            URL = "UpdateInventoryWithDMV"
                        },
                        new InventoryUrlSetting
                        {
                            State = "CA",
                            Command = "TransferInventory",
                            URL = "TransferInventoryWithDMV"
                        }
                    };

                    result.Settings = invUrls.AsJsonDocument();
                }
                else if (arg1 == "COMMON" && arg2 == "CACHE" && arg3 == "MEMORY")
                {
                    var commSetting = new CacheTimeoutSetting { CacheTimeOut = 12 };
                    result.Settings = commSetting.AsJsonDocument();
                }
                else
                {
                    var commSetting = new TestSetting { Name = "Test", Value = "This is a test value." };
                    result.Settings = commSetting.AsJsonDocument();
                }


                return Task.FromResult<ApplicationSettingsDbModel>(result);
            });
        }

        public IApplicationSettingsProvider GetMocked()
        {
            return _mock.Object;
        }
    }
}
