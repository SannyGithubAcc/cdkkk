﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TestUtilities;

namespace cdk.evr.converge.cbe.common.tests.Utils
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class EmailServiceTest : TestStartup
    {
        [TestMethod]
        public async Task TestSend()
        {
            //Arrange
            var settingsManagerMock = new Mock<IApplicationSettingsManager>();

            var logSettings = new ApiItemModel<ApplicationSettingsModel>
            {
                Identification = new IdentificationModel { Cmf = "CMF123" },
                Item = new ApplicationSettingsModel
                {
                    State = "COMMON",
                    System = "Logging",
                    Subsystem = "Exceptions",
                    Settings = JsonDocument.Parse("{\"Path\": \"d:/logs/cdk.evr.converge.cbe.common/Exception.log\"}")
                }
            };
            settingsManagerMock
                .Setup(ip => ip.ReadAsync("COMMON", "Logging", "Exceptions"))
                .ReturnsAsync(logSettings);

            var smtpSettings = new ApiItemModel<ApplicationSettingsModel>
            {
                Identification = new IdentificationModel { Cmf = "CMF123" },
                Item = new ApplicationSettingsModel
                {
                    State = "COMMON",
                    System = "EmailService",
                    Subsystem = "SmtpSettings",
                    Settings = JsonDocument.Parse("{\"Host\": \"test.com\", \"Port\": 25, \"Password\": \"pass\", \"Username\": \"user1\"}")
                }
            };
            settingsManagerMock
                .Setup(ip => ip.ReadAsync("COMMON", "EmailService", "SmtpSettings"))
                .ReturnsAsync(smtpSettings);
            var splunkManagerMock = new Mock<ISplunkManager>();
            var clientMock = new Mock<ISmtpClient>();
            clientMock.Setup(x => x.SendAsync(It.IsAny<MailMessage>()));
            EmailService emailService = new EmailService(splunkManagerMock.Object, settingsManagerMock.Object, clientMock.Object);

            //Act
            await emailService.SendAsync("gponnaganti@cvrreg.com", "gponnaganti@cvrreg.com", "test", "<p>test body</p>", true);

            //Assert
            Assert.IsTrue(1 == 1, "Success, nothing to assert");
        }

        [TestMethod]
        public async Task TestAttachemtSend()
        {
            //Arrange
            var settingsManagerMock = new Mock<IApplicationSettingsManager>();

            var logSettings = new ApiItemModel<ApplicationSettingsModel>
            {
                Identification = new IdentificationModel { Cmf = "CMF123" },
                Item = new ApplicationSettingsModel
                {
                    State = "COMMON",
                    System = "Logging",
                    Subsystem = "Exceptions",
                    Settings = JsonDocument.Parse("{\"Path\": \"d:/logs/cdk.evr.converge.cbe.common/Exception.log\"}")
                }
            };
            settingsManagerMock
                .Setup(ip => ip.ReadAsync("COMMON", "Logging", "Exceptions"))
                .ReturnsAsync(logSettings);

            var smtpSettings = new ApiItemModel<ApplicationSettingsModel>
            {
                Identification = new IdentificationModel { Cmf = "CMF123" },
                Item = new ApplicationSettingsModel
                {
                    State = "COMMON",
                    System = "EmailService",
                    Subsystem = "SmtpSettings",
                    Settings = JsonDocument.Parse("{\"Host\": \"test.com\", \"Port\": 25, \"Password\": \"pass\", \"Username\": \"user1\"}")
                }
            };
            settingsManagerMock
                .Setup(ip => ip.ReadAsync("COMMON", "EmailService", "SmtpSettings"))
                .ReturnsAsync(smtpSettings);
            var splunkManagerMock = new Mock<ISplunkManager>();
            var clientMock = new Mock<ISmtpClient>();
            clientMock.Setup(x => x.SendAsync(It.IsAny<MailMessage>()));
            EmailService emailService = new EmailService(splunkManagerMock.Object, settingsManagerMock.Object, clientMock.Object);
            string strWorkPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string fileName = $"{Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)}/mailAttachmentTest.Txt";
            string fileContent = "Attached mail";

            using (FileStream fs = File.Create(fileName))
            {
                // Add some text to file    
                Byte[] title = new UTF8Encoding(true).GetBytes(fileContent);
                fs.Write(title, 0, title.Length);
            }

            //Act
            await emailService.SendAttachmentAsync("venkatamahesh.karna@cdk.com", "venkatamahesh.karna@cdk.com", "test", "<p>test body</p>", fileName, true);

            //Assert
            Assert.IsTrue(1 == 1, "Success, nothing to assert");
        }

        [TestMethod]
        public async Task TestSend_HandlesException()
        {
            var settingsManagerMock = new Mock<IApplicationSettingsManager>();
            var splunkManagerMock = new Mock<ISplunkManager>();
            var clientMock = new Mock<ISmtpClient>();
            clientMock.Setup(x => x.SendAsync(It.IsAny<MailMessage>())).Throws(new ArgumentNullException());
            EmailService _emailService = new EmailService(splunkManagerMock.Object, settingsManagerMock.Object, clientMock.Object);

            //Act
            await _emailService.SendAsync("gponnaganti@cvrreg.com", "gponnaganti@cvrreg.com", "test", "<p>test body</p>", true);

            //Assert
            Assert.IsTrue(1 == 1, "Success, nothing to assert");
        }
    }
}
