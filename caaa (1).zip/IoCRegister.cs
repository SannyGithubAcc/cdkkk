﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;

namespace cdk.evr.converge.cbe.common.ioc
{
    /// <summary>
    /// bootstrap class to scan all cdk.evr assemblies for class implementing IIocStartup interface and 
    /// </summary>
    public static class IoCRegister
    {
        internal static IServiceCollection Services { get; private set; }

        /// <summary>
        /// Scan provided assembly for Classes implements IIocStarup interface and invoke
        /// ConfigureServices(IServiceCollection services) to register a Injection mapping
        /// </summary>
        /// <param name="assembly">assembly to be searched</param>
        /// <param name="prefixFilters">Only classes with name started with cdk.evr or a value in the array will be scanned.</param>
        /// <returns>Service Container</returns>
        public static IServiceCollection RegisterIocStartupForAssembly(Assembly assembly, string[] prefixFilters)
        {
            HashSet<string> LoadedAssemblyNames = new HashSet<string>();
            HashSet<string> ScannedAssemblyNames = new HashSet<string>();

            string[] prefixFilterToLower = new string[] { };

            if (prefixFilters != null)
            {
                prefixFilterToLower = prefixFilters.Select(c => c.ToLower()).ToArray();
            }

            if (!HasCorrectPrefix("cdk.evr", prefixFilterToLower))
            {
                prefixFilterToLower = prefixFilterToLower.Append("cdk.evr").ToArray();
            }

            ScanAssemblyForIocStartup(Services, assembly, prefixFilterToLower, false, LoadedAssemblyNames, ScannedAssemblyNames);

            foreach (Assembly loadedAssembly in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                LoadedAssemblyNames.Add(assembly.FullName);
                if (HasCorrectPrefix(assembly.FullName, prefixFilterToLower))
                {
                    ScanAssemblyForIocStartup(Services, loadedAssembly, prefixFilterToLower, false, LoadedAssemblyNames, ScannedAssemblyNames);
                }
            }

            return Services;
        }

        /// <summary>
        /// Scan all Assemblies for Classes implements IIocStarup interface and invoke
        /// ConfigureServices(IServiceCollection services) to register a Injection mapping
        /// </summary>
        /// <param name="serviceCollection">Service Container to be used</param>
        /// <param name="prefixFilters">Only assemblies with name started with cdk.evr or a value in the array will be scanned.</param>
        /// <returns>Service Container</returns>
        public static IServiceCollection RegisterIocStartup(IServiceCollection serviceCollection, string[] prefixFilters)
        {
            Services = serviceCollection;

            HashSet<string> LoadedAssemblyNames = new HashSet<string>();
            HashSet<string> ScannedAssemblyNames = new HashSet<string>();

            string[] prefixFilterToLower = { };

            if (prefixFilters != null)
            {
                prefixFilterToLower = prefixFilters.Select(c => c.ToLower()).ToArray();
            } 
            
            if (!HasCorrectPrefix("cdk.evr", prefixFilterToLower))
            {
                prefixFilterToLower = prefixFilterToLower.Append("cdk.evr").ToArray();
            }

            ScanAssemblyForIocStartup(serviceCollection, Assembly.GetCallingAssembly(), prefixFilterToLower, false, LoadedAssemblyNames, ScannedAssemblyNames);

            foreach (Assembly assembly in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                LoadedAssemblyNames.Add(assembly.FullName);
                if (HasCorrectPrefix(assembly.FullName, prefixFilterToLower))
                {
                    ScanAssemblyForIocStartup(serviceCollection, assembly, prefixFilterToLower, false, LoadedAssemblyNames, ScannedAssemblyNames);
                }
            }

            return serviceCollection;
        }

        private static bool HasCorrectPrefix(string assemblyName, string[] prefixFilters)
        {
            if (prefixFilters != null)
            {
                foreach (string aPrefix in prefixFilters)
                {
                    if (assemblyName.StartsWith(aPrefix))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private static void ScanAssemblyForIocStartup(IServiceCollection serviceCollection, Assembly assembly, string[] prefixFilters, bool checkPrefixFilters,
            HashSet<string> LoadedAssemblyNames, HashSet<string> ScannedAssemblyNames)
        {
            if (ScannedAssemblyNames.Contains(assembly.FullName))
                return;

            if (checkPrefixFilters && !HasCorrectPrefix(assembly.GetName().Name.ToLower(), prefixFilters))
                return;

            ScannedAssemblyNames.Add(assembly.FullName);
            foreach (Type aType in assembly.GetTypes())
            {
                if (aType.IsClass && !aType.IsAbstract && typeof(IIoCStartup).IsAssignableFrom(aType))
                {
                    try
                    {
                        IIoCStartup startupObj = (IIoCStartup)assembly.CreateInstance(aType.FullName);
                        startupObj.ConfigureServices(serviceCollection);
                    }
                    catch (Exception)
                    {
                    }
                }
            }

            foreach (AssemblyName referencedAssemblyName in assembly.GetReferencedAssemblies())
            {
                if (LoadedAssemblyNames.Contains(referencedAssemblyName.FullName))
                {
                    Assembly referencedAssembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(c => c.FullName == referencedAssemblyName.FullName);
                    if (referencedAssembly != null)
                    {
                        ScanAssemblyForIocStartup(serviceCollection, referencedAssembly, prefixFilters, true, LoadedAssemblyNames, ScannedAssemblyNames);
                    }
                }
                else
                {
                    try
                    {
                        Assembly referencedAssembly = AppDomain.CurrentDomain.Load(referencedAssemblyName);
                        if (referencedAssembly != null)
                        {
                            LoadedAssemblyNames.Add(referencedAssembly.FullName);
                            ScanAssemblyForIocStartup(serviceCollection, referencedAssembly, prefixFilters, true, LoadedAssemblyNames, ScannedAssemblyNames);
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            }
        }
    }
}
