﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics.CodeAnalysis;
using TestUtilities;

namespace cdk.evr.converge.cbe.common.ioc.Tests
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class IoCFactoryTests : TestStartup
    {
        private readonly IIoCFactory _iocFactory;

        public IoCFactoryTests()
        {
            _iocFactory = new IoCFactory();
        }

        [TestMethod]
        public void GetServiceTest()
        {
            var result = _iocFactory.GetService<IStoreValidator>();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetServiceFailTest()
        {
            var result2 = _iocFactory.GetService<StoreValidator>();
            Assert.IsNull(result2);
        }

        [TestMethod]
        public void GetService2Test()
        {
            var result = _iocFactory.GetService(typeof(IStoreValidator));
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetService2FailTest()
        {
            var result2 = _iocFactory.GetService(typeof(StoreValidator));
            Assert.IsNull(result2);
        }

        [TestMethod]
        public void GetRequiredServiceTest()
        {
            var result = _iocFactory.GetRequiredService<IStoreValidator>();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(System.InvalidOperationException),
            "No service for type 'cdk.evr.converge.cbe.common.CompanyValidator' has been registered.")]
        public void GetRequiredServiceFailTest()
        {
            var result2 = _iocFactory.GetRequiredService<StoreValidator>();
            Assert.IsNull(result2);
        }


        [TestMethod]
        public void GetRequiredService2Test()
        {
            var result = _iocFactory.GetRequiredService(typeof(IStoreValidator));
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(System.InvalidOperationException),
            "No service for type 'cdk.evr.converge.cbe.common.CompanyValidator' has been registered.")]
        public void GetRequiredService2FailTest()
        {
            var result2 = _iocFactory.GetRequiredService(typeof(StoreValidator));
            Assert.IsNotNull(result2);
        }
    }
}