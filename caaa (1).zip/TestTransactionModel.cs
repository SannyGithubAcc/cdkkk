﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using cdk.evr.converge.cbe.common.models.Transactions;

namespace TestUtilities
{
    [ExcludeFromCodeCoverage]
    public class TestTransactionModel : TransactionBaseModel
    {
        public List<OwnerBaseModel> Owners { get; set; }
        public VehicleBaseModel Vehicle { get; set; }
        public RegistrationBaseModel Registration { get; set; }
        public TitleBaseModel Title { get; set; }
        public List<FeeBaseModel> Fees { get; set; }
        public bool FeeAcceptanceIndc { get; set; }

        public TestTransactionModel() : base()
        {
            Owners = new List<OwnerBaseModel>();
            Vehicle = new VehicleBaseModel();
            Registration = new RegistrationBaseModel();
            Title = new TitleBaseModel();
            Fees = new List<FeeBaseModel>();
        }

        public TestTransactionModel(TestTransactionModel model) : base(model)
        {
            Owners = new List<OwnerBaseModel>();
            Owners.AddRange(model.Owners);
            Vehicle = new VehicleBaseModel(model.Vehicle);
            Registration = new RegistrationBaseModel(model.Registration);
            Title = new TitleBaseModel(model.Title);
            Fees = new List<FeeBaseModel>();
            Fees.AddRange(model.Fees);
        }

        public override List<OwnerBaseModel> GetOwnerObject()
        {
            return Owners;
        }

        public override RegistrationBaseModel GetRegistrationObject()
        {
            return Registration;
        }

        public override TitleBaseModel GetTitleObject()
        {
            return Title;
        }

        public override VehicleBaseModel GetVehicleObject()
        {
            return Vehicle;
        }

        public override List<FeeBaseModel> GetFeeObject()
        {
            return Fees;
        }
    }
}
