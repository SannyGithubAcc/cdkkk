using System;
using Microsoft.Extensions.DependencyInjection;

namespace cdk.evr.converge.cbe.common.ioc
{
    public interface IIoCFactory
    {
        TService GetService<TService>() where TService : class;
        object GetService(Type type);
        TService GetRequiredService<TService>() where TService : class;
        object GetRequiredService(Type type);
    }

    /// <summary>
    /// This class provides methods for retrieving services from the service collection maintained by IoCRegister.
    /// </summary>
    public class IoCFactory : IIoCFactory
    {
        /// <summary>
        /// Gets the service associated with the specified type.
        /// </summary>
        /// <typeparam name="TService">Type parameter of interface of the class to return.</typeparam>
        /// <returns>Instantiated object for the class that was registered with the supplied type parameter TService or null if a service could not be found.</returns>
        public TService GetService<TService>() where TService : class
        {
            TService service = IoCRegister.Services.BuildServiceProvider().GetService<TService>();
            return service;
        }

        /// <summary>
        /// Gets the service associated with the specified type.
        /// </summary>
        /// <param name="type">Type of object to return.</param>
        /// <returns>Instantiated object for the class that was registered with the supplied type parameter TService or null if a service could not be found.</returns>
        public object GetService(Type type)
        {
            var service = IoCRegister.Services.BuildServiceProvider().GetService(type);
            return service;
        }

        /// <summary>
        /// Gets the service associated with the specified type.
        /// </summary>
        /// <typeparam name="TService">Type parameter of interface of the class to return.</typeparam>
        /// <returns>Instantiated object for the class that was registered with the supplied type parameter TService or thows an exception if a service could not be found.</returns>
        public TService GetRequiredService<TService>() where TService : class
        {
            TService service = IoCRegister.Services.BuildServiceProvider().GetRequiredService<TService>();
            return service;
        }

        /// <summary>
        /// Gets the service associated with the specified type.
        /// </summary>
        /// <param name="type">Type of object to return.</param>
        /// <returns>Instantiated object for the class that was registered with the supplied type parameter TService or thows an exception if a service could not be found.</returns>
        public object GetRequiredService(Type type)
        {
            var service = IoCRegister.Services.BuildServiceProvider().GetRequiredService(type);
            return service;
        }
    }
}
