﻿using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Inventory;
using cdk.evr.converge.cbe.common.models.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using TestUtilities;

namespace cdk.evr.converge.cbe.common.tests
{
    [Ignore]
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class InventoryPoolsManagerActualTests : TestStartup
    {

        private readonly IPostgreSqlContext _context;
        private readonly IInventoryPoolsProvider _provider;
        private readonly IInventoryPoolsManager _manager;

        public InventoryPoolsManagerActualTests()
        {
            _context = (IPostgreSqlContext)TestServiceProvider.GetService(typeof(IPostgreSqlContext));
            _provider = new InventoryPoolsProvider(_context);

            var settingsManagerMock = new Mock<IApplicationSettingsManager>();
            var setting = new ApiItemModel<ApplicationSettingsModel>
            {
                Identification = new IdentificationModel { Cmf = "TEST0001", InventorySite = "XX" },
                Item = new ApplicationSettingsModel
                {
                    State = "NONE",
                    System = "NONE",
                    Subsystem = "NONE",
                    Settings = System.Text.Json.JsonDocument.Parse("{\"Path\": \"./Exception.log\"}")
                }
            };

            settingsManagerMock.Setup(x => x.ReadAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(setting);
            var splunkManagerMock = new Mock<ISplunkManager>();

            _manager = new InventoryPoolsManager(_provider, settingsManagerMock.Object, splunkManagerMock.Object);
        }

        [TestMethod]
        public async Task GetPool_ShouldSucceed()
        {
            var testPool = await _manager.GetPool("V07", "BG", "IPP");

            Assert.IsNotNull(testPool);
            Assert.IsFalse(testPool.HasErrors);
            Assert.AreEqual("CAWHSE07", testPool.Item.Cmf);
        }

        [TestMethod]
        public async Task GetPool_ShouldReturnError()
        {
            var testPool = await _manager.GetPool("V07", "BH", "UIP");

            Assert.IsNotNull(testPool);
            Assert.IsTrue(testPool.HasErrors, "Expected errors");
            Assert.IsTrue(testPool.Errors.AsJsonString().Contains("Unable to read a pool record associated"), testPool.Errors.AsJsonString());
        }

        [TestMethod]
        public async Task GetPools_ShouldSucceed()
        {
            var testPools = await _manager.GetPools("CAWHSE07", "IPP");

            Assert.IsNotNull(testPools);
            Assert.IsFalse(testPools.HasErrors);
            Assert.AreEqual(2, testPools.Items.Count);
            Assert.AreEqual("V07", testPools.Items.First().OfficeId);
        }

        [TestMethod]
        public async Task CreateInventoryPool_ShouldSucceed()
        {
            //Arrange
            var record = new ApiItemModel<InventoryPoolsModel>();
            record.Identification.Cmf = "CAWHSE07";
            record.Identification.UserId = "test_user";
            record.Item.State = "CA";
            record.Item.Cmf = "TEST0001";
            record.Item.OfficeId = "VE3";
            record.Item.SiteId = "LQ";
            record.Item.PoolType = "IPP";
            record.Item.Description = "Reflectorized Automobile Plate Test";
            //Act
            var result = await _manager.SaveAsync(record);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.HasErrors);

        }

        [TestMethod]
        public async Task UpdateInventoryPool_ShouldSucceed()
        {
            //Arrange
            var record = new ApiItemModel<InventoryPoolsModel>();
            record.Item.Id = 56;
            record.Identification.Cmf = "CAWHSE07";
            record.Identification.UserId = "test_user";
            record.Item.State = "CA";
            record.Item.Cmf = "TEST0001";
            record.Item.OfficeId = "VE6";
            record.Item.SiteId = "LA";
            record.Item.PoolType = "IPP";
            record.Item.Description = "Reflectorized Automobile Plate Test";

            var result = await _manager.SaveAsync(record);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.HasErrors);

        }

        [TestMethod]
        public async Task DeleteInventoryPool_ShouldSucceed()
        {
            //Arrange
            var record = new ApiItemModel<InventoryPoolsModel>();
            record.Item.Id = 56;
            record.Identification.Cmf = "CAWHSE07";
            record.Identification.UserId = "test_user";
            record.Item.State = "CA";
            record.Item.Cmf = "TEST0001";
            record.Item.OfficeId = "VE6";
            record.Item.SiteId = "LA";
            record.Item.PoolType = "IPP";
            record.Item.Description = "Reflectorized Automobile Plate Test";

            var result = await _manager.DeleteAsync(record);
            //Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.HasErrors);
        }

    }
}

