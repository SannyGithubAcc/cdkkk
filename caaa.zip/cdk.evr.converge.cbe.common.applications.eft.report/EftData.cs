﻿using System;
using System.Collections.Generic;

namespace cdk.evr.converge.cbe.common.applications.eft.report
{
    public class EftData
    {
        public DateTime EftDate { get; set; }
        public decimal DebitTotal { get; set; }
        public decimal CreditTotal { get; set; }
        public List<string> CmfTotal { get; set; }
        public int RecordsTotal { get; set; }
    }
}
