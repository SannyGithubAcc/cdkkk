﻿using System;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.eft.report
{
    public interface IEftReport
    {
        Task<string> GetEftReport(DateTime? startDate, DateTime? endDate);
        bool Debug { get; set; }
    }
}
