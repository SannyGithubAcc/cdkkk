﻿using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text;

namespace cdk.evr.converge.cbe.common.applications.eft.report
{
    [ExcludeFromCodeCoverage]
    class Program
    {
        static int Main(string[] args)
        {
            string requestedEnvironment = "Dev";
            string fileName = String.Empty;
            DateTime startDate = DateTime.Today, endDate = DateTime.Today;

            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            for (var index = 0; index < args.Length; index++)
            {
                if (args[index].ToLower() == "-h")
                {
                    Console.WriteLine(@"Usage: dotnet cdk.evr.convercdk.evr.converge.cbe.common.applications.eftDev -sd 2022/02/13 -ed 2022/02/13 -f C:\Test.log");
                    return 0;
                }

                if (args[index].ToLower() == "-e")
                {
                    ++index;
                    requestedEnvironment = args[index].ToLower();
                }

                if (args[index].ToLower() == "-sd")
                {
                    ++index;
                    startDate = Convert.ToDateTime(args[index]);
                }

                if (args[index].ToLower() == "-ed")
                {
                    ++index;
                    endDate = Convert.ToDateTime(args[index]);
                }

                if (args[index].ToLower() == "-f")
                {
                    ++index;
                    fileName = args[index];
                }
            }

            var services = ConfigureServices();
            var connectString = config.GetValue<string>($"{requestedEnvironment}ConnectionString");
            var environment = config.GetValue<string>("Environment");
            var debug = config.GetValue<bool>("Debug");
            services.AddDbContext<PostgreSqlContext>(options => options.UseNpgsql(connectString));
            var serviceProvider = services.BuildServiceProvider();

            var report = serviceProvider.GetService<IEftReport>();
            report.Debug = debug;

            Console.WriteLine($"Starting preparing Transaction summary report data at {DateTime.Now}");
            var result = report.GetEftReport(startDate, endDate).Result;
            var reportResult = CreateReport(fileName, result);
            Console.WriteLine($"Completed Transaction summary report data at {DateTime.Now}");

            return (reportResult) ? 1 : 0;
        }

        /// <summary>
        /// This will create a file and copy the transaction summary report into the file.
        /// </summary>
        /// <param name="fileName">Name of the file to save.</param>
        /// <param name="fileContent">Content of the transaction summary report</param>
        /// <returns>Returns response.</returns>
        private static bool CreateReport(string fileName, string fileContent)
        {
            try
            {
                // Check if file already exists. If yes, delete it.     
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                // Create a new file     
                using (FileStream fs = File.Create(fileName))
                {
                    // Add some text to file    
                    Byte[] title = new UTF8Encoding(true).GetBytes(fileContent);
                    fs.Write(title, 0, title.Length);
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
                return false;
            }

            return true;
        }

        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddTransient<IPostgreSqlContext, PostgreSqlContext>();
            services.AddTransient<ISplunkManager, SplunkManager>();
            services.AddTransient<IApplicationSettingsManager, ApplicationSettingsManager>();
            services.AddTransient<IRegionsProvider, RegionsProvider>();
            services.AddTransient<IDmvLogProvider, DmvLogProvider>();
            services.AddTransient<IMiscellaneousChargesProvider, MiscellaneousChargesProvider>();
            services.AddTransient<ITransactionProvider, TransactionProvider>();
            services.AddTransient<IApplicationSettingsProvider, ApplicationSettingsProvider>();
            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<ISmtpClient, SmtpClientWrapper>();
            services.AddTransient<IEftReport, EftReport>();

            return services;
        }
    }
}
