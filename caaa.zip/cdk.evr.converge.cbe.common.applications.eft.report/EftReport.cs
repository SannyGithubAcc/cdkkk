﻿using cdk.evr.converge.cbe.common.dal.Models;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.eft.report
{
    public class EftReport : IEftReport
    {
        private readonly IRegionsProvider _regionsProvider;
        private readonly ITransactionProvider _transactionProvider;
        private readonly IMiscellaneousChargesProvider _miscellaneousChargesProvider;

        private List<string> _pullAndHoldStates = new List<string>() { "CA", "WI", "WV", "MA" };

        public bool Debug { get; set; }

        public EftReport(IRegionsProvider regionsProvider,
            ITransactionProvider transactionProvider,
            IMiscellaneousChargesProvider miscellaneousChargesProvider)
        {
            _regionsProvider = regionsProvider;
            _transactionProvider = transactionProvider;
            _miscellaneousChargesProvider = miscellaneousChargesProvider;
            Debug = false;
        }

        public async Task<string> GetEftReport(DateTime? startDate, DateTime? endDate)
        {
            StringBuilder reportBody = new StringBuilder();

            try
            {
                if (!startDate.HasValue)
                {
                    startDate = DateTime.UtcNow.AddDays(-1);
                }
                if (!endDate.HasValue)
                {
                    endDate = startDate;
                }
                startDate = new DateTime(startDate.Value.Year, startDate.Value.Month, startDate.Value.Day, 0, 0, 0, 0);
                endDate = new DateTime(endDate.Value.Year, endDate.Value.Month, endDate.Value.Day, 23, 59, 59, 999);

                StringBuilder emailBody = new StringBuilder();

                PrepareFormattedText(reportBody, "Electronic Funds Transfer Summary", "", "", "", "", "", "", "", "", "Transmission Date:", startDate.Value.ToString("MM/dd/yy").ToString(), "", "");

                PrepareFormattedText(reportBody, GetMarginString(14, true), GetMarginString(8, true), GetMarginString(6, true), GetMarginString(8, true), GetMarginString(6, true),
                  GetMarginString(8, true), GetMarginString(16, true), GetMarginString(16, true), GetMarginString(14, true), GetMarginString(16, true), GetMarginString(16, true),
                  GetMarginString(16, true), GetMarginString(22, true));
                reportBody.Append(NewLine);

                PrepareFormattedText(reportBody, "Jurisdiction", "Region", "Type", "Date", "CMF", "Record", "Debit Detail", "Debit Settles", "Debit Amount"
                    , "Credit Detail", "Credit Settles", "Credit Amount", "Description");

                PrepareFormattedText(reportBody, GetMarginString(13, true), GetMarginString(7, true), GetMarginString(5, true), GetMarginString(7, true), GetMarginString(5, true),
                    GetMarginString(7, true), GetMarginString(15, true), GetMarginString(15, true), GetMarginString(13, true), GetMarginString(15, true), GetMarginString(15, true),
                    GetMarginString(15, true), GetMarginString(21, true));

                var regions = await _regionsProvider.ReadByStateAsync();
                var states = regions.Select(x => x.State).Distinct();

                var eftRecordsTotal = new List<EftData>();

                foreach (var state in states)
                {
                    var stateRegions = regions.Where(x => x.State == state);
                    bool hasMultipleRecords = stateRegions.Count() > 1;

                    List<string> stateCmf = new List<string>();
                    int stateTransactionCount = 0;

                    decimal stateDebitTotal = 0M;
                    decimal stateCreditTotal = 0M;

                    foreach (var region in stateRegions)
                    {
                        var allStateTransactions = await _transactionProvider.ReadCompletedByStateAndDateRangeAsync(region.State, startDate.Value, endDate.Value);
                        allStateTransactions = allStateTransactions.Where(x => x.CurrentDmvDate.HasValue || x.CurrentDmvDate.HasValue).ToList();

                        List<FilterModel> filterModels = new List<FilterModel>()
                        {
                            new FilterModel() { FieldName = "RunOn", RangeFromValue = startDate.Value.ToString(), RangeToValue = endDate.ToString()},
                        };
                        ApiListModel<MiscellaneousChargesDbModel> response = await _miscellaneousChargesProvider.ReadByStateFSPAsync(region.State, filterModels, new List<SortModel>(), null);

                        var groupTransations = allStateTransactions.GroupBy(x => new { x.CurrentEftDate, x.CurrentDmvDate }).ToList();
                        hasMultipleRecords = !hasMultipleRecords && groupTransations.Count() > 0;

                        foreach (var transaction in groupTransations)
                        {
                            var transactionsByDate = allStateTransactions.Where(x => x.CurrentEftDate == transaction.Key.CurrentEftDate && x.CurrentDmvDate == transaction.Key.CurrentDmvDate).ToList();

                            var miscellaneousTransactions = response.Items.Where(x => x.CurrentEftDate == transaction.Key.CurrentEftDate);

                            decimal transactionsEftAmount = transactionsByDate.Sum(x => Convert.ToDecimal(x.TotalCurrentEft));
                            decimal miscellaneousChargesEftAmount = miscellaneousTransactions.Sum(x => Convert.ToDecimal(x.TotalCurrentEft));

                            var transactionCmfs = transactionsByDate.Select(x => x.Cmf).Distinct();
                            var miscellaneousChargesCmfs = miscellaneousTransactions.Select(x => x.Cmf).Distinct();

                            var eftType = _pullAndHoldStates.Contains(region.State) ? "11" : "10";
                            var cmfCount = transactionCmfs.Union(miscellaneousChargesCmfs).Count();

                            var debitTotal = transactionsEftAmount + miscellaneousChargesEftAmount;
                            stateDebitTotal += debitTotal;

                            var creditTotal = transactionsEftAmount + miscellaneousChargesEftAmount;
                            stateCreditTotal += creditTotal;

                            var regionCmf = transactionCmfs.Union(miscellaneousChargesCmfs).ToList();
                            stateCmf = stateCmf.Union(regionCmf).ToList();

                            var transactionCount = transactionsByDate.Count + response.Items.Count;
                            stateTransactionCount += transactionCount;

                            var formattedDebitTotal = string.Format("{0:C}", debitTotal);
                            var formattedCreditTotal = string.Format("{0:C}", creditTotal);

                            AddEftTotals(eftRecordsTotal, regionCmf, transaction.Key.CurrentDmvDate.Value, region.State, creditTotal);
                            AddEftTotals(eftRecordsTotal, regionCmf, transaction.Key.CurrentEftDate.Value, region.State, debitTotal, true, transactionCount);

                            if (_pullAndHoldStates.Contains(region.State))
                            {
                                PrepareFormattedText(reportBody, region.State, region.Region, eftType, startDate.Value.ToString("MMM dd"), cmfCount.ToString(), transactionCount.ToString(), "FEES"
                                        , transaction.Key.CurrentEftDate.Value.ToString("MM/dd/yy"), formattedDebitTotal, "", "", "", region.Name);
                            }
                            else
                            {
                                PrepareFormattedText(reportBody, region.State, region.Region, eftType, startDate.Value.ToString("MMM dd"), cmfCount.ToString(), transactionCount.ToString(), "FEES"
                                        , transaction.Key.CurrentEftDate.Value.ToString("MM/dd/yy"), formattedDebitTotal, "PAYMENT", transaction.Key.CurrentDmvDate.Value.ToString("MM/dd/yy")
                                        , formattedCreditTotal, region.Name);
                            }
                        }
                    }

                    if (hasMultipleRecords)
                    {
                        var formattedStateDebitTotal = string.Format("{0:C}", stateDebitTotal);
                        var formattedStateCreditTotal = string.Format("{0:C}", stateCreditTotal);

                        PrepareFormattedText(reportBody, "", "", "", "", GetMarginString(5), GetMarginString(7), "", "", GetMarginString(13), "", "",
                            _pullAndHoldStates.Contains(state) ? "" : GetMarginString(15), "");

                        PrepareFormattedText(reportBody, "", "", "", "", stateCmf.Distinct().Count().ToString(), stateTransactionCount.ToString(), "", "",
                            formattedStateDebitTotal, "", "", _pullAndHoldStates.Contains(state) ? "" : formattedStateCreditTotal, "");

                        reportBody.Append(NewLine);
                    }
                }

                PrepareFormattedText(reportBody, GetMarginString(13, true), "", "", "", "", "", "", GetMarginString(15, true), GetMarginString(13, true), "",
                    GetMarginString(15, true), GetMarginString(15, true), "");

                foreach (var eft in eftRecordsTotal.OrderBy(x => x.EftDate))
                {
                    var formattedCreditTotal = string.Format("{0:C}", eft.CreditTotal);
                    var formattedDebitTotal = string.Format("{0:C}", eft.DebitTotal);

                    if (eft.DebitTotal > 0)
                    {
                        PrepareFormattedText(reportBody, "RELEASED", "", "", "", "", "", "", eft.EftDate.ToString("MM/dd/yy"), formattedDebitTotal, "",
                            eft.EftDate.ToString("MM/dd/yy"), formattedCreditTotal, "");
                    }
                    else
                    {
                        PrepareFormattedText(reportBody, "WAREHOUSED", "", "", "", "", "", "", "", "", "", eft.EftDate.ToString("MM/dd/yy"), formattedCreditTotal, "");
                    }
                }

                PrepareFormattedText(reportBody, "", "", "", "", GetMarginString(5, true), GetMarginString(7, true), "", "", GetMarginString(13, true), "", "",
                     GetMarginString(15, true), "");

                var formattedGrandCreditTotal = string.Format("{0:C}", eftRecordsTotal.Select(x => x.CreditTotal).Sum());
                var formattedGrandDebitTotal = string.Format("{0:C}", eftRecordsTotal.Select(x => x.DebitTotal).Sum());

                PrepareFormattedText(reportBody, "Grand Total", "", "", "", eftRecordsTotal.Select(x => x.CmfTotal.Distinct().Count()).Sum().ToString(),
                    eftRecordsTotal.Select(x => x.RecordsTotal).Sum().ToString(), "", "", formattedGrandDebitTotal, "", "", formattedGrandCreditTotal, "");

                if (Debug)
                {
                    Console.WriteLine(reportBody);
                }

                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }

            return reportBody.ToString();
        }

        private void PrepareFormattedText(StringBuilder reportBody, string column1, string column2, string column3, string column4, string column5,
            string column6, string column7, string column8, string column9, string column10, string column11, string column12, string column13)
        {
            reportBody.Append($"{column1,12}{column2,7}{column3,5}{column4,7}{column5,5}{column6,7}{column7,15}" +
                                              $"{column8,15}{column9,13}{column10,15}{column11,15}{column12,15}{column13,21}");
            reportBody.Append(NewLine);
        }

        private string GetMarginString(int length, bool needEquals = false)
        {
            string marginStyle = "-";
            if (needEquals)
            {
                marginStyle = "=";
            }

            string result = string.Empty;
            for (int i = 0; i < length - 1; i++)
            {
                result += marginStyle;
            }

            return result;
        }

        private void AddEftTotals(List<EftData> eftRecords, List<string> cmfs, DateTime eftDate, string state, decimal amount, bool isDebitRecord = false, int transactionCount = 0)
        {
            var creditTotal = _pullAndHoldStates.Contains(state) ? 0 : amount;
            if (isDebitRecord || (creditTotal > 0 && !isDebitRecord))
            {
                var eftRecord = eftRecords.Where(x => x.EftDate == eftDate).FirstOrDefault();
                if (eftRecord != null)
                {
                    eftRecord.CreditTotal += isDebitRecord ? 0 : _pullAndHoldStates.Contains(state) ? 0 : amount;
                    eftRecord.DebitTotal += !isDebitRecord ? 0 : amount;
                    eftRecord.CmfTotal = isDebitRecord ? eftRecord.CmfTotal.Union(cmfs).ToList() : eftRecord.CmfTotal;
                    eftRecord.RecordsTotal += isDebitRecord ? transactionCount : 0;
                }
                else
                {
                    eftRecords.Add(new EftData
                    {
                        CreditTotal = isDebitRecord ? 0 : _pullAndHoldStates.Contains(state) ? 0 : amount,
                        DebitTotal = !isDebitRecord ? 0 : amount,
                        CmfTotal = isDebitRecord ? cmfs : new List<string>(),
                        RecordsTotal = isDebitRecord ? transactionCount : 0,
                        EftDate = eftDate,
                    });
                }
            }
        }

        private string NewLine
        {
            get { return "\n"; }
        }
    }
}
