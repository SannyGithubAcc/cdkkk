﻿using System;
using cdk.evr.converge.cbe.common.dal.Models;
using System.Text;
using cdk.evr.converge.cbe.common.dal.Providers;
using System.Linq;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.billing.cbe
{
    /// <summary>
    /// This class is used to generate host billing files
    /// </summary>
    public class CBEBillingGenerator : ICBEBillingGenerator
    {
        private readonly IRegionsManager _regionsManager;
        private readonly ITransactionProvider _transactionProvider;
        private readonly IStateManager _stateManager;

        public bool Debug { get; set; }

        /// <summary>
        /// Constructor with dependancy injection 
        /// </summary>
        /// <param name="regionsManager"></param>
        /// <param name="transactionProvider"></param>
        /// <param name="stateManager"></param>
        public CBEBillingGenerator(IRegionsManager regionsManager,
            ITransactionProvider transactionProvider,
            IStateManager stateManager)
        {
            _regionsManager = regionsManager;
            _transactionProvider = transactionProvider;
            _stateManager = stateManager;

            Debug = false;
        }

        /// <summary>
        /// Gets content of cbe billing file
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>String of a billing file or an empty string</returns>
        public async Task<string> GetCBEBillingFile(DateTime? startDate, DateTime? endDate)
        {
            const string detailHeader = "JURISDICTION CODE|SHIP TO CMF|BILL CATALOG|ORIG COUNT|ADJ COUNT|PERIOD";
            try
            {
                if (!startDate.HasValue || !endDate.HasValue)
                {
                    Console.WriteLine("Date range values are required.");

                    return string.Empty;
                }
                if (startDate.Value > endDate.Value)
                {
                    Console.WriteLine("Date range values are invalid.");

                    return string.Empty;
                }
                startDate = startDate.Value;
                endDate = endDate.Value.Date.AddDays(1).AddMilliseconds(-1);
                StringBuilder billingFileData = new StringBuilder();
                var regions = await _regionsManager.ReadByStateAsync();
                if (!regions.HasErrors)
                {
                    var states = regions.Items.Select(x => x.State).Distinct();
                    // header per file.
                    billingFileData.AppendLine(detailHeader);
                    foreach (var state in states)
                    {
                        var stateData = await _stateManager.ReadByStateBillingModelAndBillingTypeAsync(state, "CBE", "Monthly");
                        if (!stateData.HasErrors && stateData.Item != null)
                        {
                            var allStateTransactions = await _transactionProvider.ReadCompletedByStateAndDateRangeAsync(state, startDate.Value, endDate.Value);
                            if (allStateTransactions.Any())
                            {
                                var groupQuery = allStateTransactions.GroupBy(
                                        x => new { workDate = x.RunOn.Value.ToString("MMddyy"), x.Cmf, x.BillingCategory },
                                        (key, billings) => new
                                        {
                                            wd = key.workDate,
                                            cmf = key.Cmf,
                                            category = key.BillingCategory,
                                            count = billings.Count(),
                                        });

                                // Iterate over each anonymous type.
                                foreach (var result in groupQuery)
                                {
                                    billingFileData.AppendLine(GetDetailRecord(state, result.cmf, result.category, result.count, result.wd));
                                }
                            }
                        }
                        else
                        {
                            Console.Error.WriteLine($"Error/s occured while searching for billable transactions in state: {state}");
                            foreach (var error in stateData.Errors)
                            {
                                Console.Error.WriteLine(error);
                            }

                            return string.Empty;
                        }
                    }
                }
                else
                {
                    Console.Error.WriteLine("Error/s occured while searching for billable regions:");
                    foreach (var error in regions.Errors)
                    {
                        Console.Error.WriteLine(error);
                    }

                    return string.Empty;
                }
                if (Debug)
                {
                    Console.WriteLine(billingFileData);
                }
                Console.WriteLine();

                return billingFileData.ToString();
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Exception: {ex.Message}");

                return string.Empty;
            }
        }

        private string GetDetailRecord(string state, string cmf, string catalog, int count, string workDate)
        {
            const string delimiter = "|";
            /*
                detail $this->getGeoCode() . '|' . $this->getCMF($location) . '|' . $catalogNumber . '|' . $tranCount . '|0|' . $this->getBillingWorkDate($workDate);
            */

            StringBuilder detailBuilder = new StringBuilder();
            detailBuilder.Append(state);
            detailBuilder.Append(delimiter);
            detailBuilder.Append(cmf);
            detailBuilder.Append(delimiter);
            detailBuilder.Append(catalog);
            detailBuilder.Append(delimiter);
            detailBuilder.Append(count.ToString());
            detailBuilder.Append(delimiter);
            detailBuilder.Append("0");
            detailBuilder.Append(delimiter);
            detailBuilder.Append(workDate);
            return detailBuilder.ToString();
        }
    }
}

