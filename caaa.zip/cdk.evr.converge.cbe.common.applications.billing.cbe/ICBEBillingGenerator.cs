﻿using System;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.billing.cbe
{
    public interface ICBEBillingGenerator
    {
        bool Debug { get; set; }

        /// <summary>
        /// Gets content of cbe billing file
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>String of a billing file or an empty string</returns>
        Task<string> GetCBEBillingFile(DateTime? startDate, DateTime? endDate);
    }
}