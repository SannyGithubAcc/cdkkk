﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.applications.billing.cbe;
using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.common.applications.billing.eft
{
    [ExcludeFromCodeCoverage]
    class Program
    {
        static async Task<int> Main(string[] args)
        {
            string requestedEnvironment = "Dev";
            string fileName = string.Empty;
            DateTime billingDate = DateTime.Today.AddMonths(-1);
            DateTime startDate = new DateTime(billingDate.Year, billingDate.Month, 1);
            DateTime endDate = startDate.AddMonths(1).AddDays(-1);
            bool reportResult = false;
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            for (var index = 0; index < args.Length; index++)
            {
                if (args[index].ToLower() == "-h")
                {
                    Console.WriteLine(@"Usage: dotnet cdk.evr.converge.cbe.common.applications.billing.host.dll -e Dev -d 2022/04/20 -f C:\CBE_BILLING_{MMddYYYY}.log");
                    return 0;
                }

                if (args[index].ToLower() == "-e")
                {
                    ++index;
                    requestedEnvironment = args[index].ToLower();
                }

                if (args[index].ToLower() == "-d")
                {
                    ++index;
                    var monthYear = Convert.ToDateTime(args[index]);
                    startDate = new DateTime(monthYear.Year, monthYear.Month, 1);
                    endDate = startDate.AddMonths(1).AddDays(-1);
                }

                if (args[index].ToLower() == "-f")
                {
                    ++index;
                    fileName = args[index];
                }
            }
            try
            {
                fileName = VerifyFileName(fileName);
                var services = ConfigureServices();
                var connectString = config.GetValue<string>($"{requestedEnvironment}ConnectionString");
                var environment = config.GetValue<string>("Environment");
                var debug = config.GetValue<bool>("Debug");
                services.AddDbContext<PostgreSqlContext>(options => options.UseNpgsql(connectString));
                var serviceProvider = services.BuildServiceProvider();

                var report = serviceProvider.GetService<ICBEBillingGenerator>();
                if(report != null)
                {
                    report.Debug = debug;
                    Console.WriteLine($"Starting preparing CBE Billing data at {DateTime.Now}");
                    var result = await report.GetCBEBillingFile(startDate, endDate);
                    reportResult = CreateFile(fileName, result);
                    if (reportResult)
                    {
                        UploadToFTP(fileName, serviceProvider);
                    }
                    else
                    {
                        Console.Error.WriteLine($"Unable to create file with file name: {fileName}");
                    }
                    Console.WriteLine($"Completed CBE Billing data at {DateTime.Now}");
                    File.Delete(fileName);
                }
            }
            catch(Exception ex)
            {
                Console.Error.WriteLine("An exception occurred while setting up CBE Billing data.");
                Console.Error.WriteLine($"Exception: {ex}");
            }

            return (reportResult) ? 1 : 0;
        }

        /// <summary>
        /// This will create a CBE Billing file.
        /// </summary>
        /// <param name="fileName">Name of the file to save.</param>
        /// <param name="fileContent">Content of the transaction summary report</param>
        /// <returns>Returns response.</returns>
        private static bool CreateFile(string fileName, string fileContent)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
                using (FileStream fs = File.Create(fileName))
                {
                    Byte[] title = new UTF8Encoding(true).GetBytes(fileContent);
                    fs.Write(title, 0, title.Length);
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
                return false;
            }

            return true;
        }

        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddTransient<IPostgreSqlContext, PostgreSqlContext>();
            services.AddTransient<ISplunkManager, SplunkManager>();
            services.AddTransient<IApplicationSettingsManager, ApplicationSettingsManager>();
            services.AddTransient<IRegionsProvider, RegionsProvider>();
            services.AddTransient<ITransactionProvider, TransactionProvider>();
            services.AddTransient<IBillingCategoriesProvider, BillingCategoriesProvider>();
            services.AddTransient<IApplicationSettingsProvider, ApplicationSettingsProvider>();
            services.AddTransient<ICBEBillingGenerator, CBEBillingGenerator>();
            services.AddTransient<IFtpClient, FtpClient>();

            return services;
        }

        private static string VerifyFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                string strFilePath = Assembly.GetExecutingAssembly().Location;
                if (!string.IsNullOrEmpty(strFilePath))
                {
                    string? strWorkPath = Path.GetDirectoryName(strFilePath);
                    fileName = $"{strWorkPath}/CBE_BILLING_{DateTime.Today.ToString("yyyyMMdd")}.Txt";
                }
                else
                {
                    Console.Error.WriteLine("Unable to get the assembly for the code that is currently being executed.");
                }
            }

            return fileName;
        }

        private static async void UploadToFTP(string fileName, ServiceProvider serviceProvider)
        {
            var applicationSettingsManager = serviceProvider.GetService<IApplicationSettingsManager>();
            var ftpClient = serviceProvider.GetService<IFtpClient>();
            if (applicationSettingsManager != null && ftpClient != null)
            {
                var settingsModel = await applicationSettingsManager.ReadAsync("COMMON", "BILLING", "FTP");
                if (settingsModel != null && settingsModel.Item != null)
                {
                    var setting = JsonConvert.DeserializeObject<FtpModel>(settingsModel.Item.Settings.AsJsonString());
                    if (setting != null)
                    {
                        ftpClient.Initialize(setting.HostFtpServer, setting.UserId, setting.Password);
                        ftpClient.UploadFile(fileName, setting.Folder);
                    }
                    else
                    {
                        Console.Error.WriteLine("Unable to deserialize FTP Application Setttings");
                    }
                }
                else
                {
                    Console.Error.WriteLine("Unable to find Application Settings for state: COMMON, system: BILLING and subsystem: FTP");
                }
            }
            else
            {
                Console.Error.WriteLine("An error occured while accessing Application Setting and FTP Client.");
            }
        }
    }
}

