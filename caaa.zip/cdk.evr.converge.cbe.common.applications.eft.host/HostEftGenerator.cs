﻿using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Eft;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.Utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.eft.host
{
    /// <summary>
    /// This calss is used to genearte host Eft file
    /// </summary>
    public class HostEftGenerator : IHostEftGenerator
    {

        private readonly IRegionsProvider _regionsProvider;
        private readonly ITransactionProvider _transactionProvider;
        private readonly IApplicationSettingsManager _settings;
        private readonly ISplunkManager _splunkManager;

        private List<string> _pullAndHoldStates = new List<string>() { "CA", "WI", "WV", "MA" };

        public bool Debug { get; set; }

        private string _tmpLogPath = null;

        private string _logFilePath
        {
            get
            {
                if (string.IsNullOrEmpty(_tmpLogPath))
                    LoadSettings();

                return _tmpLogPath;
            }
        }

        /// <summary>
        /// Constructor with DI
        /// </summary>
        /// <param name="regionsProvider"></param>
        /// <param name="transactionProvider"></param>
        /// <param name="splunkManager">ISplunk Manager is responsible for creating and writing to a Serilog that feeds log entries in Splunk.</param>
        /// <param name="settingsManager">IApplicationSettingsManager responseible for accessing the application_settings table.</param>
        public HostEftGenerator(IRegionsProvider regionsProvider,
            ITransactionProvider transactionProvider,
            ISplunkManager splunkManager,
            IApplicationSettingsManager settingsManager)
        {
            _regionsProvider = regionsProvider;
            _transactionProvider = transactionProvider;
            _splunkManager = splunkManager;
            _settings = settingsManager;
            Debug = false;
        }

        /// <summary>
        /// Get contents of HostEft file
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<string> GetHostEftFile(DateTime? startDate, DateTime? endDate)
        {
            try
            {
                if (!startDate.HasValue)
                {
                    startDate = DateTime.UtcNow.AddDays(-1);
                }
                if (!endDate.HasValue)
                {
                    endDate = startDate;
                }
                startDate = startDate.Value.Date;
                endDate = endDate.Value.Date.AddDays(1).AddMilliseconds(-1);

                StringBuilder eftFileData = new StringBuilder();
                var regions = await _regionsProvider.ReadByStateAsync();

                var actionDate = GetActionDate();
                foreach (var state in regions.Select(x => x.State).Distinct())
                {
                    List<string> stateCmf = new List<string>();
                    var allStateTransactions = await _transactionProvider.ReadCompletedByStateEftModelAndDateRangeAsync(state, startDate.Value, endDate.Value, "Legacy");

                    foreach (var transaction in allStateTransactions)
                    {
                        eftFileData.AppendLine(GetDetailRecord(state, "01", transaction.RunOn.Value, transaction.Cmf, transaction.Id.ToString(), Convert.ToDecimal(transaction.TotalCurrentEft), actionDate));
                    }
                }

                if (Debug)
                {
                    Console.WriteLine(eftFileData);
                }

                Console.WriteLine();

                return eftFileData.ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                var message = "Unable to Execute eft host file.";
                _splunkManager.InitializeAndLogException(null, _logFilePath, message, ex);

                return string.Empty;
            }
        }

        private string getEftType(string state)
        {
            return _pullAndHoldStates.Contains(state) ? "11" : "10";
        }

        private string GetDetailRecord(string state, string region, DateTime workDate, string cmf,
            string reference, decimal amount, string actionDate)
        {
            /*
             * 40 – Batch Detail Record
                Description	   Length	Format
                Jurisdiction	2	   Alpha – "WI", “CA”, “FL”, “VA”, etc.
                EFT Region	    2	   Alphanumeric – “01”, “02”, “AF”, etc. when used
                                       May be set to “**” if not needed (mainly EFT types 01 and 02)
                Record Type	    2	   Always set to “40”
                Work Date	    5	   Transaction work date in MMDD format, with a trailing space
                                       e.g. “1231” represents a work date of 12/31/2021 if the base date in the “10” record is 010122
                                       Exception: Billing period in MMYY format, with a trailing space, for EFT type “01” and “02”
                CMF	            8	   Alphanumeric – “70395859”, “71043829”, “US000001”, etc.
                                       May be set to “********” if not needed (EFT types 12 and 22, though not recommended)
                EFT Type	    2	   Numeric – “01”, “10”, “11”, “12”, “02”, “20”, “21”, “22”, “97”, “98”, and “99” only
                Reference	   20	   Alphanumeric text to tie record back to the associated transaction – for internal use only
                Amount	       10	   Amount in pennies – “1234567890” means $12,345,678.90.
                Action Date	    6	   Date final funds transfer settles in MMDDYY format
                Reserved	 <=22	   Should be excluded, but set to spaces by old software
             */

            StringBuilder detailBuilder = new StringBuilder();
            detailBuilder.Append(state.EnsureSize(2));
            detailBuilder.Append(region.EnsureSize(2));
            detailBuilder.Append("40");
            detailBuilder.Append(workDate.ToString("MMdd").EnsureSize(5, ' ', false));
            detailBuilder.Append(cmf.EnsureSize(8, ' ', false));
            detailBuilder.Append(getEftType(state).EnsureSize(2));
            detailBuilder.Append(reference.EnsureSize(20, ' ', false));
            detailBuilder.Append(amount.ToString().Replace(".", "").EnsureSize(10, '0'));
            detailBuilder.Append(actionDate.EnsureSize(6));
            detailBuilder.Append("".EnsureSize(22));


            return detailBuilder.ToString();
        }

        private string GetActionDate()
        {
            var actionDate = EftHelper.GetEftDate();

            return actionDate.ToString("MMddyy");
        }

        /// <summary>
        /// Used to load the full path name of the exception file for logging purposes.
        /// </summary>
        private void LoadSettings()
        {
            var response = _settings.ReadAsync("COMMON", "Logging", "Exceptions").Result;
            if (response != null && response.Item != null)
            {
                var setting = JsonConvert.DeserializeObject<PathSetting>(response.Item.Settings.AsJsonString());
                _tmpLogPath = setting.Path;
            }
        }
    }
}