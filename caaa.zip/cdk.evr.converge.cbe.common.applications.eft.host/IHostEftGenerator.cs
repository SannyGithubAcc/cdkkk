﻿using System;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.eft.host
{
    public interface IHostEftGenerator
    {
        Task<string> GetHostEftFile(DateTime? startDate, DateTime? endDate);
        bool Debug { get; set; }
    }
}
