﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;

namespace cdk.evr.converge.cbe.common.applications.eft.host
{
    [ExcludeFromCodeCoverage]
    class Program
    {
        static async Task<int> Main(string[] args)
        {
            string requestedEnvironment = "Dev";
            string fileName = string.Empty;
            DateTime startDate = DateTime.Today.AddDays(-30), endDate = DateTime.Today;

            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            for (var index = 0; index < args.Length; index++)
            {
                if (args[index].ToLower() == "-h")
                {
                    Console.WriteLine(@"Usage: dotnet cdk.evr.converge.cbe.common.applications.eft.host.dll -e Dev -sd 2022/02/13 -ed 2022/02/13 -f C:\CBE_EFT_{MMddYYYY}.log");
                    return 0;
                }

                if (args[index].ToLower() == "-e")
                {
                    ++index;
                    requestedEnvironment = args[index].ToLower();
                }

                if (args[index].ToLower() == "-sd")
                {
                    ++index;
                    startDate = Convert.ToDateTime(args[index]);
                }

                if (args[index].ToLower() == "-ed")
                {
                    ++index;
                    endDate = Convert.ToDateTime(args[index]);
                }

                if (args[index].ToLower() == "-f")
                {
                    ++index;
                    fileName = args[index];
                }
            }
            string strFilePath = Assembly.GetExecutingAssembly().Location;
            string strWorkPath = Path.GetDirectoryName(strFilePath);
            if (string.IsNullOrEmpty(fileName))
            {
                fileName = $"{strWorkPath}/CBE_EFT_{DateTime.Today.ToString("yyyyMMdd")}.Txt";
            }

            var services = ConfigureServices();
            var connectString = config.GetValue<string>($"{requestedEnvironment}ConnectionString");
            var environment = config.GetValue<string>("Environment");
            var debug = config.GetValue<bool>("Debug");
            services.AddDbContext<PostgreSqlContext>(options => options.UseNpgsql(connectString));
            var serviceProvider = services.BuildServiceProvider();

            var report = serviceProvider.GetService<IHostEftGenerator>();
            report.Debug = debug;

            Console.WriteLine($"Starting preparing Host EFT data at {DateTime.Now}");
            var result = await report.GetHostEftFile(startDate, endDate);


            var applicationSettingsManager = serviceProvider.GetService<IApplicationSettingsManager>();
            var settingsModel = await applicationSettingsManager.ReadAsync("COMMON", "EFT", "FTP");

            var reportResult = CreateFile(fileName, result);
            if (reportResult)
            {
                var ftpClient = serviceProvider.GetService<IFtpClient>();
                if (settingsModel != null && settingsModel.Item != null)
                {
                    var setting = JsonConvert.DeserializeObject<FtpModel>(settingsModel.Item.Settings.AsJsonString());
                    ftpClient.Initialize(setting.HostFtpServer, setting.UserId, setting.Password);
                    ftpClient.UploadFile(fileName, setting.Folder);
                }
            }

            File.Delete(fileName);
            Console.WriteLine($"Completed Host EFT data at {DateTime.Now}");

            return (reportResult) ? 1 : 0;
        }

        /// <summary>
        /// This will create a Host EFT file.
        /// </summary>
        /// <param name="fileName">Name of the file to save.</param>
        /// <param name="fileContent">Content of the transaction summary report</param>
        /// <returns>Returns response.</returns>
        private static bool CreateFile(string fileName, string fileContent)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                } 
                using (FileStream fs = File.Create(fileName))
                { 
                    Byte[] title = new UTF8Encoding(true).GetBytes(fileContent);
                    fs.Write(title, 0, title.Length);
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
                return false;
            }

            return true;
        }

        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddTransient<IPostgreSqlContext, PostgreSqlContext>();
            services.AddTransient<ISplunkManager, SplunkManager>();
            services.AddTransient<IApplicationSettingsManager, ApplicationSettingsManager>();
            services.AddTransient<IRegionsProvider, RegionsProvider>();
            services.AddTransient<ITransactionProvider, TransactionProvider>();
            services.AddTransient<IApplicationSettingsProvider, ApplicationSettingsProvider>();
            services.AddTransient<IHostEftGenerator, HostEftGenerator>();
            services.AddTransient<IFtpClient, FtpClient>();
            services.AddMemoryCache();

            return services;
        }
    }
}
