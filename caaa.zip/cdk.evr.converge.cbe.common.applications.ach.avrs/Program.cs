﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text;
using Microsoft.Extensions.Configuration;
using cdk.evr.converge.cbe.common.dal;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.nacha.Eft;
using Microsoft.Extensions.Caching.Memory;
using cdk.evr.converge.cbe.common.nacha;

namespace cdk.evr.converge.cbe.common.applications.ach.avrs
{
    [ExcludeFromCodeCoverage]
    class Program
    {
        static async Task<int> Main(string[] args)
        {

            string requestedEnvironment = "Dev";
            string fileName = String.Empty;
            fileName = $"/Users/ponnagag/Desktop/ACH/AVRS_NACHA_{DateTime.Now.ToString("yyyy-MM-dd")}.Txt";
            DateTime startDate = DateTime.Today.AddDays(-30), endDate = DateTime.Today;

            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            for (var index = 0; index < args.Length; index++)
            {
                if (args[index].ToLower() == "-h")
                {
                    Console.WriteLine($"Usage: dotnet cdk.evr.converge.cbe.common.applications.ach.avrs.dll -e Dev -sd 2022/04/20 -ed 2022/04/20 -f /Users/ponnagag/Desktop/ACH/NACHA_{DateTime.Now.ToString("yyyy-MM-dd")}.Txt");
                    return 0;
                }

                if (args[index].ToLower() == "-e")
                {
                    ++index;
                    requestedEnvironment = args[index].ToLower();
                }

                if (args[index].ToLower() == "-sd")
                {
                    ++index;
                    startDate = Convert.ToDateTime(args[index]);
                }

                if (args[index].ToLower() == "-ed")
                {
                    ++index;
                    endDate = Convert.ToDateTime(args[index]);
                }

                if (args[index].ToLower() == "-f")
                {
                    ++index;
                    fileName = args[index];
                }
            }

            var services = ConfigureServices();
            var connectString = config.GetValue<string>($"{requestedEnvironment}ConnectionString");
            var environment = config.GetValue<string>("Environment");
            var debug = config.GetValue<bool>("Debug");
            services.AddDbContext<PostgreSqlContext>(options => options.UseNpgsql(connectString));
            var serviceProvider = services.BuildServiceProvider();

            var nachaGenerator = serviceProvider.GetService<INACHAGenerator>();
            nachaGenerator.Debug = debug;

            Console.WriteLine($"Starting generating NACHA file at {DateTime.Now}");
            bool result = await nachaGenerator.GenerateNACHAFile(fileName, startDate, endDate);
            if (!result) {
                return 1;
            }
            Console.WriteLine($"Completed generating NACHA file at {DateTime.Now}");

            return 0;
        }

        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddTransient<IPostgreSqlContext, PostgreSqlContext>();
            services.AddTransient<ISplunkManager, SplunkManager>();
            services.AddTransient<IApplicationSettingsManager, ApplicationSettingsManager>();
            services.AddTransient<IRegionsProvider, RegionsProvider>();
            services.AddTransient<IDmvLogProvider, DmvLogProvider>();
            services.AddTransient<IMiscellaneousChargesProvider, MiscellaneousChargesProvider>();
            services.AddTransient<ITransactionProvider, TransactionProvider>();
            services.AddTransient<IApplicationSettingsProvider, ApplicationSettingsProvider>();
            services.AddTransient<INACHAGenerator, NACHAGenerator>();
            services.AddTransient<ICmfEftManager, CmfEftManager>();
            services.AddTransient<ICmfEftProvider, CmfEftProvider>();
            services.AddTransient<IFileWriter, FileWriter>();
            services.AddTransient<IFeeSummaryProvider, FeeSummaryProvider>();
            services.AddMemoryCache();

            return services;
        }
    }
}
