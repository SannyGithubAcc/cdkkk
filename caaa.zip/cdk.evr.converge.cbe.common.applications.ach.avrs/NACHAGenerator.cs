﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cdk.evr.converge.cbe.common.dal.Models;
using cdk.evr.converge.cbe.common.dal.Providers;
using cdk.evr.converge.cbe.common.nacha.Eft;
using cdk.evr.converge.cbe.common.models;
using cdk.evr.converge.cbe.common.models.Eft;
using Newtonsoft.Json;
using cdk.evr.converge.cbe.common.models.Extensions;
using cdk.evr.converge.cbe.common.nacha;

namespace cdk.evr.converge.cbe.common.applications.ach.avrs
{
    /// <summary>
    /// NACHA file generator class
    /// </summary>
    public class NACHAGenerator : INACHAGenerator
    {
        private readonly ITransactionProvider _transactionProvider;
        private readonly IMiscellaneousChargesProvider _miscellaneousChargesProvider;
        private readonly ICmfEftManager _cmfEftManager;
        private readonly IStateManager _stateManager;
        private readonly IFeeSummaryProvider _feeSummaryProvider;
        private readonly IApplicationSettingsManager _settings;
        private readonly ISplunkManager _splunkManager;
        private readonly IFileWriter _fileWriter;
        private const int TransactionCode_LiveCheckingAccountDebit = 27;

        private string _tmpLogPath = null;

        private string _logFilePath
        {
            get
            {
                if (string.IsNullOrEmpty(_tmpLogPath))
                    LoadSettings();

                return _tmpLogPath;
            }
        }
        /// <summary>
        /// Constructor with arguments
        /// </summary>
        /// <param name="transactionProvider"></param>
        /// <param name="miscellaneousChargesProvider"></param>
        /// <param name="cmfEftManager"></param>
        /// <param name="fileWriter"></param>
        /// <param name="splunkManager">ISplunk Manager is responsible for creating and writing to a Serilog that feeds log entries in Splunk.</param>
        /// <param name="settingsManager">IApplicationSettingsManager responseible for accessing the application_settings table.</param>
        public NACHAGenerator(ITransactionProvider transactionProvider,
            IMiscellaneousChargesProvider miscellaneousChargesProvider,
            ICmfEftManager cmfEftManager,
            IStateManager stateManager,
            IFileWriter fileWriter, IFeeSummaryProvider feeSummaryProvider,
            ISplunkManager splunkManager,
            IApplicationSettingsManager settingsManager)
        {
            _transactionProvider = transactionProvider;
            _miscellaneousChargesProvider = miscellaneousChargesProvider;
            _cmfEftManager = cmfEftManager;
            _splunkManager = splunkManager;
            _settings = settingsManager;
            _fileWriter = fileWriter;
            _stateManager = stateManager;
            Debug = false;
            _feeSummaryProvider = feeSummaryProvider;
        }

        /// <summary>
        /// Flag to enable debug mode
        /// </summary>
        public bool Debug { get; set; }

        /// <summary>
        /// MEthod to generate file
        /// </summary>
        /// <param name="path"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<bool> GenerateNACHAFile(string path, DateTime? startDate, DateTime? endDate)
        {
            var result = true;
            try
            {
                if (!startDate.HasValue)
                {
                    startDate = DateTime.UtcNow.AddDays(-1);
                }
                if (!endDate.HasValue)
                {
                    endDate = startDate;
                }
                startDate = new DateTime(startDate.Value.Year, startDate.Value.Month, startDate.Value.Day, 0, 0, 0, 0);
                endDate = new DateTime(endDate.Value.Year, endDate.Value.Month, endDate.Value.Day, 23, 59, 59, 999);
                var stateRecords = await _stateManager.ReadByBillingModelAndBillingType("AVRS", "Daily");
                if (stateRecords.Items.Any() && !stateRecords.HasErrors)
                {
                    //Init file and batch writer
                    var fileModel = GetFileModel();
                    _fileWriter.Initialize(path, fileModel);
                    var batchWriter = _fileWriter.CreateBatch(225, standardEntryClassCode: "CCD"); // ACH Debit only
                    //Add content to file
                    List<string> states = new List<string>();
                    states.AddRange(stateRecords.Items.Select(x => x.State).Distinct());
                    foreach (var state in states)
                    {
                        var allStateTransactions = await _transactionProvider.ReadCompletedByStateEftModelAndDateRangeAsync("CA", startDate.Value, endDate.Value, "AVRS");
                        decimal grandTotal = await _feeSummaryProvider.ReadByStateWorkDateAsync(state, startDate.Value.Date);
                        List<string> cmfs = new List<string>();
                        cmfs.AddRange(allStateTransactions.Select(x => x.Cmf).Distinct());

                        List<FilterModel> filterModels = new List<FilterModel>()
                        {
                            new FilterModel() { FieldName = "RunOn", RangeFromValue = startDate.Value.ToString(), RangeToValue = endDate.ToString()},
                        };
                        ApiListModel<MiscellaneousChargesDbModel> miscCharges = await _miscellaneousChargesProvider.ReadByStateAndEftModelFSPAsync(state, filterModels, new List<SortModel>(), null, "CBE");
                        cmfs.AddRange(miscCharges.Items.Select(x => x.Cmf).Distinct());
                        var totalEFTAmount = allStateTransactions.Sum(x => Convert.ToDecimal(x.TotalCurrentEft));
                        if (grandTotal != totalEFTAmount)
                        {
                            Console.WriteLine($"Discrepancies in total EFT amount :{totalEFTAmount} and grand total of fee summmary {grandTotal}");
                            result = false;
                            break;
                        }
                        foreach (var cmf in cmfs.Distinct())
                        {
                            var cmfApiModel = await _cmfEftManager.ReadByCmfAsync(cmf);
                            if (string.IsNullOrEmpty(cmfApiModel.Item.AbaNumber) || string.IsNullOrEmpty(cmfApiModel.Item.AccountNumber))
                            {
                                throw new Exception($"Routing or Account number is empty for CMF: {cmf}");
                            }
                            var bpaTotal = allStateTransactions.Where(x => x.Cmf == cmf).Sum(x => Convert.ToDecimal(x.TotalCurrentEft));
                            var miscTotal = miscCharges.Items.Where(x => x.Cmf == cmf).Sum(x => Convert.ToDecimal(x.TotalCurrentEft));
                            var total = bpaTotal + miscTotal;
                            //27 Live Checking Account Debit
                            var entryDetailWriter = batchWriter.CreateDebitEntryDetail(TransactionCode_LiveCheckingAccountDebit, cmfApiModel.Item.AbaNumber, cmfApiModel.Item.AccountNumber, total, "", "");
                            entryDetailWriter.Close();
                        }
                    }
                    batchWriter.Close();
                    _fileWriter.Close();
                }
                else
                {
                    ConsoleWriteErrors(stateRecords);
                    Console.WriteLine("No states found to generate NACHAFile");
                    result = false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                result = false;
            }

            return result;
        }

        private NACHAFileModel GetFileModel()
        {
            var fileModel = new NACHAFileModel();
            fileModel.BatchNumber = 1;
            fileModel.BlockingFactor = 10;
            fileModel.DestinationBankName = "WELLS FARGO";
            fileModel.DestinationBankRoutingNumber = "121000248";
            fileModel.FileIDModifier = 'A';
            fileModel.OriginatingCompanyId = "2223187174";
            fileModel.OriginatingCompanyName = "AVRS";
            fileModel.ReferenceCode = "REF";
            fileModel.Reserved = "";

            return fileModel;
        }

        private void ConsoleWriteErrors(ApiListModel<StateModel> model)
        {
            if (model.HasErrors)
            {
                foreach (var error in model.Errors)
                {
                    Console.WriteLine(error.Message);
                }
            }
        }

        /// <summary>
        /// Used to load the full path name of the exception file for logging purposes.
        /// </summary>
        private void LoadSettings()
        {
            var response = _settings.ReadAsync("COMMON", "Logging", "Exceptions").Result;
            if (response != null && response.Item != null)
            {
                var setting = JsonConvert.DeserializeObject<PathSetting>(response.Item.Settings.AsJsonString());
                _tmpLogPath = setting.Path;
            }
        }
    }
}
