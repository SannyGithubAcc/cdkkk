﻿using System;
using System.Threading.Tasks;

namespace cdk.evr.converge.cbe.common.applications.billing.host
{
    public interface IHostBillingGenerator
    {
        Task<string> GetHostBillingFile(DateTime? startDate, DateTime? endDate);
        bool Debug { get; set; }
    }
}
