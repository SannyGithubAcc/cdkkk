﻿namespace CDK.Service.Common.Http.Clients
{
    public interface IHttpClientConfigurator
    {
        string PrepareUri(string uri, Dictionary<string, string> queryParams);
        void PrepareHeaders(Dictionary<string, string> headers, HttpClient httpClient);
    }
}