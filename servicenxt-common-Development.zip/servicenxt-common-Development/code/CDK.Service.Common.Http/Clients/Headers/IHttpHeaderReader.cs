﻿namespace CDK.Service.Common.Http.Clients.Headers
{
    public interface IHttpHeaderReader
    {
        T GetHeaderValue<T>(string headerName);
    }
}