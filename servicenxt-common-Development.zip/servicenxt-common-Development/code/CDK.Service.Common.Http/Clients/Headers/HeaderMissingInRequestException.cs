﻿namespace CDK.Service.Common.Http.Clients.Headers
{
    public class HeaderMissingInRequestException : Exception
    {
        public HeaderMissingInRequestException(string message) : base(message)
        {
        }

        public HeaderMissingInRequestException() : this("Header is missing in request.")
        {
        }
    }
}