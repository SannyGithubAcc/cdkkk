﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace CDK.Service.Common.Http.Clients.Headers
{
    public class HttpHeaderReader : IHttpHeaderReader
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger _logger;

        public HttpHeaderReader(IHttpContextAccessor httpContextAccessor,
            ILogger logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        public T GetHeaderValue<T>(string headerName)
        {
            var headerValue = _httpContextAccessor.HttpContext?.Request?.Headers[headerName].ToString();

            if (headerValue == null)
            {
                throw new HeaderMissingInRequestException($"Missing {headerValue} header in request");
            }

            try
            {
                return (T)Convert.ChangeType(headerValue, typeof(T));
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Unsupported type {typeof(T).Name} passed for Header Value of Header {headerName}.");
                throw;
            }
        }
    }
}