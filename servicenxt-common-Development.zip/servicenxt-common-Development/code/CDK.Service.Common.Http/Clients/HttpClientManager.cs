﻿using Newtonsoft.Json;

namespace CDK.Service.Common.Http.Clients
{
    public class HttpClientManager : IHttpClientManager
    {
        public async Task<TResult> GetAsync<TResult>(HttpClient httpClient, string getUri, Dictionary<string, string> queryParams = null, Dictionary<string, string> headers = null) where TResult : class
        {
            TResult result;
            var response = await httpClient.GetAsync(getUri);
            try
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                result = JsonConvert.DeserializeObject<TResult>(jsonString)!;
            }
            catch (Exception ex)
            {
                throw new HttpResponseMessageException(response.StatusCode, response, ex);
            }
            return result;
        }
    }
}