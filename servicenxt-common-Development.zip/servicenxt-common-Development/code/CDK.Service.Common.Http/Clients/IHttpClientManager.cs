﻿namespace CDK.Service.Common.Http.Clients
{
    public interface IHttpClientManager
    {
        Task<TResult> GetAsync<TResult>(HttpClient httpClient, string getUri, Dictionary<string, string> queryParams = null, Dictionary<string, string> headers = null) where TResult : class;
    }
}