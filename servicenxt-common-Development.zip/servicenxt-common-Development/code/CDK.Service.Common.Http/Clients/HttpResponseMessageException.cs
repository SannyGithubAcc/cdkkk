﻿using System.Net;

namespace CDK.Service.Common.Http.Clients
{
    internal class HttpResponseMessageException : Exception
    {
        public HttpResponseMessageException(HttpStatusCode statusCode, HttpResponseMessage response, Exception? innerException = null)
            : base(response.Content?.ReadAsStringAsync().Result, innerException)
        {
            StatusCode = statusCode;
            Response = response;
        }
        public HttpStatusCode StatusCode { get; private set; }

        public HttpResponseMessage Response { get; private set; }
    }
}