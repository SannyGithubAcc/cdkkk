﻿using System.Text;
using System.Web;

namespace CDK.Service.Common.Http.Clients
{
    //class for building the Http client
    public class HttpClientConfigurator : IHttpClientConfigurator
    {
        private const string MediaType = "application/json";
        public HttpClientConfigurator()
        {

        }

        public void PrepareHeaders(Dictionary<string, string> headers, HttpClient httpClient)
        {
            httpClient.DefaultRequestHeaders.Clear();

            if (headers != null)
            {
                if (headers.ContainsKey("Accept"))
                {
                    headers["Accept"] = headers["Accept"].Contains("*/*") ? MediaType : headers["Accept"];
                }
                foreach (var header in headers)
                {
                    if (header.Key != "Content-Type")
                    {
                        httpClient.DefaultRequestHeaders.Add(header.Key, header.Value);
                    }
                }
            }
        }

        public string PrepareUri(string uri, Dictionary<string, string> queryParams)
        {
            if (queryParams != null && queryParams.Count > 0)
            {
                var queryBuilder = new StringBuilder();
                queryBuilder.Append(uri);
                if (uri.Contains('?'))
                    queryBuilder.Append('&');
                else
                    queryBuilder.Append('?');
                foreach (var queryParam in queryParams)
                {
                    queryBuilder.AppendFormat("{0}={1}&", HttpUtility.UrlEncode(queryParam.Key), HttpUtility.UrlEncode(queryParam.Value));
                }
                uri = queryBuilder.ToString().TrimEnd('&');
            }
            return uri;
        }
    }
}