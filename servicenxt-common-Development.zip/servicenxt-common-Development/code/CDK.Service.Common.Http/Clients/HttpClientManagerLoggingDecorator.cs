﻿using Microsoft.Extensions.Logging;

namespace CDK.Service.Common.Http.Clients
{
    public class HttpClientManagerLoggingDecorator:IHttpClientManager
    {
        private readonly IHttpClientManager _httpClientManager;
        private readonly ILogger _logger;

        public HttpClientManagerLoggingDecorator(IHttpClientManager httpClientManager,ILogger logger)
        {
            _httpClientManager = httpClientManager;
            _logger = logger;
        }

        public Task<TResult> GetAsync<TResult>(HttpClient httpClient, string getUri, Dictionary<string, string> queryParams = null, Dictionary<string, string> headers = null) where TResult : class
        {
            _logger.LogInformation($"{httpClient.BaseAddress}.{getUri}");
            return _httpClientManager.GetAsync<TResult>(httpClient, getUri, queryParams, headers);
        }
    }
}