﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Logging;
using Polly;

namespace CDK.Service.Common.Http.Polly;

[ExcludeFromCodeCoverage]
// Excluded because Policy Context Configuration
public class LoggerProviderMessageHandler<T> : DelegatingHandler
{
    private readonly ILogger<T> _logger;
    private readonly string _typeName;

    public LoggerProviderMessageHandler(ILogger<T> logger)
    {
        _logger = logger;
        _typeName = typeof(T).Name;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var operationKey = $"SendAsync:{_typeName}:{request.RequestUri?.OriginalString}:{DateTime.UtcNow}:{Guid.NewGuid()}";
        var context = new Context(operationKey)
        {
            ["logger"] = _logger
        };
        request.SetPolicyExecutionContext(context);

        return await base.SendAsync(request, cancellationToken);
    }
}