﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Registry;

namespace CDK.Service.Common.Http.Polly;

[ExcludeFromCodeCoverage]
// Excluded because Dependency Injection Configuration Extension
public static class PollyExtensions
{
    public static IHttpClientBuilder AddPolicyLoggerProvider<T>(this IHttpClientBuilder builder)
    {
        if (builder.Services.Any(serviceDescriptor =>
                serviceDescriptor.ServiceType == typeof(LoggerProviderMessageHandler<T>)))
        {
            return builder;
        }
        
        builder.Services.AddSingleton<LoggerProviderMessageHandler<T>>();
        builder.AddHttpMessageHandler<LoggerProviderMessageHandler<T>>();

        return builder;
    }

    public static IServiceCollection AddDefaultPolicyRegistryAndWithDefaultPolicies(this IServiceCollection services, IConfiguration configuration, out IPolicyRegistry<string> registry)
    {
        registry = services.AddPolicyRegistry();

        var httpResponsePolicy = Policy<HttpResponseMessage>
            .HandleResult(result => !result.IsSuccessStatusCode)
            .Retry(configuration.GetValue<int>("Polly:DefaultHttpResponsePolicy:RetryAttempts"),
                onRetry: (exception, retryCount, context) =>
            {
                if (!context.TryGetValue("logger", out var contextLogger)) return;
                if (contextLogger is not ILogger logger) return;
                logger.LogError(
                    $"Retry {retryCount} of {context.PolicyKey} at {context.OperationKey}, due to: {exception}.");
            });
        registry.Add("DefaultHttpResponsePolicy", httpResponsePolicy);

        return services;
    }
}