﻿using System.Diagnostics.CodeAnalysis;
using System.Security.Claims;
using CDK.Service.Common.Auth.User.Token;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;

namespace CDK.Service.Common.Auth.User;

[ExcludeFromCodeCoverage]
// Excluded because Dependency Injection Configuration Extension
public static class UserAuthenticationServicesExtension
{
    public static IServiceCollection AddUserAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddCustomJwtBearer(configuration, options =>
        {
            options.RequireHttpsMetadata = true; 
            options.ClaimsIssuer = configuration.GetValue<string>("Security:ClaimsIssuer");
            options.Audience = configuration.GetValue<string>("Security:Audience");
            options.TokenValidationParameters = new TokenValidationParameters
            {
                // CustomJwtBearerHandler Overrides IssuerSigningKeys
                RequireAudience = true,
                RequireExpirationTime = true,
                RequireSignedTokens = true,
                ValidateAudience = true,
                ValidateIssuer = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidAudience = configuration.GetValue<string>("Security:Audience"),
                ValidIssuer = configuration.GetValue<string>("Security:ClaimsIssuer"),
                ClockSkew = TimeSpan.FromMinutes(5),
                NameClaimType = ClaimTypes.Name,
                RoleClaimType = ClaimTypes.Role
            };
            // CustomJwtBearerHandler Overrides Events: OnValidated, OnMessageReceived, OnAuthenticationFailed, OnForbidden
        });
        return services;
    }
}