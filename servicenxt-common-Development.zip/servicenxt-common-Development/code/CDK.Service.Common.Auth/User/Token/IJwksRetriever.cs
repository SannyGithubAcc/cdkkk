﻿using Microsoft.IdentityModel.Tokens;

namespace CDK.Service.Common.Auth.User.Token
{
    public interface IJwksRetriever
    {
        Task<IEnumerable<SecurityKey>> GetSigningKeys();
    }
}