﻿using System.Security.Claims;
using System.Web;
using CDK.Service.Common.Auth.User.Token.Encryption;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;

namespace CDK.Service.Common.Auth.User.Token;

public class CustomTokenValidator : ICustomTokenValidator
{
    private readonly IConfiguration _configuration;
    private readonly ITokenDecryptionProvider _tokenDecryptionProvider;
    private readonly ITokenHttpHelper _tokenHttpHelper;

    public CustomTokenValidator(IConfiguration configuration,
        ITokenDecryptionProvider tokenDecryptionProvider,
        ITokenHttpHelper tokenHttpHelper)
    {
        _configuration = configuration;
        _tokenDecryptionProvider = tokenDecryptionProvider;
        _tokenHttpHelper = tokenHttpHelper;
    }

    public Task ValidateToken(TokenValidatedContext context)
    {
        var cookieString = context.Request.Cookies["sfc"];
        var claims = context.Principal?.Claims?.ToArray();
        if (cookieString != null && claims != null)
        {
            var key = _configuration.GetValue<string>("Security:CookieEncryptionKey");
            var iv = _configuration.GetValue<string>("Security:CookieEncryptionValue");
            var decryptedCookieString = DecryptHttpEncodedValue(cookieString, key, iv);
            var codeFromCookie = _tokenHttpHelper.ReadFromCookieString(decryptedCookieString, "sfcode");
            var uidFromCookie = _tokenHttpHelper.ReadFromCookieString(decryptedCookieString, "sfuid");
            var cidFromRouteValues = Convert.ToString(context.HttpContext.Request.RouteValues["companyId"]);
            var codeFromToken = Convert.ToString(claims.FirstOrDefault(x => x.Type == "code")?.Value);
            Guid.TryParse(claims.FirstOrDefault(claim => claim.Type == ClaimTypes.NameIdentifier)?.Value,
                out var userIdGuidFromToken);
            var userIdFromToken = userIdGuidFromToken.ToString();
            var cidFromToken = Convert.ToString(claims.FirstOrDefault(x => x.Type == "cid")?.Value);

            if (codeFromCookie == codeFromToken
                && uidFromCookie == userIdFromToken
                && cidFromRouteValues == cidFromToken)
            {
                return Task.FromResult(true);
            }
        }

        context.Fail(new Exception("Unauthorized"));
        return Task.CompletedTask;
    }

    private string DecryptHttpEncodedValue(string encryptedValue, string key, string iv)
    {
        var urlDecodedBase64Value = HttpUtility.UrlDecode(encryptedValue);
        var base64Value = urlDecodedBase64Value // For backwards-compatibility
            .Replace('@', '+') // For backwards-compatibility
            .Replace(".", "") // For backwards-compatibility
            .Replace('-', '+') // For backwards-compatibility
            .Replace('_', '/'); // For backwards-compatibility
        base64Value = AddPaddingForBase64(base64Value); // For backwards-compatibility
        var value = _tokenDecryptionProvider.DecryptBase64Value(base64Value, key, iv);

        return value;
    }

    private string AddPaddingForBase64(string base64Value)
    {
        var length = base64Value.Length;
        var paddingToAdd = 4 - length + (length / 4) * 4;
        if (paddingToAdd == 4) paddingToAdd = 0;
        return $"{base64Value}{new string('=', paddingToAdd)}";
    }
}