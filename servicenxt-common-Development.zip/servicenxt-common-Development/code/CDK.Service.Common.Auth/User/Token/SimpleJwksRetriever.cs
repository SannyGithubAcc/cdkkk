﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace CDK.Service.Common.Auth.User.Token;

public class SimpleJwksRetriever : IJwksRetriever
{
    private readonly IDocumentRetriever _documentRetriever;
    private readonly IConfiguration _configuration;

    public SimpleJwksRetriever(IDocumentRetriever documentRetriever,
        IConfiguration configuration)
    {
        _documentRetriever = documentRetriever;
        _configuration = configuration;
    }

    public async Task<IEnumerable<SecurityKey>> GetSigningKeys()
    {
        var jwksUri = _configuration.GetValue<string>("Security:JwksUri");
        var response = await _documentRetriever.GetDocumentAsync(jwksUri, CancellationToken.None);
        var jwks = JsonConvert.DeserializeObject<JsonWebKeySet>(response);
        var signingKeys = jwks?.GetSigningKeys();
        return signingKeys;
    }
}