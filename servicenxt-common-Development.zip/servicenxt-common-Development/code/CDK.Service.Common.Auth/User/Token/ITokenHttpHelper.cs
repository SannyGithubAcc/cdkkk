﻿namespace CDK.Service.Common.Auth.User.Token;

public interface ITokenHttpHelper
{
    string ReadFromCookieString(string cookieString, string key);
}