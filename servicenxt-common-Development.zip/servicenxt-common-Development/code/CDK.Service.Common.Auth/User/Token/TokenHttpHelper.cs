﻿namespace CDK.Service.Common.Auth.User.Token;

public class TokenHttpHelper : ITokenHttpHelper
{
    public string ReadFromCookieString(string cookieString, string key)
    {
        var splitChar = new char[] { '&' };
        var equalChar = new char[] { '=' };

        // Split query string to components
        foreach (var keyValueString in cookieString.Split(splitChar))
        {
            // split each component to key and value
            var keyValue = keyValueString.Split(equalChar, 2);

            var itemKey = keyValue[0];
            var itemValue = (keyValue.Length > 1) ? keyValue[1] : string.Empty;

            // Add to the hashtable
            if (itemKey == key)
            {
                return itemValue;
            }
        }

        return null;
    }
}