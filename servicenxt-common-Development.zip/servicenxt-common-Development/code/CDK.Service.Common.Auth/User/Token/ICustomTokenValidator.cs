﻿using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace CDK.Service.Common.Auth.User.Token;

public interface ICustomTokenValidator
{
    Task ValidateToken(TokenValidatedContext context);
}