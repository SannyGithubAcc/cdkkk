﻿namespace CDK.Service.Common.Auth.User.Token.Encryption;

public interface ITokenDecryptionProvider
{
    string DecryptBase64Value(string base64Value, string key, string iv);
    string DecryptValue(byte[] value, string key, string iv);
}