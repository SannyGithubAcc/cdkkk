﻿using System.Security.Cryptography;
using System.Text;

namespace CDK.Service.Common.Auth.User.Token.Encryption;

public class TokenDecryptionProvider : ITokenDecryptionProvider
{
    public string DecryptBase64Value(string base64Value, string key, string iv)
    {
        var encryptedValue = Convert.FromBase64String(base64Value);
        var value = DecryptValue(encryptedValue, key, iv);

        return value;
    }

    public string DecryptValue(byte[] value, string key, string iv)
    {
        var csp = new RC2CryptoServiceProvider();
        var decryptor = csp.CreateDecryptor(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(iv));

        // Encrypt the data as an array of encrypted bytes in memory.
        using (var msDecrypt = new MemoryStream(value))
        {
            using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
            {
                var sb = new StringBuilder();
                var b = 0;

                do
                {
                    b = csDecrypt.ReadByte();

                    if (b != -1)
                    {
                        sb.Append((char)b);
                    }

                }
                while (b != -1);

                var decrypted = sb.ToString();

                return decrypted;
            }
        }
    }
}