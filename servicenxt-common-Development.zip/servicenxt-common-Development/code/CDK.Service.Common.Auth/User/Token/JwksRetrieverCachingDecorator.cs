﻿using LazyCache;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace CDK.Service.Common.Auth.User.Token;

public class JwksRetrieverCachingDecorator : IJwksRetriever
{
    private readonly IJwksRetriever _jwksRetriever;
    private readonly IAppCache _appCache;
    private readonly IConfiguration _configuration;

    // Uses LazyCache as .Net 6 Memory Cache is not Thread Safe
    // See https://blog.novanet.no/asp-net-core-memory-cache-is-get-or-create-thread-safe/
    public JwksRetrieverCachingDecorator(IJwksRetriever jwksRetriever,
        IAppCache appCache,
        IConfiguration configuration)
    {
        _jwksRetriever = jwksRetriever;
        _appCache = appCache;
        _configuration = configuration;
    }

    public async Task<IEnumerable<SecurityKey>> GetSigningKeys()
    {
        var cachedKeys = await _appCache.GetOrAddAsync(
            "jwks_keys",
            cacheEntry => _jwksRetriever.GetSigningKeys(),
            new MemoryCacheEntryOptions()
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(_configuration.GetValue<int>("Security:SigningKeyCacheDurationInMinutes"))
            });

        return cachedKeys;
    }
}