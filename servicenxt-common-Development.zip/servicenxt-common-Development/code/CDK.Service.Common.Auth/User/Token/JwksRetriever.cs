﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace CDK.Service.Common.Auth.User.Token
{
    [ExcludeFromCodeCoverage]
    // TODO: Deprecated, Replace with Newer Implementation once tested
    // Excluded from Code Coverage as this is previous implementation brought in from prior project as fallback
    public class JwksRetriever : IJwksRetriever
    {
        private TimeSpan _refreshInterval = new TimeSpan(1, 0, 0);
        private DateTimeOffset syncAfter = DateTimeOffset.MinValue;
        private IList<SecurityKey> _signingKeys;
        private readonly SemaphoreSlim refreshLock;
        private readonly IDocumentRetriever documentRetriever;
        private readonly IConfiguration configuration;
        private readonly ILogger<JwksRetriever> _logger;

        public JwksRetriever(IDocumentRetriever documentRetriever, IConfiguration configuration, ILogger<JwksRetriever> logger)
        {
            refreshLock = new SemaphoreSlim(1);
            this.documentRetriever = documentRetriever ?? throw new ArgumentNullException(nameof(documentRetriever));
            this.configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }
        public async Task<IEnumerable<SecurityKey>> GetSigningKeys()
        {
            var jwksUri = configuration["Security:JwksUri"];
            var now = DateTimeOffset.UtcNow;
            if (_signingKeys != null && syncAfter > now)
                return _signingKeys;

            if (string.IsNullOrEmpty(jwksUri))
                throw new ArgumentNullException("JwksUri");

            refreshLock.Wait();
            try
            {
                if (syncAfter < now)
                {
                    try
                    {
                        var response = await documentRetriever.GetDocumentAsync(jwksUri, CancellationToken.None);
                        var jwks = JsonConvert.DeserializeObject<JsonWebKeySet>(response);
                        _signingKeys = jwks.GetSigningKeys();
                        syncAfter = DateTimeOffset.UtcNow.Add(_refreshInterval);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, ex.Message);
                    }
                }
                if (_signingKeys != null)
                    return _signingKeys;
                return null;
            }
            finally
            {
                refreshLock.Release();
            }
        }
    }
}