﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CDK.Service.Common.Auth.User.Token;

[ExcludeFromCodeCoverage]
// Excluded because JwtBearer Option Configuration
public class CustomJwtBearerHandler : JwtBearerHandler
{
    private readonly IJwksRetriever _jwksRetriever;
    private readonly ICustomTokenValidator _customTokenValidator;

    public CustomJwtBearerHandler(IOptionsMonitor<JwtBearerOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        ISystemClock clock,
        IJwksRetriever jwksRetriever,
        ICustomTokenValidator customTokenValidator) : base(options, logger, encoder, clock)
    {
        _jwksRetriever = jwksRetriever;
        _customTokenValidator = customTokenValidator;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        this.Options.TokenValidationParameters.IssuerSigningKeys = await _jwksRetriever.GetSigningKeys();
        this.Options.Events.OnTokenValidated = (context) => _customTokenValidator.ValidateToken(context);
        this.Options.Events.OnMessageReceived = (context) => Task.FromResult(true);
        this.Options.Events.OnAuthenticationFailed = (context) => Task.FromResult(true);
        this.Options.Events.OnForbidden = (context) => Task.FromResult(true);
        return await base.HandleAuthenticateAsync();
    }
}