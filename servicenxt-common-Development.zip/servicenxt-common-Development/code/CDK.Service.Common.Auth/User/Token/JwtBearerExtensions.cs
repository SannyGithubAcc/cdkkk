﻿using System.Diagnostics.CodeAnalysis;
using CDK.Service.Common.Auth.User.Token.Encryption;
using CDK.Service.Common.Http.Polly;
using LazyCache;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Polly;

namespace CDK.Service.Common.Auth.User.Token;

[ExcludeFromCodeCoverage]
// Excluded because Dependency Injection Configuration Extension
public static class JwtBearerExtensions
{
    public static AuthenticationBuilder AddCustomJwtBearer(this AuthenticationBuilder builder, IConfiguration configuration, Action<JwtBearerOptions> configureOptions)
    {
        builder.Services.AddLazyCache();
        builder.Services.AddSingleton<ICustomTokenValidator, CustomTokenValidator>();
        builder.Services.AddSingleton<ITokenDecryptionProvider, TokenDecryptionProvider>();
        builder.Services.AddSingleton<ITokenHttpHelper, TokenHttpHelper>();
        // Depends on HttpClient so must come before HttpClient Configuration, See https://github.com/dotnet/runtime/issues/53944
        builder.Services.AddSingleton<IDocumentRetriever, HttpDocumentRetriever>();
        builder.Services.AddSingleton<SimpleJwksRetriever>();
        // Decorator Pattern in .Net 6 DI
        builder.Services.AddSingleton<IJwksRetriever, JwksRetrieverCachingDecorator>(provider => new JwksRetrieverCachingDecorator(
            provider.GetService<SimpleJwksRetriever>(),
            provider.GetService<IAppCache>(),
            provider.GetService<IConfiguration>()));

        builder.Services.AddDefaultPolicyRegistryAndWithDefaultPolicies(configuration, out var registry);

        // Depended on by IDocumentRetriever so must come after IDocumentRetriever Configuration, See https://github.com/dotnet/runtime/issues/53944
        builder.Services.AddHttpClient<IDocumentRetriever>(client => {})
            // Adding Policy Logger Provider must come before Policy Handler
            .AddPolicyLoggerProvider<IDocumentRetriever>()
            .AddPolicyHandler(registry.Get<IAsyncPolicy<HttpResponseMessage>>("DefaultHttpResponsePolicy"));

        builder.Services.TryAddEnumerable(ServiceDescriptor.Singleton<IPostConfigureOptions<JwtBearerOptions>, JwtBearerPostConfigureOptions>());
        builder.AddScheme<JwtBearerOptions, CustomJwtBearerHandler>(JwtBearerDefaults.AuthenticationScheme, displayName: null, configureOptions);

        return builder;
    }
}