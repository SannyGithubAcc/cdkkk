﻿using CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts;
using LazyCache;
using Microsoft.Extensions.Caching.Memory;

namespace CDK.Service.Common.Auth.Service.Legacy.Iam;

public class CacheProviderExpirationFromCacheEntryDecorator : ICacheProvider
{
    private readonly ICacheProvider _cacheProvider;

    public CacheProviderExpirationFromCacheEntryDecorator(ICacheProvider cacheProvider)
    {
        _cacheProvider = cacheProvider;
    }

    public void Dispose()
    {
        _cacheProvider.Dispose();
    }

    public void Set(string key, object item, MemoryCacheEntryOptions policy)
    {
        _cacheProvider.Set(key, item, policy);
    }

    public object Get(string key)
    {
        return _cacheProvider.Get(key);
    }

    public object GetOrCreate<T>(string key, Func<ICacheEntry, T> func)
    {
        return _cacheProvider.GetOrCreate(key, func);
    }

    public object GetOrCreate<T>(string key, MemoryCacheEntryOptions policy, Func<ICacheEntry, T> func)
    {
        var obj = _cacheProvider.GetOrCreate(key, policy, func);

        if (obj is not AuthorizationToken auth) return obj;
        // TODO Refactor this to an Injected Factory for Processing Expiration
        policy.AbsoluteExpirationRelativeToNow = null;
        policy.AbsoluteExpiration = auth.AuthTokenExpiration;
        Set(key, obj, policy);
        return obj;
    }

    public void Remove(string key)
    {
        _cacheProvider.Remove(key);
    }

    public Task<T> GetOrCreateAsync<T>(string key, Func<ICacheEntry, Task<T>> func)
    {
        return _cacheProvider.GetOrCreateAsync(key, func);
    }

    public bool TryGetValue<T>(object key, out T value)
    {
        return _cacheProvider.TryGetValue(key, out value);
    }
}