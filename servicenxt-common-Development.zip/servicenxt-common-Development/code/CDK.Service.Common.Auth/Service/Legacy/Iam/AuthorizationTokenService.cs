﻿namespace CDK.Service.Common.Auth.Service.Legacy.Iam
{
    public class AuthorizationTokenService : IAuthorizationTokenService
    {
        private readonly IAuthorizationTokenClient _authorizationTokenClient;

        public AuthorizationTokenService(IAuthorizationTokenClient authorizationTokenClient)
        {
            _authorizationTokenClient = authorizationTokenClient;
        }

        public async Task<string> GetAuthTokenAsync()
        {
            var cachedKeys = await _authorizationTokenClient.GetAuthTokenAsync();

            return cachedKeys.AuthToken;

        }
    }
}