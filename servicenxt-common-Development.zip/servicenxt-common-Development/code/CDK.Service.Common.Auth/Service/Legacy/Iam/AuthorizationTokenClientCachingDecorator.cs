﻿using CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts;
using LazyCache;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;

namespace CDK.Service.Common.Auth.Service.Legacy.Iam;

public class AuthorizationTokenClientCachingDecorator : IAuthorizationTokenClient
{
    private readonly IAuthorizationTokenClient _authorizationTokenClient;
    private readonly IAppCache _appCache;
    private readonly IConfiguration _configuration;

    // Uses LazyCache as .Net 6 Memory Cache is not Thread Safe
    // See https://blog.novanet.no/asp-net-core-memory-cache-is-get-or-create-thread-safe/
    public AuthorizationTokenClientCachingDecorator(IAuthorizationTokenClient authorizationTokenClient,
        IAppCache appCache,
        IConfiguration configuration)
    {
        _authorizationTokenClient = authorizationTokenClient;
        _appCache = appCache;
        _configuration = configuration;
    }

    public async Task<AuthorizationToken> GetAuthTokenAsync()
    {
        var cachedKeys = await _appCache.GetOrAddAsync(
            "authorization_token",
            cacheEntry => _authorizationTokenClient.GetAuthTokenAsync(),
            new MemoryCacheEntryOptions()
            {
                // Passing Options Creates a Policy which our Decorator uses to set Expiration from the Response
            });

        return cachedKeys;
    }
}