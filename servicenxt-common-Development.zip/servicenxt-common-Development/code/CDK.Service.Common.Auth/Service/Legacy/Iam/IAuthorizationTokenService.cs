﻿namespace CDK.Service.Common.Auth.Service.Legacy.Iam
{
    public interface IAuthorizationTokenService
    {
        Task<string> GetAuthTokenAsync();
    }
}
