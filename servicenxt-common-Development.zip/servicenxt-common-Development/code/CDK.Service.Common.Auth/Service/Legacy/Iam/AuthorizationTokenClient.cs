﻿using CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts;
using CDK.Service.Common.Http.Clients;
using Microsoft.Extensions.Configuration;

namespace CDK.Service.Common.Auth.Service.Legacy.Iam;
    public class AuthorizationTokenClient : IAuthorizationTokenClient
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpClientConfigurator _httpClientConfigurator;
        private readonly IHttpClientManager _httpClientManager;
        private readonly IConfiguration _configuration;

        public AuthorizationTokenClient(HttpClient httpClient,
            IHttpClientConfigurator httpClientConfigurator,
            IHttpClientManager httpClientManager,
            IConfiguration configuration)
        {
            _httpClient = httpClient;
            _httpClientConfigurator = httpClientConfigurator;
            _httpClientManager = httpClientManager;
            _configuration = configuration;
        }

        public async Task<AuthorizationToken> GetAuthTokenAsync()
        {
            var serviceUserId = _configuration.GetValue<string>("Security:IamAuthorizationTokenServiceUserId")
                                ?? throw new KeyNotFoundException("IamAuthorizationTokenServiceUserId");
            var uri = _httpClientConfigurator.PrepareUri(serviceUserId, new Dictionary<string, string>());
            return await _httpClientManager.GetAsync<AuthorizationToken>(_httpClient, uri);
        }
    }