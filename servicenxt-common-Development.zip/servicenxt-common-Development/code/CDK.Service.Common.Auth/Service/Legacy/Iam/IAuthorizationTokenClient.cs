﻿using CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts;

namespace CDK.Service.Common.Auth.Service.Legacy.Iam
{
    public interface IAuthorizationTokenClient
    { 
        Task<AuthorizationToken> GetAuthTokenAsync();
    }
}
