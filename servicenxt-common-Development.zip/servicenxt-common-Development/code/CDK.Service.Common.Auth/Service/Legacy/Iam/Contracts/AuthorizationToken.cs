﻿namespace CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts
{
    public class AuthorizationToken
    {
        public string AuthToken { get; set; }
        public DateTime AuthTokenExpiration { get; set; }
    }
}