﻿using CDK.Service.Common.Auth.Service.Legacy.Iam;
using CDK.Service.Common.Http.Polly;
using LazyCache;
using LazyCache.Providers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;

namespace CDK.Service.Common.Auth.Service.Legacy;

public static class LegacyAuthenticationServicesExtensions
{
    public static IServiceCollection AddLegacyAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddLazyCache();
        // Decorator Pattern in .Net 6 DI
        services.AddSingleton<MemoryCacheProvider>();
        services.AddSingleton<ICacheProvider, CacheProviderExpirationFromCacheEntryDecorator>(provider => new CacheProviderExpirationFromCacheEntryDecorator(
            provider.GetService<MemoryCacheProvider>()));

        // Decorator Pattern in .Net 6 DI
        services.AddSingleton<AuthorizationTokenClient>();
        services.AddSingleton<IAuthorizationTokenClient, AuthorizationTokenClientCachingDecorator>(provider => new AuthorizationTokenClientCachingDecorator(
            provider.GetService<AuthorizationTokenClient>(),
            provider.GetService<IAppCache>(),
            provider.GetService<IConfiguration>()));
        services.AddSingleton<IAuthorizationTokenService, AuthorizationTokenService>();

        services.AddDefaultPolicyRegistryAndWithDefaultPolicies(configuration, out var registry);

        // Depended on by IDocumentRetriever so must come after IDocumentRetriever Configuration, See https://github.com/dotnet/runtime/issues/53944
        services.AddHttpClient<AuthorizationTokenClient>(client =>
            {
                client.BaseAddress = new Uri(configuration.GetValue<string>("Security:IamAuthorizationTokenServiceUri"));
            })
            // Adding Policy Logger Provider must come before Policy Handler
            .AddPolicyLoggerProvider<AuthorizationTokenClient>()
            .AddPolicyHandler(registry.Get<IAsyncPolicy<HttpResponseMessage>>("DefaultHttpResponsePolicy"));

        return services;
    }
}