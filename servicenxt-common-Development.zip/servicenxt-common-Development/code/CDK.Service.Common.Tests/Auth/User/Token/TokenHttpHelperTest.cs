﻿using CDK.Service.Common.Auth.User.Token;

namespace CDK.Service.Common.Tests.Auth.User.Token;

public class TokenHttpHelperTest
{
    // Arrange
    private readonly TokenHttpHelper _classUnderTest;
    private readonly string _validKey;
    private readonly string _validValue;
    private readonly string _invalidKey;
    private readonly string _validCookieString;

    public TokenHttpHelperTest()
    {
        _classUnderTest = new TokenHttpHelper();
        _validKey = "foo";
        _validValue = "bar";
        _invalidKey = "doo";
        _validCookieString = $"{_validKey}={_validValue}";
    }

    [Fact]
    public void ReadFromCookieString_ReturnsValidValueFromValidCookieStringAndValidKey()
    {
        // Arrange

        // Act
        var testResult = _classUnderTest.ReadFromCookieString(_validCookieString, _validKey);

        // Assert
        Assert.Equal(_validValue, testResult);
    }

    [Fact]
    public void ReadFromCookieString_ReturnsNullValueFromValidCookieStringAndInvalidKey()
    {
        // Arrange

        // Act
        var testResult = _classUnderTest.ReadFromCookieString(_validCookieString, _invalidKey);

        // Assert
        Assert.Null(testResult);
    }

    [Fact]
    public void ReadFromCookieString_ThrowsNullReferenceExceptionFromNullCookieStringAndValidKey()
    {
        // Arrange

        // Act
        // Assert
        var exception = Assert.Throws<NullReferenceException>(() => _classUnderTest.ReadFromCookieString(null, _validKey));
    }
}