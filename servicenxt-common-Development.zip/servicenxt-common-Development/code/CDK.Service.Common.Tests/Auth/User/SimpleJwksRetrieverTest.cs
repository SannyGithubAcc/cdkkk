﻿using CDK.Service.Common.Auth.User.Token;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Tokens;
using Moq;
using Newtonsoft.Json;

namespace CDK.Service.Common.Tests.Auth.User;

public class SimpleJwksRetrieverTest
{
    private readonly Mock<IDocumentRetriever> _documentRetrieverMock;
    private readonly Mock<IConfiguration> _configurationMock;
    private readonly Mock<IConfigurationSection> _configurationSectionMock;
    private readonly SimpleJwksRetriever _classUnderTest;
    private readonly string _validJwksUri;
    private readonly JsonWebKeySet _validJsonWebKeySet;
    private readonly string _validJsonWebKeySetString;

    public SimpleJwksRetrieverTest()
    {
        _documentRetrieverMock = new Mock<IDocumentRetriever>();
        _configurationMock = new Mock<IConfiguration>();
        _configurationSectionMock = new Mock<IConfigurationSection>();
        _classUnderTest = new SimpleJwksRetriever(_documentRetrieverMock.Object, _configurationMock.Object);
        _validJwksUri = "http://localhost";
        _validJsonWebKeySet = new JsonWebKeySet();
        _validJsonWebKeySetString = JsonConvert.SerializeObject(_validJsonWebKeySet);
    }

    [Fact]
    public void GetSigningKeys_ReturnsValidKeysFromSuccessfulDocumentRetrieverCall()
    {
        // Arrange
        _configurationSectionMock.SetupGet(configurationSection => configurationSection.Value).Returns(_validJwksUri);

        _configurationMock.Setup(configuration => configuration.GetSection("Security:JwksUri")).Returns(_configurationSectionMock.Object);

        _documentRetrieverMock.Setup(documentRetriever => documentRetriever.GetDocumentAsync(_validJwksUri, CancellationToken.None)).ReturnsAsync(_validJsonWebKeySetString);

        // Act
        var testResult = _classUnderTest.GetSigningKeys().Result;

        // Assert
        Assert.NotNull(testResult);
        Assert.Equal(0, testResult.Count());
    }

    [Fact]
    public void GetSigningKeys_ThrowsArgumentNullExceptionFromUnsuccessfulDocumentRetrieverCall()
    {
        // Arrange
        _configurationSectionMock.SetupGet(configurationSection => configurationSection.Value).Returns(_validJwksUri);
        _configurationMock.Setup(configuration => configuration.GetSection("Security:JwksUri")).Returns(_configurationSectionMock.Object);

        _documentRetrieverMock.Setup(documentRetriever => documentRetriever.GetDocumentAsync(_validJwksUri, CancellationToken.None)).ReturnsAsync(null as string);

        // Act
        // Assert
        var exception = Assert.ThrowsAsync<ArgumentNullException>(() => _classUnderTest.GetSigningKeys());
    }
}