﻿using CDK.Service.Common.Auth.Service.Legacy.Iam;
using CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts;
using CDK.Service.Common.Http.Clients;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDK.Service.Common.Tests.Auth.Service.Legacy.Iam;

public class AuthorizationTokenServiceTest
{
    private readonly AuthorizationTokenService _authorizationTokenService;
    private readonly Mock<IAuthorizationTokenClient> _authorizationTokenClient;

    public AuthorizationTokenServiceTest()
    {
        var authorizationToken = new AuthorizationToken
        {
            AuthToken = "NjdlNTdjZjItMzU1OS00NjAwLThkNTItOWEzMmQwOGJkYzY5",
            AuthTokenExpiration = DateTime.Now.AddMinutes(10)
        };
        _authorizationTokenClient = new Mock<IAuthorizationTokenClient>();
        _authorizationTokenClient.Setup(mock => mock.GetAuthTokenAsync()).Returns(Task.FromResult(authorizationToken));
        _authorizationTokenService = new AuthorizationTokenService(_authorizationTokenClient.Object);
    }

    [Fact]
    public async Task GetAuthTokenAsync_Success()
    {
        var testResult = await _authorizationTokenService.GetAuthTokenAsync();
        Assert.NotNull(testResult);
    }
}

