﻿
using CDK.Service.Common.Http.Clients;
using Microsoft.Extensions.Configuration;
using CDK.Service.Common.Auth.Service.Legacy.Iam;
using CDK.Service.Common.Auth.Service.Legacy.Iam.Contracts;
using Moq;
namespace CDK.Service.Common.Tests.Auth.Service.Legacy.Iam;

public class AuthorizationTokenClientTest
{
    private readonly AuthorizationTokenClient _authorizationTokenClient;
    private readonly string _validIamAuthorizationTokenServiceUserId;
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<IConfigurationSection> _mockConfigurationSection;
    private readonly Mock<HttpClient> _mockHttpClient;
    private readonly Mock<IHttpClientConfigurator> _mockHttpClientConfigurator;
    private readonly Mock<IHttpClientManager> _mockHttpClientManager;

    public AuthorizationTokenClientTest()
    {
        _validIamAuthorizationTokenServiceUserId = "ServiceAdvisorInspect";
        _mockConfiguration = new Mock<IConfiguration>();
        _mockConfigurationSection = new Mock<IConfigurationSection>();
        _mockHttpClient = new Mock<HttpClient>();
        _mockHttpClientConfigurator = new Mock<IHttpClientConfigurator>();
        _mockHttpClientManager = new Mock<IHttpClientManager>();

        _authorizationTokenClient = new AuthorizationTokenClient(_mockHttpClient.Object, _mockHttpClientConfigurator.Object,
            _mockHttpClientManager.Object, _mockConfiguration.Object);

        _mockConfigurationSection.SetupGet(configurationSection => configurationSection.Value).Returns(_validIamAuthorizationTokenServiceUserId);
        _mockConfiguration.Setup(configuration => configuration.GetSection("Security:IamAuthorizationTokenServiceUserId")).Returns(_mockConfigurationSection.Object);
        _mockHttpClientConfigurator.Setup(mock => mock.PrepareUri(_validIamAuthorizationTokenServiceUserId, new Dictionary<string, string>()))
                            .Returns(_validIamAuthorizationTokenServiceUserId);
    }

    [Fact]
    public async Task GetAuthTokenAsync_ShouldReturn_Token()
    {
        var authorizationToken = new AuthorizationToken
        {
            AuthToken = "NjdlNTdjZjItMzU1OS00NjAwLThkNTItOWEzMmQwOGJkYzY5",
            AuthTokenExpiration = DateTime.Now.AddMinutes(10)
        };
        _mockHttpClientManager.Setup(mock => mock.GetAsync<AuthorizationToken>(_mockHttpClient.Object,
                                                _validIamAuthorizationTokenServiceUserId, null, null)).ReturnsAsync(authorizationToken);

        var testResult = await _authorizationTokenClient.GetAuthTokenAsync();

        Assert.NotNull(testResult);
        Assert.Equal(authorizationToken.AuthToken, testResult.AuthToken);
        _mockHttpClientConfigurator.Verify(x => x.PrepareUri(_validIamAuthorizationTokenServiceUserId, new Dictionary<string, string>()));
        _mockHttpClientManager.Verify(mock => mock.GetAsync<AuthorizationToken>(_mockHttpClient.Object,
                                                        _validIamAuthorizationTokenServiceUserId, null, null));
    }

    [Fact]
    public async Task GetAuthTokenAsync_ShouldThrowExceptionIfClientReturnException()
    {
        _mockHttpClientManager.Setup(mock => mock.GetAsync<AuthorizationToken>(_mockHttpClient.Object,
                                                _validIamAuthorizationTokenServiceUserId, null, null)).ThrowsAsync(new InvalidOperationException());

        var ex = Assert.ThrowsAsync<InvalidOperationException>( async () => await _authorizationTokenClient.GetAuthTokenAsync());
        _mockHttpClientConfigurator.Verify(x => x.PrepareUri(_validIamAuthorizationTokenServiceUserId, new Dictionary<string, string>()));
        _mockHttpClientManager.Verify(mock => mock.GetAsync<AuthorizationToken>(_mockHttpClient.Object,
                                                        _validIamAuthorizationTokenServiceUserId, null, null));
    }
}

