# \<Add here the Application Name>

## Description

Provide here minimal project description and link to the docs and external links.

## Getting Started

Explain here how to use the application.

## How to Contribute to the Application

See [CONTRIBUTING.md](CONTRIBUTING.md).

## App Registry Meta Data

Add here a link to App Registry
<!--
Example for "app-serviceflex-ui":

Link: [app-serviceflex-ui](https://athena-app-cmdb.athena.connectcdk.com/assets/app-serviceflex-ui)

replace app-serviceflex-ui by your own application id
if not relevant, please remove this section.
-->

## Source Code Integrity

All Source Codes within this github enterprise account are CDK’s Intellectual Property. Please NEVER upload any of these source codes to public code sharing site. More details [here](https://confluence.cdk.com/display/PSRC/Source+Code+Management).
