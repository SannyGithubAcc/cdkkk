# Okta API Token Expiration Watcher

## Introduction

A service to periodically check for expiring okta api tokens every week and notify dev teams.
## Getting Started

```
npm install
```

### Testing
```
npm run test
```

### Start
```
npm start
```