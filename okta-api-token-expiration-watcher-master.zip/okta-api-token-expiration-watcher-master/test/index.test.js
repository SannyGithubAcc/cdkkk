const oktaRepo = require('../src/okta-repo');
process.env.token_expiration_threshold_in_days = 100
jest.mock('../src/okta-repo');
jest.mock('../src/notification-repo', () => {
    let mockObj = {};
    function getMock(name) {
      if (!mockObj[name]) {
        mockObj[name] = jest.fn().mockResolvedValue();
      }
      return mockObj[name];
    }
    return jest.fn().mockImplementation(() => {
        return { sendSNSAlert: getMock('sendSNSAlert') }
    })
})
const notificationRepo = require('../src/notification-repo')({});
const index = require('../src/index');

describe('index.handler', () => {
    beforeEach(() => {
        oktaRepo.getExpiringAPITokens.mockClear();
        notificationRepo.sendSNSAlert.mockClear();
    })
    test('should send alert when okta api tokens exist which expire within configure threshold in days', async () => {
        const expiringTokenList = [
            { expiresAt: 'expiresAt',
              tokenName: 'tokenName',
              ownerName: 'ownerName',
              ownerLogin: 'ownerLogin' }
        ]
        oktaRepo.getExpiringAPITokens.mockResolvedValue(expiringTokenList);
        await index.handler();
        expect(oktaRepo.getExpiringAPITokens.mock.calls.length).toBe(1);
        expect(oktaRepo.getExpiringAPITokens.mock.calls[0][0]).toBe(process.env.token_expiration_threshold_in_days);
        expect(notificationRepo.sendSNSAlert.mock.calls.length).toBe(1);
        expect(notificationRepo.sendSNSAlert.mock.calls[0][0]).toEqual({
            "Number of Expiring Tokens": expiringTokenList.length,
            "Expiration Threshold In Days": process.env.token_expiration_threshold_in_days,
            "Expiring Tokens": expiringTokenList
        });
    })

    test('should send alert when faled to fetch token information or unhandled exception', async () => {
        const mockError = { message: '401 - UnAuthorized' };
        oktaRepo.getExpiringAPITokens.mockRejectedValue(mockError);
        await index.handler();
        expect(oktaRepo.getExpiringAPITokens.mock.calls.length).toBe(1);
        expect(oktaRepo.getExpiringAPITokens.mock.calls[0][0]).toBe(process.env.token_expiration_threshold_in_days);
        expect(notificationRepo.sendSNSAlert.mock.calls.length).toBe(1);
        expect(notificationRepo.sendSNSAlert.mock.calls[0][0]).toEqual({
            message: 'Unexpected error occured, failed to verify token expiration, need investigation',
            error: mockError.message
        });
    })
})