const axios = require('axios');
jest.mock('axios');
const oktaRepo = require('../src/okta-repo');

describe('oktaRepo', () => {
    let dateSpy;
    const mockTokenRes = [{
        "expiresAt": "2021-01-02T00:00:00.000Z",
        "name": "API Token 1 (DO NOT DELETE)",
        "_embedded": {
            "user": {
                "id": "00u2a228mdGlnN7oS2p7",
                "displayName": "Token displayname",
                "login": "token_owner_1@cdk.com",
                "role": "Read Only Admin"
              }
        }
    },
    {
        "expiresAt": "2021-01-03T00:00:00.000Z",
        "name": "API Token 2 (DO NOT DELETE)",
        "_embedded": {
            "user": {
                "id": "00u2a228mdGlnN7oS2p7",
                "displayName": "Token displayname",
                "login": "token_owner_2@cdk.com",
                "role": "Read Only Admin"
              }
        }
    },
    {
        "expiresAt": "2021-01-05T00:00:00.000Z",
        "name": "API Token 3 (DO NOT DELETE)",
        "_embedded": {
            "user": {
                "id": "00u2a228mdGlnN7oS2p7",
                "displayName": "Token displayname",
                "login": "token_owner_2@cdk.com",
                "role": "Read Only Admin"
              }
        }
    }];

    beforeAll(() => {
        dateSpy = jest.spyOn(Date, 'now')
    })
    afterAll(() => {
        dateSpy.mockRestore();
    })
    describe('getExpiringAPITokens', () => {
        beforeEach(() => {
            axios.get.mockClear();
        })

        test('should build okta request object', () => {
            axios.get.mockResolvedValue([]);
            oktaRepo.getExpiringAPITokens();
            expect(axios.get.mock.calls.length).toBe(1);
            expect(axios.get.mock.calls[0][0].endsWith('/api/internal/tokens?expand=user')).toBeTruthy();
            expect(axios.get.mock.calls[0][1]).toEqual({
                headers: {
                    'Authorization': `SSWS ${process.env.okta_api_token || ''}`,
                    'Accept': 'application/json'
                }
            });
        });

        test('should return expiring tokens based on input days - return 1 token when input data range is set to 1 day', async () => {
            axios.get.mockResolvedValue({ data: mockTokenRes });
            let currenDateMockDateInEpoch = new Date('2021-01-01T00:00:00.000Z').getTime();
            dateSpy.mockReturnValue(currenDateMockDateInEpoch);
            const tokenList = await oktaRepo.getExpiringAPITokens(2);
        
            expect(tokenList).toEqual([
                {
                    "expiresAt": mockTokenRes[0].expiresAt,
                    "tokenName": mockTokenRes[0].name,
                    "ownerName": mockTokenRes[0]._embedded.user.displayName,
                    "ownerLogin": mockTokenRes[0]._embedded.user.login
                }
            ]);
        });

        test('should return expiring tokens based on input days - return 2 tokens when input data range is set to 3 days', async () => {
            axios.get.mockResolvedValue({ data: mockTokenRes });
            let currenDateMockDateInEpoch = new Date('2021-01-01T00:00:00.000Z').getTime();
            dateSpy.mockReturnValue(currenDateMockDateInEpoch);
            const tokenList = await oktaRepo.getExpiringAPITokens(3);
        
            expect(tokenList).toEqual([
                {
                    "expiresAt": mockTokenRes[0].expiresAt,
                    "tokenName": mockTokenRes[0].name,
                    "ownerName": mockTokenRes[0]._embedded.user.displayName,
                    "ownerLogin": mockTokenRes[0]._embedded.user.login
                },
                {
                    "expiresAt": mockTokenRes[1].expiresAt,
                    "tokenName": mockTokenRes[1].name,
                    "ownerName": mockTokenRes[1]._embedded.user.displayName,
                    "ownerLogin": mockTokenRes[1]._embedded.user.login
                }
            ]);
        });

        test('should return expiring tokens based on input days - return 3 tokens when input data range is set to 7 days', async () => {
            axios.get.mockResolvedValue({ data: mockTokenRes });
            let currenDateMockDateInEpoch = new Date('2021-01-01T00:00:00.000Z').getTime();
            dateSpy.mockReturnValue(currenDateMockDateInEpoch);
            const tokenList = await oktaRepo.getExpiringAPITokens(7);
        
            expect(tokenList).toEqual([
                {
                    "expiresAt": mockTokenRes[0].expiresAt,
                    "tokenName": mockTokenRes[0].name,
                    "ownerName": mockTokenRes[0]._embedded.user.displayName,
                    "ownerLogin": mockTokenRes[0]._embedded.user.login
                },
                {
                    "expiresAt": mockTokenRes[1].expiresAt,
                    "tokenName": mockTokenRes[1].name,
                    "ownerName": mockTokenRes[1]._embedded.user.displayName,
                    "ownerLogin": mockTokenRes[1]._embedded.user.login
                },
                {
                    "expiresAt": mockTokenRes[2].expiresAt,
                    "tokenName": mockTokenRes[2].name,
                    "ownerName": mockTokenRes[2]._embedded.user.displayName,
                    "ownerLogin": mockTokenRes[2]._embedded.user.login
                }
            ]);
        });

        test('should return empty array when no tokens expires within input number of days', async () => {
            axios.get.mockResolvedValue({ data: mockTokenRes });
            let currenDateMockDateInEpoch = new Date('2021-01-01T00:00:00.000Z').getTime()/1000;
            dateSpy.mockReturnValue(currenDateMockDateInEpoch);
            const tokenList = await oktaRepo.getExpiringAPITokens(1);
        
            expect(tokenList).toEqual([]);
        });
        
    });
});