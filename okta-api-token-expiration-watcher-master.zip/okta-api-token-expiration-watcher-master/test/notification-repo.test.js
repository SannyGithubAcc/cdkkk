let publishMock = jest.fn().mockResolvedValue();
let snsMock = { publish: jest.fn().mockReturnValue({ promise: publishMock }) };
const alertRepo = require('../src/notification-repo')(snsMock);

describe('notificationRepo.sendSNSAlert', () => {
    beforeEach(() => {
        snsMock.publish.mockClear();
        publishMock.mockClear();
    })
    test('should be defined', () => {
        expect(alertRepo.sendSNSAlert).toBeDefined();
    });

    test('should throw error when no input received', async (done) => {
        try{
            await alertRepo.sendSNSAlert();
        }catch(err){
            expect(err).toEqual({ error: 'Invalid event payload' });
            done()
        }
        expect.assertions(1);
    });

    test('should send an alert with input event payload', async () => {
        let mockInput =  { message: 'Tokens Expiring', data: { } };
        await alertRepo.sendSNSAlert(mockInput);
        expect(snsMock.publish.mock.calls.length).toBe(1);
        expect(snsMock.publish.mock.calls[0][0].Message).toBe(JSON.stringify(mockInput));
        expect(snsMock.publish.mock.calls[0][0].TopicArn).toBe(process.env.sns_notification_topic);
    });
})