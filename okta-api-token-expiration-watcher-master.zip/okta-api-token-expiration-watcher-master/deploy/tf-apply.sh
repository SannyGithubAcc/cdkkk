#!/bin/bash

set -ue

DOCKER_USER="$(id -u):$(id -g)"

function terraform
{
  docker run --rm --user ${DOCKER_USER} -v $(pwd):/app --workdir /app hashicorp/terraform:0.13.7 $@
}

cat >> terraform.tfvars <<EOF

access_key="${bamboo_inject_aws_access_key}"
secret_key="${bamboo_inject_aws_secret_access_key}"
okta_api_token="${bamboo_inject_secret_okta_api_token}"
EOF

cat > backend.tf <<EOF
terraform {
  backend "s3" {}
}
EOF

cat >> config.tfbackend <<EOT
access_key = "${bamboo_inject_aws_access_key}"
secret_key = "${bamboo_inject_aws_secret_access_key}"
EOT


terraform init -reconfigure -backend-config=config.tfbackend

terraform apply -lock=true -auto-approve