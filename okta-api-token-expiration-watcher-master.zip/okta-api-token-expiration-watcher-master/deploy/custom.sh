#!/bin/bash

######################## Must in Custom.sh file  ##########################
# This file is being introduced to perform any custom tasks that you have to perform.
# You do not need to update the tf-apply.sh file.

# export the environment file elements to access here
#------------------------------------------
set -a 
. ../${env}.env
set +a
# -----------------------------------------

# Configuring the s3 backend bucket in config.tfbackend file.
cat >> config.tfbackend <<EOT
bucket = "${s3_backend_bucket}"
region = "${aws_region}"
EOT

#########################  Must in custom.sh file ######################

#########################  Must in custom.sh file ######################


# File to fetch the secrets
cd ../secret-fetch

# Now running same script to fetch apigee username and password.

sh get-secret-by-id.sh ${okta_api_key_secret_id} okta_api_token_key secret_okta_api_token