const SNS_TOPIC_ARN = process.env.sns_topic_arn;

function notificationRepo(sns){

    function sendSNSAlert(event){
        if(!event){
            throw { error: 'Invalid event payload' };
        }
        const payload = {
            Message: JSON.stringify(event),
            TopicArn: SNS_TOPIC_ARN,
            Subject: 'OKTA API Token(s) Expiring - Action Required'
        };
        return sns.publish(payload).promise();
    };

    return {
        sendSNSAlert
    }
}

module.exports = notificationRepo;