const AWS = require('aws-sdk');
const AWS_REGION = process.env.aws_region || '';
AWS.config.update({region: AWS_REGION});
const sns = new AWS.SNS({apiVersion: '2010-03-31'});
const notiticationRepo = require('./notification-repo')(sns);
const oktaRepo = require('./okta-repo');
const token_expiration_threshold_in_days = process.env.token_expiration_threshold_in_days || 100;
const logger = require("@fortellis/logger");
logger.setContext("OKTA-API-TOKEN-WATCHER");

exports.handler =  async function(event, context) {
    logger.info({ message: 'Processing start.' })
    try{
        logger.info({ message: 'Fetching expiring API Tokens from okta' });
        const expiringTokens = await oktaRepo.getExpiringAPITokens(token_expiration_threshold_in_days);
        logger.info({ message: 'Info about expiring tokens fetched.', expirationThresholdInDays: token_expiration_threshold_in_days, expiringItems: expiringTokens.length });
        if(expiringTokens.length){
            await notiticationRepo.sendSNSAlert({ 
                "Number of Expiring Tokens": expiringTokens.length,
                "Expiration Threshold In Days": token_expiration_threshold_in_days,
                "Expiring Tokens": expiringTokens
            });
            logger.info({ message: 'Notification posted to sns topic successfully.', expiringingItems: expiringTokens.length, expirationThresholdInDays: token_expiration_threshold_in_days })
        }else{
            logger.info({ message: 'No tokens expiring within configured window, notification skipped.', expirationThresholdInDays: token_expiration_threshold_in_days })
        }
    }catch(err){
        logger.error({ message: 'Failed to process api tokens', error: err.message || err });
        let event = { 
            message : 'Unexpected error occured, failed to verify token expiration, need investigation',
            error: err.message
        };
        await notiticationRepo.sendSNSAlert(event);
        logger.info({ message: 'Alert sent about processing failure.', critical: true })
    }
    logger.info({ message: 'Processing complete.' });
}