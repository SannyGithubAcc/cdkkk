const axios = require('axios');
const TOKEN_PATH = 'api/internal/tokens?expand=user';
const OKTA_ADMIN_BASE_URL = process.env.okta_admin_base_url || '';
const OKTA_API_TOKEN = process.env.okta_api_token || '';
const SECONDS_IN_A_DAY = 86400;

function filterByExpirationDays(tokenList, noOfDays){
    let futureExpirationTime = Date.now()/1000 + (noOfDays * SECONDS_IN_A_DAY);
    // "new Date(TIME).getTime()/1000" converts time in Z timestamp(ex: 2021-01-03T00:00:00.000Z) to epoch(ex: 1611271125469)
    let expiringTokens = tokenList.filter(token => futureExpirationTime > new Date(token.expiresAt).getTime()/1000);

    return expiringTokens.map(each => ({
        expiresAt: each.expiresAt,
        tokenName: each.name,
        ownerName: each._embedded.user.displayName,
        ownerLogin: each._embedded.user.login
    }))
}

async function getExpiringAPITokens(noOfDays){
    const options = {
        headers: {
            'Authorization': `SSWS ${OKTA_API_TOKEN}`,
            'Accept': 'application/json'
        }
    };
    let { data: tokenList} = await axios.get(`${OKTA_ADMIN_BASE_URL}/${TOKEN_PATH}`, options);
    return filterByExpirationDays(tokenList, noOfDays); 
}

module.exports = {
    getExpiringAPITokens
}