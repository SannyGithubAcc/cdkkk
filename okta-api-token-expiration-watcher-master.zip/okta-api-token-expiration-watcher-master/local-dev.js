require('dotenv').config({ path: 'config/.env' });

const {handler} = require('./src/index');

async function main(){
    console.log('#### START')
    await handler();
    console.log('#### END')
}

main()